#ifndef __HS_ADC_H__
#define __HS_ADC_H__
#include <rtdevice.h>




void adc_init();
uint16_t Get_Tem_Data();
uint16_t Get_Cp_Data();
uint16_t Get_Jd_Data();
void sensor_data_filter();
void mspi_init();

#endif