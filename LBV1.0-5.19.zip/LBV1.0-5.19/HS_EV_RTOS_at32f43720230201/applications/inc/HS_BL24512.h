#ifndef __HS_BL24512__H
#define __HS_BL24512__H

#include <rthw.h>
#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

#define BL24C01     0
#define BL24C02     1
#define BL24C04     2
#define BL24C08     3
#define BL24C16     4
#define BL24C32     5
#define BL24C64     6
#define BL24C128    7
#define BL24C256    8
#define BL24C512    9
#define BL24CTYPE   10   // Number of supported types

#define EE_TWR      5

#ifndef EE_TYPE
#define EE_TYPE     BL24C512
#endif

struct bl24cxx_device
{
    struct rt_i2c_bus_device *i2c;
    rt_mutex_t lock;
    uint8_t AddrInput;
};

typedef struct bl24cxx_device *bl24cxx_device_t;

void bl24512_init();
extern bl24cxx_device_t bl24cxx_init(const char *i2c_bus_name, uint8_t AddrInput);
extern rt_err_t bl24cxx_read(bl24cxx_device_t dev, uint32_t ReadAddr, uint8_t *pBuffer, uint16_t NumToRead);
extern rt_err_t bl24cxx_write(bl24cxx_device_t dev, uint32_t WriteAddr, uint8_t *pBuffer, uint16_t NumToWrite);
extern rt_err_t bl24cxx_page_read(bl24cxx_device_t dev, uint32_t ReadAddr, uint8_t *pBuffer, uint16_t NumToRead);
extern rt_err_t bl24cxx_page_write(bl24cxx_device_t dev, uint32_t WriteAddr, uint8_t *pBuffer, uint16_t NumToWrite);


#endif