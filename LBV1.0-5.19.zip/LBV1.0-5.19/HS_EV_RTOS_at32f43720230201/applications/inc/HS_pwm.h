#ifndef __HS_PWM_H__
#define __HS_PWM_H__


void pwm_init();

#endif