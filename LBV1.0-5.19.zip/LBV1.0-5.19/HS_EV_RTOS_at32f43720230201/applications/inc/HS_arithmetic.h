#ifndef __HS_ARITHMETIC_H
#define __HS_ARITHMETIC_H
#include <rtthread.h>


uint32_t* averaging(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint32_t arr4[],uint8_t strlen);
void bubblesort(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint32_t arr4[],uint8_t strlen);
char* itoa(int num,char* str,int radix);

#endif