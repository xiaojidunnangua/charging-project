#ifndef __HS_DDS3666D_H__
#define __HS_DDS3666D_H__
#include <rtdevice.h>

uint32_t Dds3366_Read_Dn();
void Dds3366_Read_Cdds();
uint8_t* Dds3366_Read(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data);
uint8_t* Dds3366_Read_I(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data);
uint8_t* Dds3366_Read_V(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data);
uint8_t* Dds3366_Read_E(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data);
uint8_t* Dds3366_Read_Addr(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data);
uint8_t* Dds3366_Read_Init_E(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data);
void Read_Device_Addr();
uint32_t Read_Device_Ey(uint8_t *addr);
uint16_t Read_Device_Ve(uint8_t *addr);
uint32_t Read_Device_Ie(uint8_t *addr);
//void rs485_init();
#endif