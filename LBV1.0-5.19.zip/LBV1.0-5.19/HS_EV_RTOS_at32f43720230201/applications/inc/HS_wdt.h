#ifndef __HS_WDT_H__
#define __HS_WDT_H__



void wdt_init();


#endif