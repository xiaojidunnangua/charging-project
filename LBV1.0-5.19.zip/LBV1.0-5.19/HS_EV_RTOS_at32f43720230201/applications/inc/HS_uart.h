#ifndef __HS_UART_H__
#define __HS_UART_H__
#include <rtthread.h>
#include "at32f435_437.h"


int uart_init();
void uart_tx_string(usart_type* usart_x,uint8_t* SendData,uint16_t len);
#endif