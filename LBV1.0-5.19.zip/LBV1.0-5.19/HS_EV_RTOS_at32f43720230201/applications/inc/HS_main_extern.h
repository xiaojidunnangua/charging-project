
//#include "HS_main.h" 
#include "HS_#define.h"  
// ����
//--- Global Variables
//extern DATADCT DATADCT1;
//extern int16 AdcBuf[ADC_CH_MAX][ADC_BUFF_LEN];
//extern Uint16 SampleTable[AVG];

//extern unsigned int Flag1;


//extern   Comm Comm1;
//extern   Comm Comm2;
//extern   Comm Comm3;
//extern   UserModbus  UserModbusP;

//extern unsigned int SCIA_Run_Flag;
//extern unsigned int SCIB_Run_Flag;
//extern unsigned int SCIC_Run_Flag;

//extern	unsigned int TXA_Flag;
//extern	unsigned int TXB_Flag;
//extern	unsigned int TXC_Flag;




//extern int16 flag_led,flag_led2;

////extern char LCD0X66_Ctype[] ;

//void FrameC(Comm *p);
//void FrameA(Comm *p);

//Uint16 calsqrvalue( );

//void GPBTOGGLE_GPIO32();

//unsigned short crc16(unsigned char *buff, int len);


