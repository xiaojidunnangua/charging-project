#ifndef __HS_CRC_H__
#define __HS_CRC_H__

#include <rtthread.h>

uint16_t ModbusCRC(uint8_t *pData,uint16_t len);


#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t crc;
} crc32_ctx;

void crc32_init(crc32_ctx *ctx);
void crc32_update(crc32_ctx *ctx, const uint8_t *data, size_t len);
void crc32_final(crc32_ctx *ctx, uint32_t *crc);

uint8_t checksum8(uint8_t *buf, uint8_t len);



#endif
