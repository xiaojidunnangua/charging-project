#ifndef __HS_RTC_H__
#define __HS_RTC_H__

int rtc_init();




#endif