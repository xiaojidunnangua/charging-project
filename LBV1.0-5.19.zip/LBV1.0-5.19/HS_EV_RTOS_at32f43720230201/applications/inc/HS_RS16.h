#ifndef __HS_RS16_H__
#define __HS_RS16_H__
#include "stdint.h"

#define   FM25640C_WREN  0x06
#define   FM25640C_WRDI  0x04
#define   FM25640C_RDSR  0x05ff
#define   FM25640C_WRSR  0x0100
#define   FM25640C_READ  0x030000FF
#define   FM25640C_WRITE  0x02000000
#define   W5500_SCS1	  rt_pin_write(RS16_CS, PIN_HIGH)	//����W5500��CS����	 
#define   W5500_SCS0		rt_pin_write(RS16_CS, PIN_LOW)//����W5500��CS����	


int rs16_init(void);
void SPI1_Send_Byte(uint8_t dat);
uint8_t FM25640C_Read_Byte(uint32_t addr);
void FM25640C_Write_Byte(uint32_t addr, uint8_t wrdata);
void FM25640C_Write();
uint8_t FM25640C_Read();
uint8_t *rs16_read_string(uint32_t addr,uint8_t *dest,uint16_t length);
uint8_t *FRAM_read1(uint32_t addr,uint8_t *dest,uint16_t length);
void rs16_write_string(uint32_t addr,uint8_t *dest,uint16_t length);
void FRAM_WRITE1(uint32_t addr,uint8_t *dest,uint16_t length);




#endif