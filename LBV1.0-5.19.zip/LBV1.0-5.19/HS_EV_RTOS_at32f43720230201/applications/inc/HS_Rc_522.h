#ifndef __HS_RC_522_H
#define __HS_RC_522_H






#endif