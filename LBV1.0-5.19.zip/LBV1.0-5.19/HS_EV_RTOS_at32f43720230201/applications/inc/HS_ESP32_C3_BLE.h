#ifndef __HS_ESP32_C3_BLE__
#define __HS_ESP32_C3_BLE__

void bluetooth_connect();


#endif