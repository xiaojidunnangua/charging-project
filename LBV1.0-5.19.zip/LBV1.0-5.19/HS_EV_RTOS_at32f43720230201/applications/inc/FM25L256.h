
//#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
//#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

Uint16 spi_xmit(Uint16 byte);
void ReadFM25L256(unsigned int *pDestination, unsigned int uiSourceAddress, unsigned int uiNum);
void WriteFM25L256(unsigned char *pSource, unsigned int uiDestinationAddress, unsigned int uiNum);
void delay_loop(Uint16 time);
void WriteWRSR();
//unsigned int Spi_TxReady(void);

//unsigned int Spi_RxReady(void);
unsigned int ReadWRSR();