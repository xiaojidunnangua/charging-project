#ifndef __HS_GPIO_H__
#define __HS_GPIO_H__


void key1();
void Gpio_init();


#endif