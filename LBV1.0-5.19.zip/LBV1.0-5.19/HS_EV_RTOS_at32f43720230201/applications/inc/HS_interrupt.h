#ifndef __HS_INTERRUPT_H__
#define __HS_INTERRUPT_H__
#include <rtthread.h>





void interrupt_init();
uint16_t* get_fre_duty();
void Cp_Handale_Open();
void Pwm_Handale_Open();
//void exint_line0_config();
#endif