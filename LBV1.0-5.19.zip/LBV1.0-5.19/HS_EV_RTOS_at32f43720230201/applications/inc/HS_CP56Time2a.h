#ifndef __HS_CP56TIME2A_H__
#define __HS_CP56TIME2A_H__

#include <rtthread.h>

#pragma pack(push, 1)
typedef volatile union
{
	uint64_t Time;			// ��7�ֽ����߸���λλ�������ʱ��	
	struct
	{
		uint16_t msec;
		uint8_t min		: 6;
		uint8_t res1	: 1;
		uint8_t iv 		: 1;
		uint8_t hour 	: 5;
		uint8_t res2 	: 2;
		uint8_t su 		: 1;
		uint8_t mday 	: 5;
		uint8_t wday 	: 3;
		uint8_t month   : 4;
		uint8_t res3 	: 4;
		uint8_t year 	: 7;
		uint8_t res4 	: 1;
	}Compts;
}st_cp56time2a;

#pragma pack(pop)
//st_cp56time2a  Cp56time2a1;			// ����ṹ�塮 Cp56time2a ��

uint8_t* CP56_data();

#endif