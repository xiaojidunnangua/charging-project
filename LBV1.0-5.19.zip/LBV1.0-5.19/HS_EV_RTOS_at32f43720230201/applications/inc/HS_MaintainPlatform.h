#ifndef __HS_MAINTAINPLATFORM_H
#define __HS_MAINTAINPLATFORM_H
#include "mqttclient.h"



//int mqtt_init();
int mqtt_publish_handle1(mqtt_client_t *client,char *str_data);
char* mqtt_json_devicedata(uint8_t *device_data);
char* mqtt_json_finaldata(uint8_t *finaldata_data,uint8_t *zbm,uint8_t *manufacturers_data,uint8_t *device_id_data,uint8_t *platform);
void mqtt_4g_pub_finaldata();
void mqtt_4g_pub_device();
void yy_4g_connect();
void sub_topic_handle1(void* client, message_data_t* msg);

#endif