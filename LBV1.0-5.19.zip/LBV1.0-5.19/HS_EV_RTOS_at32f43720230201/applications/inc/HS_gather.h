#ifndef __HS_GATHER_H__
#define __HS_GATHER_H__


void Recharge_Combine();

#endif