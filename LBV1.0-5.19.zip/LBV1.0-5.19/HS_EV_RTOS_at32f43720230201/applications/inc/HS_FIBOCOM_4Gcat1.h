#ifndef __HS_FIBOCOM_4Gcat1_H__
#define __HS_FIBOCOM_4Gcat1_H__




void FIB_4G_dataprocess();
void Flb_cloud_connect();
void SD_cloud_connect();
void APP_cloud_connect();
void f4g_connect_cloud();
void cloud_eliminate();
//void cloud_4g_connect();
void ssjcsj_bw();

#endif 
