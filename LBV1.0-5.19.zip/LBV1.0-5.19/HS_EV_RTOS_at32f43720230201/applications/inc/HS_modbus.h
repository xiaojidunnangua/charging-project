#ifndef __HS_MODUBUS_H
#define __HS_MODUBUS_H

#include <rtthread.h>
void modbus_10_function();
void modbus_05_function();
void modbus_03_function();
void modbus_02_function();
void modbus_65_function();
void rs485_send(uint8_t *data,uint16_t len);
#endif