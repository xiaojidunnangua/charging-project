#ifndef __HS_TIMER_H__
#define __HS_TIMER_H__


int hwtimer_init();

#endif