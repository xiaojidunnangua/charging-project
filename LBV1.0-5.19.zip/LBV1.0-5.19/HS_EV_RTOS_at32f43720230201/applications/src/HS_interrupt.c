#include <rtthread.h>
#include <rtdevice.h>
#include "drv_gpio.h"
#include "HS_main.h"
#include "HS_#define.h"  
#include "HS_interrupt.h"
//#include "HS_adc.h"
//#include "HS_uart.h"






uint8_t iqr_duty_num=1;
uint8_t iqr_frequency_num=1;
uint8_t iqr_duty_freq_switch=1;






void USART1_IRQHandler(void)
{
	uint8_t clear;
	if(usart_flag_get(USART1,USART_IDLEF_FLAG)!=RESET)
	{
		
		clear=USART1->sts;                                              // USART1��������жϱ�־λ
		clear=USART1->dt;												// USART1��������жϱ�־λ
		clear&=0;
		uart1_device.uart_flag=1;
		uint16_t read_len=0;
		read_len=255-dma_data_number_get(DMA1_CHANNEL2);
		uart1_device.uart_rx_len=read_len;
		rt_ringbuffer_put(uart1_device.ringbuffer,uart1_device.uart_rx_buffer,read_len);
		rt_memset(uart1_device.uart_rx_buffer,'\0',read_len);
		
		dma_flag_clear(DMA1_FDT2_FLAG);                 //���־  
    dma_channel_enable(DMA1_CHANNEL2, FALSE);       //�ر�USART1 DMA ����
    usart_dma_receiver_enable(USART1,FALSE);        //�ر�ͨ��5
    DMA1_CHANNEL2->dtcnt=255;                       //���յ����ݳ���
    DMA1_CHANNEL2->maddr=(uint32_t)uart1_device.uart_rx_buffer;   //�������buf��ַ
    usart_dma_receiver_enable(USART1,TRUE);         //����USART1 DMA ����
    dma_channel_enable(DMA1_CHANNEL2, TRUE);        //����ͨ��5����ʼ���գ�
	}
}


void USART3_IRQHandler(void)
{
	uint8_t clear;
	if(usart_flag_get(USART3,USART_IDLEF_FLAG)!=RESET)
	{
		
		clear=USART3->sts;                                              // USART1��������жϱ�־λ
		clear=USART3->dt;												// USART1��������жϱ�־λ
		clear&=0;
		uart3_device.uart_flag=1;
		uint16_t data_len=0;
		data_len=255-dma_data_number_get(DMA1_CHANNEL4);
		uart3_device.uart_rx_len=data_len;
		
		dma_flag_clear(DMA1_FDT4_FLAG);                 //���־  
    dma_channel_enable(DMA1_CHANNEL4, FALSE);       //�ر�USART1 DMA ����
    usart_dma_receiver_enable(USART3,FALSE);        //�ر�ͨ��5
    DMA1_CHANNEL4->dtcnt=255;                       //���յ����ݳ���
    DMA1_CHANNEL4->maddr=(uint32_t)uart3_device.uart_rx_buffer;   //�������buf��ַ
    usart_dma_receiver_enable(USART3,TRUE);         //����USART1 DMA ����
    dma_channel_enable(DMA1_CHANNEL4, TRUE);        //����ͨ��5����ʼ���գ�	
	}
}



void UART4_IRQHandler(void)
{
	uint8_t clear;
	if(usart_flag_get(UART4,USART_IDLEF_FLAG)!=RESET)
	{
		
		clear=UART4->sts;                                              // USART1��������жϱ�־λ
		clear=UART4->dt;												// USART1��������жϱ�־λ
		clear&=0;
		uart4_device.uart_flag=1;
		uint16_t data_len=0;
		data_len=255-dma_data_number_get(DMA1_CHANNEL5);
//		data_len=dma_data_number_get(DMA1_CHANNEL4);
		uart4_device.uart_rx_len=data_len;


		
		dma_flag_clear(DMA1_FDT5_FLAG);                 //���־  
    dma_channel_enable(DMA1_CHANNEL5, FALSE);       //�ر�USART1 DMA ����
    usart_dma_receiver_enable(UART4,FALSE);        //�ر�ͨ��5
    DMA1_CHANNEL5->dtcnt=255;                       //���յ����ݳ���
    DMA1_CHANNEL5->maddr=(uint32_t)uart4_device.uart_rx_buffer;   //�������buf��ַ
    usart_dma_receiver_enable(UART4,TRUE);         //����USART1 DMA ����
    dma_channel_enable(DMA1_CHANNEL5, TRUE);        //����ͨ��5����ʼ���գ�	
	}
}



void UART5_IRQHandler(void)
{
	uint8_t clear;
	if(usart_flag_get(UART5,USART_IDLEF_FLAG)!=RESET)
	{
		
		clear=UART5->sts;                                              // USART1��������жϱ�־λ
		clear=UART5->dt;												// USART1��������жϱ�־λ
		clear&=0;
		uart5_device.uart_flag=1;
		uint16_t data_len=0;
		data_len=255-dma_data_number_get(DMA1_CHANNEL6);
//		data_len=dma_data_number_get(DMA1_CHANNEL4);
		uart5_device.uart_rx_len=data_len;;
		
		dma_flag_clear(DMA1_FDT6_FLAG);                 //���־  
    dma_channel_enable(DMA1_CHANNEL6, FALSE);       //�ر�USART1 DMA ����
    usart_dma_receiver_enable(UART5,FALSE);        //�ر�ͨ��5
    DMA1_CHANNEL6->dtcnt=255;                       //���յ����ݳ���
    DMA1_CHANNEL6->maddr=(uint32_t)uart5_device.uart_rx_buffer;   //�������buf��ַ
    usart_dma_receiver_enable(UART5,TRUE);         //����USART1 DMA ����
    dma_channel_enable(DMA1_CHANNEL6, TRUE);        //����ͨ��5����ʼ���գ�	
	}
}


void DMA1_Channel1_IRQHandler(void)
{
  if(dma_flag_get(DMA1_FDT1_FLAG) != RESET)
  {
    dma_flag_clear(DMA1_FDT1_FLAG);
    dma_trans_complete_flag++;
  }
}

/**
  * @brief  this function handles adc1_2_3 handler.
  * @param  none
  * @retval none
  */
void ADC1_2_3_IRQHandler(void)
{
  if(adc_flag_get(ADC1, ADC_OCCO_FLAG) != RESET)
  {
    adc_flag_clear(ADC1, ADC_OCCO_FLAG);
    adc1_overflow_flag++;
  }
}




////�ص�����
void IQR_HANDALE_PWM(void *args)
{
	
	rt_hwtimerval_t timeout_s;      /* ��ʱ����ʱֵ */
	iqr_duty_num++;
	
	if(iqr_duty_num%2!=0&&iqr_frequency_num==1)
	{
		iqr_frequency_num=2;
		rt_device_read(time4_dev, 0, &timeout_s, sizeof(timeout_s));
		frequency_count_record2=timeout_s.usec+3;
		frequency_flag_record=1;
		timeout_s.sec =0;
		timeout_s.usec = 10;
		rt_device_write(time4_dev, 0, &timeout_s, sizeof(timeout_s));
		
	}
	else if(iqr_duty_num%2==0&&iqr_frequency_num==2)
	{
		iqr_frequency_num=1;
		iqr_duty_num=0;
		rt_device_read(time4_dev, 0, &timeout_s, sizeof(timeout_s));
		frequency_count_record1=timeout_s.usec+4;
	}
}

uint16_t get_adcval_average1(uint8_t times)
{
	uint16_t adc_val[200];
	uint32_t adc_valsum=0;
	
	uint8_t cut;
	for(cut=0;cut<times;cut++)							//��λ�ȡadc��ֵ
	{
		adc_val[cut]=adc1_ordinary_valuetab[1];
//		rt_thread_delay(5);
	}
	for(cut=1;cut<times-1;cut++)						//ȥ����һ�κ����һ�ε�ֵ
	{
		adc_valsum+=adc_val[cut];
		
	}
	
	return adc_valsum/(times-2);						//����ƽ��ֵ
}

void IQR_HANDALE_CP(void *args)
{
	
	if(cpcp_thread_flag == CP_Sampling_Eint)
	{
		
//		CP_Voltage = get_adcval_average1(150);//0.3784295175023;  //*3300/4096*4.546
//		CP_Voltage=CP_Voltage*0.3784295175023;
//		read_modbus_buffer[4]=CP_Voltage>>8;
//		read_modbus_buffer[5]=CP_Voltage;
		for(int t=0;t<200;t++)
		{
			uint16_t cpcp_value=0;
			cpcp_value=adc1_ordinary_valuetab[1];
			CP_Voltage = cpcp_value*0.3784295175023;//0.3784295175023;  //*3300/4096*4.546
			read_modbus_buffer[4]=CP_Voltage>>8;
			read_modbus_buffer[5]=CP_Voltage;
			
		}
		
	}
}

void IQR_HANDALE_UP(void *args)
{
	rt_pin_detach_irq(PIN_EINT0);
	rt_pin_attach_irq(PIN_EINT0, PIN_IRQ_MODE_RISING_FALLING  , IQR_HANDALE_PWM, RT_NULL);
	rt_pin_irq_enable(PIN_EINT0,PIN_IRQ_ENABLE);
}


void Cp_Handale_Open()
{
	rt_pin_detach_irq(PIN_EINT0);
	rt_pin_attach_irq(PIN_EINT0, PIN_IRQ_MODE_RISING  , IQR_HANDALE_CP, RT_NULL);
	rt_pin_irq_enable(PIN_EINT0, PIN_IRQ_ENABLE);
}

void Pwm_Handale_Open()
{
	rt_pin_detach_irq(PIN_EINT0);
	rt_pin_attach_irq(PIN_EINT0, PIN_IRQ_MODE_RISING  , IQR_HANDALE_UP, RT_NULL);
	rt_pin_irq_enable(PIN_EINT0,PIN_IRQ_ENABLE);
}


uint16_t* get_fre_duty()
{
	static uint16_t pwm_data[2]={0x00,0x00};
	
	rt_thread_delay(10);
	if(frequency_flag_record==1)
	{
		frequency_flag_record=0;
		pwm_data[0]=(frequency_count_record1);
		pwm_data[1]=frequency_count_record2;
		rt_kprintf("%d,%d\n",pwm_data[0],pwm_data[1]);
		return pwm_data;
	}
}



void interrupt_init()
{
  //����Ϊ����
  rt_pin_mode(PIN_EINT0, PIN_MODE_INPUT);
	

  //���жϣ�������ģʽ���ص�������ΪIQR_HANDALE
//  rt_pin_attach_irq(PIN_EINT0, PIN_IRQ_MODE_RISING_FALLING  , IQR_HANDALE, RT_NULL);
	rt_pin_attach_irq(PIN_EINT0, PIN_IRQ_MODE_RISING  , IQR_HANDALE_CP, RT_NULL);
	//ʹ���ж�
	rt_pin_irq_enable(PIN_EINT0, PIN_IRQ_ENABLE);
//  
}




