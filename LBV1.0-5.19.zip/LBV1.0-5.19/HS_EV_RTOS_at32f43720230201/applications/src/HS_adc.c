#include <rtthread.h>
#include <rtdevice.h>
#include "HS_adc.h"
#include "HS_#define.h"
#include "HS_main.h"
#include "math.h"
#include "HS_IP101GR.h"
#include "HS_arithmetic.h"



//adc1��adc2���
rt_adc_device_t adc1_dev,adc2_dev,adc3_dev;

uint8_t sensor_gather_flag=1;

uint32_t sensor_data1[SENSOR_LEN_MAX],sensor_data2[SENSOR_LEN_MAX],sensor_data3[SENSOR_LEN_MAX];

//��ȡ�¶�����
uint16_t Get_Tem_Data()
{
	uint16_t tem_average_value=0;
	uint32_t Tmp_Data,Tmp_Data10k;
	uint16_t tem_value;
	uint16_t tem_data;
	uint16_t tem_value_average;
	double r1;
	
//	rt_adc_enable(adc2_dev, ADC2_DEV_CHANNEL12);                //��adc2��13ͨ��
//	for(int t=0;t<20;t++)
//	{
//		tem_value=rt_adc_read(adc2_dev, ADC2_DEV_CHANNEL12);        //��ȡ�¶�����
//		tem_average_value+=tem_value;
//	}
	tem_average_value=adc1_ordinary_valuetab[2];
	tem_data=tem_average_value;
	Tmp_Data=tem_data * 3300 / 4096;
	Tmp_Data10k = Tmp_Data * 10000; 
	r1 = Tmp_Data10k / (3300 - Tmp_Data); 
	
	r1=r1/10000;//1
	r1=log(r1);
	r1=r1/3950;//2
	r1=r1+0.003354;
	r1=1/r1;
	r1=r1-273.15;
	r1=r1*10; 
	if(r1>=0)
	{
		tem_value_average=r1;
		tem_state=0;
	}
	else
	{
		tem_value_average=r1*(-1);
//		tem_value_average=~tem_value_average;
		tem_value_average=tem_value_average|0x8000;
		tem_state=1;
	}
//	rt_adc_disable(adc2_dev, ADC2_DEV_CHANNEL0);               //�ر�adc2,13ͨ��
	return tem_value_average;
}





uint16_t Get_Cp_Data()
{
	uint16_t cpcp_value=0;
	uint16_t cp_data;
//	cpcp_value = rt_adc_read(adc1_dev, ADC1_DEV_CHANNEL10);
	for(int t=0;t<20;t++)
	{
		cpcp_value=adc1_ordinary_valuetab[1];
	}
	
	cp_data = cpcp_value*0.3784295175023;//0.3784295175023;  //*3300/4096*4.546//4.52
	return cp_data;
}

uint16_t Get_Jd_Data()
{
	
	uint16_t jd_value=0,jd_zz_value=0;
	uint32_t jd_pj_value=0;
	uint16_t vol=0;
	uint8_t jd_buffer[10];
	jd_value=adc1_ordinary_valuetab[0];
// jd_value = rt_adc_read(adc3_dev, ADC3_DEV_CHANNEL3);
//	for(int t=0;t<100000;t++)
//	{
//		jd_value = rt_adc_read(adc2_dev, ADC2_DEV_CHANNEL3);
//		jd_pj_value+=jd_value;
//	}
//	jd_zz_value=jd_pj_value/100000;
//	rt_kprintf("%d\n",jd_value);
	
	
//	rt_adc_disable(adc2_dev, ADC2_DEV_CHANNEL3);

//  /* ת��Ϊ��Ӧ��ѹֵ */
//  vol = jd_value * REFER_VOLTAGE / CONVERT_BITS;
//	sprintf((char *)jd_buffer,"%d",jd_value);
//	SendData(jd_buffer,sizeof(jd_buffer));
//  rt_kprintf("%d.%02d \n", vol / 100, vol % 100);
//	rt_adc_disable(adc3_dev, ADC3_DEV_CHANNEL3);
//	rt_adc_enable(adc3_dev, ADC3_DEV_CHANNEL3);
	return jd_value;
}


void sensor_ass_data(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint32_t length)
{
//	if(sensor_gather_flag==1)
//	{
//		sensor_gather_flag=0;
		for(int t=0;t<length;t++)
		{
			uint32_t value1=0x00,value2=0x00,value3=0x00;
			value1=Get_Tem_Data();
			value2=Get_Cp_Data();
//			value3=Get_Jd_Data();
			arr1[t]=value1;
			arr2[t]=value2;
			arr3[t]=value3;
		}
//	}
}


void sensor_ass_data_jd(uint32_t arr1[],uint32_t length)
{
//	if(sensor_gather_flag==1)
//	{
//		sensor_gather_flag=0;
		for(int t=0;t<length;t++)
		{
			uint32_t value1=0x00;
//			value3=Get_Jd_Data();
			arr1[t]=value1;
		}
//	}
}


void sensor_move_Front(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint16_t length)
{
	for (int i = 0; i < length; i++)
	{
		arr1[i] = arr1[i + 1];
		arr2[i] = arr2[i + 1];
		arr3[i] = arr3[i + 1];
	}
	uint16_t value1=0x00,value2=0x00,value3=0x00;
	value1=Get_Tem_Data();
	value2=Get_Cp_Data();
//	value3=Get_Jd_Data();
	arr1[SENSOR_LEN_MAX-1]=value1;
	arr2[SENSOR_LEN_MAX-1]=value2;
//	arr3[SENSOR_LEN_MAX-1]=value3;
}


void sensor_move_Front_jd(uint32_t arr1[],uint16_t length)
{
	for (int i = 0; i < length; i++)
	{
		arr1[i] = arr1[i + 1];
	}
	uint16_t value1=0x00;
	value1=Get_Jd_Data();
	arr1[SENSOR_LEN_MAX-1]=value1;
}

void sensor_mode_data(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint16_t len)
{
	
	uint32_t max1=0,max2=0,max3=0,number1,number2,number3,mode1,mode2,mode3;
	
	for(int i=0;i<len;i++)
	{ 
		
		number1=1;
		number2=1;
		number3=1;
    for(int j=0;j<len;j++)
	  {
      if(arr1[j]==arr1[i])
		  {
			  number1++;
      } 
      if(max1<number1)
		  {
        max1=number1;
        mode1=arr1[i];
		  }
			
			if(arr2[j]==arr2[i])
		  {
			  number2++;
      } 
      if(max2<number2)
		  {
        max2=number2;
        mode2=arr2[i];
		  }
			
			if(arr3[j]==arr3[i])
		  {
			  number3++;
      } 
      if(max3<number3)
		  {
        max3=number3;
        mode3=arr3[i];
		  }
			
    }
  }
	data_scpoe[TEMPERATURE].data =mode1;
	read_modbus_buffer[0]=data_scpoe[TEMPERATURE].data>>8;
	read_modbus_buffer[1]=data_scpoe[TEMPERATURE].data;
	if(cpcp_thread_flag==CP_Sampling_Loop)//�ж��߳�cpcp�����Ƿ��
	{
		CP_Voltage=mode2;
		read_modbus_buffer[4]=CP_Voltage>>8;
		read_modbus_buffer[5]=CP_Voltage;
	}
	data_scpoe[GROUNDING].data =mode3;
	read_modbus_buffer[2]=data_scpoe[GROUNDING].data>>8;
	read_modbus_buffer[3]=data_scpoe[GROUNDING].data;
//	rt_kprintf("%d\n",EffectiveGrounding_Value);
//	uint8_t jd_buffer[10];
//	sprintf((char *)jd_buffer,"%d",EffectiveGrounding_Value);
//	
//	SendData(jd_buffer,sizeof(jd_buffer));
//	rt_kprintf("Temperature:%d\n",Temperature);
//	rt_kprintf("CP_Voltage:%d\n",CP_Voltage);
//	rt_kprintf("EffectiveGrounding_Value:%d\n",EffectiveGrounding_Value);
	
}


uint16_t get_adcval_average(uint8_t times)
{
	uint16_t adc_val[100];
	uint32_t adc_valsum=0;
	
	uint8_t cut;
	for(cut=0;cut<times;cut++)							//��λ�ȡadc��ֵ
	{
		adc_val[cut]=Get_Cp_Data();
		rt_thread_delay(5);
	}
	for(cut=1;cut<times-1;cut++)						//ȥ����һ�κ����һ�ε�ֵ
	{
		adc_valsum+=adc_val[cut];
		
	}
	
	return adc_valsum/(times-2);						//����ƽ��ֵ
}

uint16_t jd_continuous[60]={0x00};
void sensor_data_filter()
{
//	uint32_t *result_avg;
//	uint64_t jd_data=0,jd_data_num=0;
//	sensor_ass_data(sensor_data1,sensor_data2,sensor_data3,SENSOR_LEN_MAX);
	
//	for(int t=0;t<80;t++)
//	{
////		rt_thread_delay(1);
//		sensor_move_Front(sensor_data1,sensor_data2,sensor_data3,SENSOR_LEN_MAX);
//	}
//	sensor_move_Front_jd(sensor_data3,SENSOR_LEN_MAX);
//	sensor_move_Front(sensor_data1,sensor_data2,sensor_data3,SENSOR_LEN_MAX);
//	sensor_mode_data(sensor_data1,sensor_data2,sensor_data3,SENSOR_LEN_MAX);
	
//	bubblesort(sensor_data1,sensor_data2,sensor_data3,NULL,SENSOR_LEN_MAX);
//	result_avg=averaging(sensor_data1,sensor_data2,sensor_data3,NULL,SENSOR_LEN_MAX);
	uint16_t jd_count1=0,jd_count2=0;
	for(int t=0;t<100;t++)
	{
		uint16_t jd_buffer=0;
		rt_thread_delay(1);
		jd_buffer=adc1_ordinary_valuetab[0];
		
		if((jd_continuous[0]-data_scpoe[GROUNDING].data_scope_par.data_scope_max<jd_buffer)&&(jd_buffer<jd_continuous[0]+data_scpoe[GROUNDING].data_scope_par.data_scope_max))
		{
			jd_count1++;
			jd_continuous[0]=jd_buffer;
			if(jd_count1>data_scpoe[TRANSPOSITION].data_scope_par.data_scope_max)
			{
				data_scpoe[GROUNDING].data=0x01;
				break;
			}
		}
		else
		{
			jd_count2++;
			jd_continuous[0]=jd_buffer;
			if(jd_count2>data_scpoe[TRANSPOSITION].data_scope_par.data_scope_min)
			{
				data_scpoe[GROUNDING].data=0x02;
				break;
			}
		}
		
//		if((adc1_ordinary_valuetab[0]-60<jd_continuous[t])&&(jd_continuous[t]<adc1_ordinary_valuetab[0]+60))
//		{
//			jd_count1++;
//			if(jd_count1>50)
//			{
//				data_scpoe[GROUNDING].data=0x01;
//				break;
//			}
//			
//		}
//		else
//		{
//			jd_count2++;
//			if(jd_count2>50)
//			{
//				data_scpoe[GROUNDING].data=0x02;
//				break;
//			}
////			data_scpoe[GROUNDING].data=0x02;
////			rt_hw_us_delay(1);
//			
//			
//		}
//		jd_continuous[t]=adc1_ordinary_valuetab[0];
	}
	
	
	data_scpoe[TEMPERATURE].data =Get_Tem_Data();//result_avg[0];
	
	read_modbus_buffer[0]=data_scpoe[TEMPERATURE].data>>8;
	read_modbus_buffer[1]=data_scpoe[TEMPERATURE].data;
	
	if(cpcp_thread_flag==CP_Sampling_Loop)//�ж��߳�cpcp�����Ƿ��
	{
		
		
		
		CP_Voltage=get_adcval_average(10);//result_avg[1];
		if((CP_Voltage < data_scpoe[CP12].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP12].data_scope_par.data_scope_min))
		{
			CP_Voltage=CP_Voltage+50;
		}
		read_modbus_buffer[4]=CP_Voltage>>8;
		read_modbus_buffer[5]=CP_Voltage;
	}
	
//	data_scpoe[GROUNDING].data=adc1_ordinary_valuetab[0];
	read_modbus_buffer[2]=data_scpoe[GROUNDING].data>>8;
	read_modbus_buffer[3]=data_scpoe[GROUNDING].data;
//	rt_kprintf("Tem=%d CP=%d jD=%d\n",data_scpoe[TEMPERATURE].data,CP_Voltage,data_scpoe[GROUNDING].data);

	
}




//void adc_init()
//{
////	adc_resolution_set(ADC2,ADC_RESOLUTION_12B);
////	adc_ordinary_channel_set(ADC2,ADC_CHANNEL_3,1,ADC_SAMPLETIME_12_5);
//	
//  /* �����豸 */
//	adc1_dev = (rt_adc_device_t)rt_device_find(ADC1_DEV_NAME);
//	adc2_dev = (rt_adc_device_t)rt_device_find(ADC2_DEV_NAME);
//	adc3_dev = (rt_adc_device_t)rt_device_find(ADC3_DEV_NAME);

//  /* ʹ���豸 */
//  rt_adc_enable(adc1_dev, ADC1_DEV_CHANNEL10);								//CPCP
//	rt_adc_enable(adc1_dev, ADC1_DEV_CHANNEL16);								//�ڲ��¶�
//	rt_adc_enable(adc2_dev, ADC2_DEV_CHANNEL13);								//�ο�
//	rt_adc_enable(adc2_dev, ADC2_DEV_CHANNEL12);									//�¶�
//	rt_adc_enable(adc3_dev, ADC2_DEV_CHANNEL3);									//�ӵ�

////	adc_ordinary_channel_set(ADC2,ADC_CHANNEL_3,2,ADC_SAMPLETIME_2_5);

////	rt_adc_enable(adc3_dev, 3);									//�ӵ�	
//	

//////  /* ��ȡ����ֵ */
////  value = rt_adc_read(adc1_dev, ADC1_DEV_CHANNEL10);
////  rt_kprintf("the value is :%d \n", value);

//////  /* ת��Ϊ��Ӧ��ѹֵ */
////  vol = value * REFER_VOLTAGE / CONVERT_BITS;
////  rt_kprintf("the voltage is :%d.%02d \n", vol / 100, vol % 100);

//  /* �ر�ͨ�� */
////  rt_adc_disable(adc1_dev, ADC1_DEV_CHANNEL10);

//}





/**
  * @brief  gpio configuration.
  * @param  none
  * @retval none
  */
//static void gpio_config(void)
//{
//  gpio_init_type gpio_initstructure;
//  crm_periph_clock_enable(CRM_GPIOA_PERIPH_CLOCK, TRUE);

//  gpio_default_para_init(&gpio_initstructure);

//  /* config adc pin as analog input mode */
//  gpio_initstructure.gpio_mode = GPIO_MODE_ANALOG;
//  gpio_initstructure.gpio_pins = GPIO_PINS_4 | GPIO_PINS_5 | GPIO_PINS_6;
//  gpio_init(GPIOA, &gpio_initstructure);
//}


uint16_t adc1_ordinary_valuetab[3] = {0};
uint16_t dma_trans_complete_flag = 0;
uint16_t adc1_overflow_flag = 0;
/**
  * @brief  dma configuration.
  * @param  none
  * @retval none
  */
static void dma_config(void)
{
  dma_init_type dma_init_struct;
  crm_periph_clock_enable(CRM_DMA1_PERIPH_CLOCK, TRUE);
  nvic_irq_enable(DMA1_Channel1_IRQn, 0, 0);

  dma_reset(DMA1_CHANNEL1);
  dma_default_para_init(&dma_init_struct);
  dma_init_struct.buffer_size = 3;
  dma_init_struct.direction = DMA_DIR_PERIPHERAL_TO_MEMORY;
  dma_init_struct.memory_base_addr = (uint32_t)adc1_ordinary_valuetab;
  dma_init_struct.memory_data_width = DMA_MEMORY_DATA_WIDTH_HALFWORD;
  dma_init_struct.memory_inc_enable = TRUE;
  dma_init_struct.peripheral_base_addr = (uint32_t)&(ADC1->odt);
  dma_init_struct.peripheral_data_width = DMA_PERIPHERAL_DATA_WIDTH_HALFWORD;
  dma_init_struct.peripheral_inc_enable = FALSE;
  dma_init_struct.priority = DMA_PRIORITY_HIGH;
  dma_init_struct.loop_mode_enable = TRUE;
  dma_init(DMA1_CHANNEL1, &dma_init_struct);

  dmamux_enable(DMA1, TRUE);
  dmamux_init(DMA1MUX_CHANNEL1, DMAMUX_DMAREQ_ID_ADC1);

  /* enable dma transfer complete interrupt */
  dma_interrupt_enable(DMA1_CHANNEL1, DMA_FDT_INT, TRUE);
  dma_channel_enable(DMA1_CHANNEL1, TRUE);
}

/**
  * @brief  adc configuration.
  * @param  none
  * @retval none
  */
static void adc_config(void)
{
  adc_common_config_type adc_common_struct;
  adc_base_config_type adc_base_struct;
  crm_periph_clock_enable(CRM_ADC1_PERIPH_CLOCK, TRUE);
  nvic_irq_enable(ADC1_2_3_IRQn, 0, 0);

  adc_common_default_para_init(&adc_common_struct);

  /* config combine mode */
  adc_common_struct.combine_mode = ADC_INDEPENDENT_MODE;

  /* config division,adcclk is division by hclk */
  adc_common_struct.div = ADC_HCLK_DIV_6;

  /* config common dma mode,it's not useful in independent mode */
  adc_common_struct.common_dma_mode = ADC_COMMON_DMAMODE_DISABLE;

  /* config common dma request repeat */
  adc_common_struct.common_dma_request_repeat_state = FALSE;

  /* config adjacent adc sampling interval,it's useful for ordinary shifting mode */
  adc_common_struct.sampling_interval = ADC_SAMPLING_INTERVAL_5CYCLES;

  /* config inner temperature sensor and vintrv */
  adc_common_struct.tempervintrv_state = FALSE;

  /* config voltage battery */
  adc_common_struct.vbat_state = FALSE;
  adc_common_config(&adc_common_struct);

  adc_base_default_para_init(&adc_base_struct);

  adc_base_struct.sequence_mode = TRUE;
  adc_base_struct.repeat_mode = TRUE;
  adc_base_struct.data_align = ADC_RIGHT_ALIGNMENT;
  adc_base_struct.ordinary_channel_length = 3;
  adc_base_config(ADC1, &adc_base_struct);
  adc_resolution_set(ADC1, ADC_RESOLUTION_12B);

  /* config ordinary channel */
  adc_ordinary_channel_set(ADC1, ADC_CHANNEL_3, 1, ADC_SAMPLETIME_247_5);
  adc_ordinary_channel_set(ADC1, ADC_CHANNEL_10, 2, ADC_SAMPLETIME_247_5);
  adc_ordinary_channel_set(ADC1, ADC_CHANNEL_12, 3, ADC_SAMPLETIME_247_5);

  /* config ordinary trigger source and trigger edge */
  adc_ordinary_conversion_trigger_set(ADC1, ADC_ORDINARY_TRIG_TMR1CH1, ADC_ORDINARY_TRIG_EDGE_NONE);

  /* config dma mode,it's not useful when common dma mode is use */
  adc_dma_mode_enable(ADC1, TRUE);

  /* config dma request repeat,it's not useful when common dma mode is use */
  adc_dma_request_repeat_enable(ADC1, TRUE);

  /* enable adc overflow interrupt */
  adc_interrupt_enable(ADC1, ADC_OCCO_INT, TRUE);

  /* adc enable */
  adc_enable(ADC1, TRUE);
  while(adc_flag_get(ADC1, ADC_RDY_FLAG) == RESET);

  /* adc calibration */
  adc_calibration_init(ADC1);
  while(adc_calibration_init_status_get(ADC1));
  adc_calibration_start(ADC1);
  while(adc_calibration_status_get(ADC1));
	
	adc_ordinary_software_trigger_enable(ADC1, TRUE);
}
void adc_init()
{
	nvic_priority_group_config(NVIC_PRIORITY_GROUP_4);
	dma_config();
	adc_config();
}



