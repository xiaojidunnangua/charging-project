#include <rtthread.h>
#include <rtdevice.h>
#include <spi.h>
#include <drv_spi.h>
#include "spi_flash_sfud.h"
#include "at32f435_437_conf.h"
#include "HS_main.h"
#include "HS_RS16.h"

#define SPI_BUS_NAME             "spi4"
#define SPI_RS16_DEVICE_NAME     "spi40"
 
static struct rt_spi_device hs_spi_dev_rs16; 
static struct at32_spi_cs  spi_cs;    
 
int rs16_init(void)
{
	rt_err_t res;
	spi_cs.gpio_x = GPIOE;
	spi_cs.gpio_pin = 4;
	rt_pin_mode(spi_cs.gpio_pin, PIN_MODE_OUTPUT);    /* ����Ƭѡ�ܽ�ģʽΪ��� */
 
	rt_pin_write(spi_cs.gpio_pin, PIN_HIGH);
	res = rt_spi_bus_attach_device(&hs_spi_dev_rs16, SPI_RS16_DEVICE_NAME, SPI_BUS_NAME, (void*)&spi_cs);
	if (res != RT_EOK)
	{
		
//        rt_kprintf("rt_spi_bus_attach_device!\r\n");

			return res;
	}
	hs_spi_dev_rs16.bus->owner = &hs_spi_dev_rs16;   
	{
			struct rt_spi_configuration cfg;
			cfg.data_width = 8;//16
			cfg.mode =  RT_SPI_MODE_0 | RT_SPI_MSB ;//| RT_SPI_NO_CS;//RT_SPI_MODE_1 | RT_SPI_MSB
			cfg.max_hz = 2 * 1000 *1000; /* 40M,SPI max 42MHz, 3-wire spi 40*1000*1000*/
			rt_spi_configure(&hs_spi_dev_rs16, &(cfg));
	
	}
	return RT_EOK;
 
}




rt_err_t hs_spi_dev_rs16_write_data(const rt_uint8_t data,const int lendth)
{
	rt_size_t len;
	len = rt_spi_send(&hs_spi_dev_rs16, &data, lendth);

	if (len != lendth)
	{
			return -RT_ERROR;
	}
	else       
	{
			return RT_EOK;
	}
}
rt_err_t hs_spi_dev_rs16_read_data( rt_uint8_t data,const int lendth)
{
rt_size_t len;
len = rt_spi_recv(&hs_spi_dev_rs16,&data, lendth);
		if (len != lendth)
	{
			return -RT_ERROR;
	}
	else       
	{
			return RT_EOK;
	}
}




void SPI1_Send_Byte(uint8_t dat)
{
	while(spi_i2s_flag_get(SPI4, SPI_I2S_TDBE_FLAG) == RESET)	
	;
		 SPI4->dt = dat;         
		rt_hw_us_delay(10);
}

uint8_t FM25640C_Read_Byte(uint32_t addr)
{
	uint32_t rddata;//,tmpdata=FM25640C_READ;
	W5500_SCS0;
//		rt_hw_us_delay(2);
	SPI1_Send_Byte(0x03);
	SPI1_Send_Byte(addr>>8);
	SPI1_Send_Byte(addr& 0xff);
//		rt_hw_us_delay(1000);
	rddata =  SPI4->dt;
	SPI1_Send_Byte(0xff);
//		rt_hw_us_delay(5000);
	while(spi_i2s_flag_get(SPI4, SPI_I2S_RDBF_FLAG) == RESET);
	rddata =  SPI4->dt;
//		rt_hw_us_delay(200);
//		rddata =  SPI4->dt;//spi_i2s_data_receive(SPI4);

//		rddata =  SPI4->dt;

//		rt_hw_us_delay(2);
	W5500_SCS1;

	return (uint8_t)rddata;
}
void FM25640C_Write_Byte(uint32_t addr, uint8_t wrdata)
{
//		  uint32_t tmpdata=FM25640C_WRITE;
	W5500_SCS0;
	SPI1_Send_Byte(FM25640C_WREN);    //��:ʹ��д����//Write Enable
	W5500_SCS1;
	 rt_hw_us_delay(2);
	W5500_SCS0;
	SPI1_Send_Byte(0x02);
	SPI1_Send_Byte(addr>>8);
	SPI1_Send_Byte(addr & 0xff);
	SPI1_Send_Byte(wrdata);
	W5500_SCS1;

	rt_hw_us_delay(2);
}

void FM25640C_Write(void)
{
//		  uint32_t tmpdata=FM25640C_WRITE;

//			WDT_Reset();
	W5500_SCS0;
	SPI1_Send_Byte(FM25640C_WREN);    //��:ʹ��д����//Write Enable
	W5500_SCS1;
//			WDT_Reset();
	W5500_SCS0;
	SPI1_Send_Byte(0x01);
	SPI1_Send_Byte(0);
	W5500_SCS1;
//			WDT_Reset();
}
uint8_t FM25640C_Read(void)
{
	uint32_t rddata;//,tmpdata=FM25640C_READ; 
	W5500_SCS0;
	SPI1_Send_Byte(0x05);
	SPI1_Send_Byte(0xff);
//			clr_SPIF;
	rddata = SPI4->dt;//SPDR;
	W5500_SCS1;
//			WDT_Reset();
	return (uint8_t)rddata;
}		



uint8_t *rs16_read_string(uint32_t addr,uint8_t *dest,uint16_t length)
{
	uint16_t i;
	for(i=0;i<length;i++)
	{
		*dest = FM25640C_Read_Byte(addr);
		dest ++;
		addr= ((addr>>8)+1)<<8;
//				WDT_Reset();
	}
	return dest;
}
void rs16_write_string(uint32_t addr,uint8_t *dest,uint16_t length)
{
	uint16_t i;
	uint8_t wrdata;
	for(i=0;i<length;i++)
	{
		wrdata = *dest;
		FM25640C_Write_Byte(addr, wrdata);
		dest ++;
		addr= ((addr>>8)+1)<<8;
//				WDT_Reset();
	}
}
uint8_t *FRAM_read1(uint32_t addr,uint8_t *dest,uint16_t length)
{
	uint16_t i;
	for(i=0;i<length;i++)
	{
		*dest = FM25640C_Read_Byte(addr+1);
		dest ++;
		addr= ((addr>>8)+1)<<8;
//				WDT_Reset();
	}
	return dest;
}
void FRAM_WRITE1(uint32_t addr,uint8_t *dest,uint16_t length)
{
	uint16_t i;
	uint8_t wrdata;
	for(i=0;i<length;i++)
	{
		wrdata = *dest;
		FM25640C_Write_Byte(addr+1, wrdata);
		dest ++;
		addr= ((addr>>8)+1)<<8;
//				WDT_Reset();
	}
}
