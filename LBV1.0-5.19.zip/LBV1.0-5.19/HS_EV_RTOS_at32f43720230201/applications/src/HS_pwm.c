#include <rtthread.h>
#include <rtdevice.h>
#include "HS_pwm.h"
#include "HS_#define.h"
#include "HS_main.h"


struct rt_device_pwm *pwm3_dev;      /* PWM�豸��� */
struct rt_device_pwm *pwm12_dev;      /* PWM�豸��� */
uint32_t pwm3_period=1000000,pwm12_period=1250;
uint32_t pwm3_pulse=35,pwm12_pulse=16;

void pwm_init()
{
	/* �����豸 */
	pwm3_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
	if (pwm3_dev == RT_NULL)
	{
			rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_DEV_NAME);
	}
	pwm12_dev = (struct rt_device_pwm *)rt_device_find(PWM_WS2815_DEV_NAME);
	if (pwm12_dev == RT_NULL)
	{
			rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_WS2815_DEV_NAME);
	}
	

	/* ����PWM���ں�������� */
	rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
//	rt_pwm_set(pwm12_dev, PWM_WS2815_DEV_CHANNEL, pwm12_period, 375);
	/*�ر��豸*/
//	rt_pwm_disable(pwm3_dev,PWM_DEV_CHANNEL);
	rt_pwm_enable(pwm3_dev,PWM_DEV_CHANNEL);
//	rt_pwm_enable(pwm12_dev, PWM_WS2815_DEV_CHANNEL);
}


