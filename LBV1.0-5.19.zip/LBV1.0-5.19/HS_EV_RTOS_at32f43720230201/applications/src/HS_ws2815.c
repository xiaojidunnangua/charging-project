#include <rtthread.h>
#include <rtdevice.h>
#include "HS_ws2815.h"
#include "HS_main.h"
#include "drv_spi.h"
#include "HS_rgb_con.h"
#include "HS_Dwin.h"





spi_init_type spi_init_struct;

uint8_t rgb_data[120];
 


RGB_PixelBuffer pixelBuffer;


void ws2812_init(void)
{
        /*Set GPIO*/
  gpio_init_type gpio_initstructure;
  spi_init_type spi_init_struct;
  dma_init_type dma_init_struct;
  crm_periph_clock_enable(CRM_SPI3_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);
  crm_periph_clock_enable(CRM_DMA1_PERIPH_CLOCK, TRUE);
        
  /* mosi */
  gpio_initstructure.gpio_out_type       = GPIO_OUTPUT_PUSH_PULL;
  gpio_initstructure.gpio_mode           = GPIO_MODE_MUX;
  gpio_initstructure.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER;
  gpio_initstructure.gpio_pull           = GPIO_PULL_UP;
  gpio_initstructure.gpio_pins           = GPIO_PINS_12;
  gpio_init(GPIOC, &gpio_initstructure);
  gpio_pin_mux_config(GPIOC, GPIO_PINS_SOURCE12, GPIO_MUX_6);
        
  dma_reset(DMA1_CHANNEL3);
  dma_default_para_init(&dma_init_struct);
  dma_init_struct.buffer_size = 0;
  dma_init_struct.direction = DMA_DIR_MEMORY_TO_PERIPHERAL ;
  dma_init_struct.memory_base_addr = (uint32_t)&pixelBuffer;
  dma_init_struct.memory_data_width = DMA_MEMORY_DATA_WIDTH_BYTE;
  dma_init_struct.memory_inc_enable = TRUE;
  dma_init_struct.peripheral_base_addr = (uint32_t)(&SPI3->dt);
  dma_init_struct.peripheral_data_width = DMA_PERIPHERAL_DATA_WIDTH_BYTE;
  dma_init_struct.peripheral_inc_enable = FALSE;
  dma_init_struct.priority = DMA_PRIORITY_VERY_HIGH;
  dma_init_struct.loop_mode_enable = FALSE;
  dma_init(DMA1_CHANNEL3, &dma_init_struct);
  dmamux_enable(DMA1, TRUE);
  dmamux_init(DMA1MUX_CHANNEL3, DMAMUX_DMAREQ_ID_SPI3_TX);
	
  spi_i2s_dma_transmitter_enable(SPI3, TRUE);
  dma_channel_enable(DMA1_CHANNEL3, TRUE);
  while(dma_flag_get(DMA1_FDT3_FLAG) != RESET);
  dma_flag_clear(DMA1_FDT3_FLAG);
  dma_channel_enable(DMA1_CHANNEL3, FALSE);
  spi_i2s_dma_transmitter_enable(SPI3, TRUE);
	
  spi_default_para_init(&spi_init_struct);
  spi_init_struct.transmission_mode = SPI_TRANSMIT_HALF_DUPLEX_TX;
  spi_init_struct.master_slave_mode = SPI_MODE_MASTER;
  spi_init_struct.mclk_freq_division = SPI_MCLK_DIV_32;
  spi_init_struct.first_bit_transmission = SPI_FIRST_BIT_MSB;
  spi_init_struct.frame_bit_num = SPI_FRAME_8BIT;
  spi_init_struct.clock_polarity = SPI_CLOCK_POLARITY_LOW;
  spi_init_struct.clock_phase = SPI_CLOCK_PHASE_1EDGE;
  spi_init_struct.cs_mode_selection = SPI_CS_SOFTWARE_MODE;
  spi_init(SPI3, &spi_init_struct);
//  spi_crc_polynomial_set(SPI3, 7);
  spi_crc_enable(SPI3, TRUE);
  spi_software_cs_internal_level_set(SPI3,SPI_SWCS_INTERNAL_LEVEL_HIGHT);//����ģʽ SPI_CS_SOFTWARE_MODE SPI_SWCS_INTERNAL_LEVEL_HIGHT
  spi_enable(SPI3, TRUE);
//	WS281x_Show();
  WS281x_CloseAll();  //�ر�ȫ���ĵ�
//  rt_thread_delay(100); //�ر�ȫ���ĵ���Ҫһ����ʱ��

}

//������ɫ��ʾ�����趨��ɫ����ɫ���ݴ��뻺��ֻ��ִ�иú�����Ż������ʾ��
void WS281x_Show(void)
{
	// ���DMA����ͨ�����Ƿ�������
	while(dma_data_number_get(DMA1_CHANNEL3)){};
	dma_channel_enable(DMA1_CHANNEL3, FALSE);
	dma_data_number_set(DMA1_CHANNEL3, PIXEL_NUM * GRB);
	dma_channel_enable(DMA1_CHANNEL3, TRUE);
	while(dma_data_number_get(DMA1_CHANNEL3)){};
	__NOP();
	__NOP();   
	__NOP();
	SPI3->dt = 0x00;
	while(dma_flag_get(DMA1_FDT3_FLAG) == RESET){};
	dma_flag_clear(DMA1_FDT3_FLAG);
	dma_channel_enable(DMA1_CHANNEL3, FALSE);
}
//�������֮�����Թ�˼�ײ���ƺ����ˣ�Ϊ�˷�����LED����Ŀɿ�������Ҫ����һ��������pixelBuffer[PIXEL_NUM][24]\
ͨ���趨��ɫ���������뻺������ͨ�����º��������ݴ��뵽LED�����ϡ�
//�ر����е���
void WS281x_CloseAll(void)
{
  uint16_t i;
  uint8_t j;
  
  for(i = 0; i < PIXEL_NUM; ++i)
  {
    for(j = 0; j < 24; ++j)
    {
      pixelBuffer.All_Buffer[i][j] = WS_LOW;
    }
  }
  WS281x_Show(); 
}


uint32_t WS281x_Color(uint8_t red, uint8_t green, uint8_t blue)
{
  return red << 16 | green << 8 | blue;
}




void WS281x_SetPixelColor(uint16_t n, uint32_t GRBColor)
{
  uint8_t i=0;
  if(n < PIXEL_NUM)
  {
    for(i = 0; i < GRB; i++)
    {
      pixelBuffer.All_Buffer[n][i] = ((GRBColor << i) & 0x800000) ? WS_HIGH : WS_LOW;
		}
  }
}





void WS281x_SetPixelRGB(uint16_t n ,uint8_t red, uint8_t green, uint8_t blue)
{
  uint8_t i;
  
  if(n < PIXEL_NUM)
  {
    for(i = 0; i < GRB; ++i)
    {
      pixelBuffer.All_Buffer[n][i] = (((WS281x_Color(red,green,blue) << i) & 0X800000) ? WS_HIGH : WS_LOW);
    }
  }
}

// Input a value 0 to 255 to get a color value.
// The colours are a transition r - g - b - back to r.
uint32_t WS281x_Wheel(uint8_t wheelPos) {
  wheelPos = 255 - wheelPos;
  if(wheelPos < 85) {
    return WS281x_Color(255 - wheelPos * 3, 0, wheelPos * 3);
  }
  if(wheelPos < 170) {
    wheelPos -= 85;
    return WS281x_Color(0, wheelPos * 3, 255 - wheelPos * 3);
  }
  wheelPos -= 170;
  return WS281x_Color(wheelPos * 3, 255 - wheelPos * 3, 0);
}

// Fill the dots one after the other with a color
void WS281x_ColorWipe(uint32_t c, uint8_t wait) {
  for(uint16_t i=0; i<PIXEL_NUM; i++) {
    WS281x_SetPixelColor(i, c);
    WS281x_Show();
    Delay_ms(wait);
		
  }
	
}











void WS281x_Rainbow(uint8_t wait) {
  uint16_t i, j;

  for(j=0; j<256; j++) {
    for(i=0; i<PIXEL_NUM; i++) {
      WS281x_SetPixelColor(i, WS281x_Wheel((i+j) & 255));
    }
    WS281x_Show();
    Delay_ms(wait);
  }
}

// Slightly different, this makes the rainbow equally distributed throughout
void WS281x_RainbowCycle(uint8_t wait) {
  uint16_t i, j;

  for(j=0; j<256*5; j++) { // 5 cycles of all colors on wheel
    for(i=0; i< PIXEL_NUM; i++) {
      WS281x_SetPixelColor(i,WS281x_Wheel(((i * 256 / PIXEL_NUM) + j) & 255));
    }
    WS281x_Show();
    Delay_ms(wait);
  }
}

//Theatre-style crawling lights.
void WS281x_TheaterChase(uint32_t c, uint8_t wait) {
  for (int j=0; j<10; j++) {  //do 10 cycles of chasing
    for (int q=0; q < 3; q++) {
      for (uint16_t i=0; i < PIXEL_NUM; i=i+3) {
        WS281x_SetPixelColor(i+q, c);    //turn every third pixel on
      }
      WS281x_Show();

      Delay_ms(wait);

      for (uint16_t i=0; i < PIXEL_NUM; i=i+3) {
        WS281x_SetPixelColor(i+q, 0);        //turn every third pixel off
      }
    }
  }
}

//Theatre-style crawling lights with rainbow effect
void WS281x_TheaterChaseRainbow(uint8_t wait) {
  for (int j=0; j < 256; j++) {     // cycle all 256 colors in the wheel
    for (int q=0; q < 3; q++) {
      for (uint16_t i=0; i < PIXEL_NUM; i=i+3) {
        WS281x_SetPixelColor(i+q, WS281x_Wheel( (i+j) % 255));    //turn every third pixel on
      }
      WS281x_Show();

      Delay_ms(wait);

      for (uint16_t i=0; i < PIXEL_NUM; i=i+3) {
        WS281x_SetPixelColor(i+q, 0);        //turn every third pixel off
      }
    }
  }
}


// Slightly different, this makes the rainbow equally distributed throughout
void WS2812_RainbowRotate(uint16_t wait) {
	uint16_t i, j;

	for (j = 0; j < 256 * 5; j++) { // 5 cycles of all colors on wheel
		for (i = 0; i < PIXEL_NUM; i++) {
			WS281x_SetPixelColor(i,  WS281x_Wheel(((i * 256 / PIXEL_NUM) + j) & 255));
		}
		WS281x_Show();
    Delay_ms(wait);
	}
}

#if SPI_DMA_IRQ
/* ISP for SPI1_TX DMA done. */
void DMA1_Channel2_IRQHandler(void)
{
	if (tos_knl_is_running())
  {
    tos_knl_irq_enter();
    if(dma_flag_get(DMA1_FDT2_FLAG) != RESET)
    {
        dma_channel_enable(DMA1_CHANNEL2, FALSE);
        app_dma_xfer_done = true;
        dma_flag_clear(DMA1_FDT2_FLAG);
    }
    tos_knl_irq_leave();
  }
}
#endif

void RGB_DEBUG_TEST(void)
{
	int i,j;
	for(i=0;i<3;i++)
	{
		
		for(j=0;j<8;j++)
		{
			if(i==0)
			{
				WS281x_ColorWipe(WS281x_Color(255, 0, 255), 1); // Red
			}
			else if(i==1)
			{
				WS281x_ColorWipe(WS281x_Color(0, 255, 255), 1); // Green
			}
			else
			{
				WS281x_ColorWipe(WS281x_Color(255, 255, 0), 1); // Blue
			}
		}
	}
		for(i=0;i<3;i++)
	{
		
		for(j=0;j<8;j++)
		{
			if(i==0)
			{
				WS281x_ColorWipe(WS281x_Color(255, 0, 0), 10); // Red
			}
			else if(i==1)
			{
				WS281x_ColorWipe(WS281x_Color(0, 255, 0), 10); // Green
			}
			else
			{
				WS281x_ColorWipe(WS281x_Color(0, 0, 255), 10); // Blue
			}
		}
	}
		for(i=0;i<3;i++)
	{
		
		for(j=0;j<8;j++)
		{
			if(i==0)
			{
				WS281x_ColorWipe(WS281x_Color(255, 0, 0), 10); // Red
				Delay_ms(100);
				WS281x_ColorWipe(WS281x_Color(0, 255, 0), 10); // Green
			}
			else if(i==1)
			{
				WS281x_ColorWipe(WS281x_Color(0, 255, 0), 10); // Green
				Delay_ms(100);
				WS281x_ColorWipe(WS281x_Color(255, 0, 0), 10); // Red
			}
			else
			{
				WS281x_ColorWipe(WS281x_Color(0, 0, 255), 10); // Blue
				Delay_ms(100);
				WS281x_ColorWipe(WS281x_Color(0, 255, 0), 10); // Green
				Delay_ms(100);
				WS281x_ColorWipe(WS281x_Color(0, 0, 255), 10); // Blue
				Delay_ms(100);
				WS281x_ColorWipe(WS281x_Color(255, 0, 0), 10); // Red
			}
		}
	}
	WS2812_RainbowRotate(2);
        // Some example procedures showing how to display to the pixels:
	WS281x_ColorWipe(WS281x_Color(255, 0, 0), 10); // Red
	WS281x_ColorWipe(WS281x_Color(0, 255, 0), 10); // Green
	WS281x_ColorWipe(WS281x_Color(0, 0, 255), 10); // Blue


	WS281x_TheaterChase(WS281x_Color(127, 127, 127), 10); // White
	WS281x_TheaterChase(WS281x_Color(127, 0, 0), 10); // Red
	WS281x_TheaterChase(WS281x_Color(0, 0, 127), 10); // Blue

	WS281x_Rainbow(10);
	WS281x_RainbowCycle(10);
	WS281x_TheaterChaseRainbow(10);

}




void RGB_RED()
{
	
	WS281x_ColorWipe(WS281x_Color(255, 0, 0), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(255, 0, 0), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(255, 0, 0), 0); // Red
}


void RGB_GER()
{
	WS281x_ColorWipe(WS281x_Color(0, 255, 0), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(0, 255, 0), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(0, 255, 0), 0); // Red
}

void RGB_BLU()
{
	WS281x_ColorWipe(WS281x_Color(0, 0, 255), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(0, 0, 255), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(0, 0, 255), 0); // Red
}

void RGB_YEL()
{
	WS281x_ColorWipe(WS281x_Color(255, 255, 0), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(255, 255, 0), 0); // Red
//	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(255, 255, 0), 0); // Red
}




void RGB_WAT()
{
	WS281x_ColorWipe(WS281x_Color(0, 255, 255), 0); // Red
	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(0, 255, 255), 0); // Red
	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(0, 255, 255), 0); // Red
}

void RGB_WHITE()
{
	WS281x_ColorWipe(WS281x_Color(255, 255, 255), 0); // Red
	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(255, 255, 255), 0); // Red
	rt_thread_delay(50);
	WS281x_ColorWipe(WS281x_Color(255, 255, 255), 0); // Red
}




int emergency_callback(uint8_t light_flag,uint8_t lcd_flag)
{
	if(light_flag==0x01)
	{

//		rt_thread_delay(50);
		RGB_RED();
		dwin_guzhangxinxi();
		if(Errors_Data&0x0001)
		{
			dwin_jitinggz();
			
		}
		if(Errors_Data&0x0004)
		{
			dwin_dianliugz();
			
		}
		if(Errors_Data&0x0008)
		{
			dwin_qitagz();

		}
		if(Errors_Data&0x0010)
		{
			dwin_qitagz();

		}
		if(Errors_Data&0x0020)
		{
			dwin_jiedigz();

		}
		if(Errors_Data&0x0040)
		{
			dwin_wendugz();
		}
		if(Errors_Data&0x0080)
		{
			dwin_loudiangz();
		}
		if(Errors_Data&0x2000)
		{
			dwin_wangluogz();
		}
		if(Errors_Data&0x0800)
		{
			dwin_cpgz();
		}
//		switch(lcd_flag)
//		{
//			case 0x01:
//				dwin_wangluoguzhang();//������ϴ���
//				break;
//			case 0x02:
//				dwin_wenduguzhang();//�¶ȹ��ϴ���
//				break;
//			case 0x03:
//				dwin_jiediguzhang();//�ӵع��ϴ���
//				break;
//			case 0x04:
//				dwin_jitingguzhang();//��ͣ���ϴ���
//				break;
//			case 0x05:
//				dwin_dianliuguzhang();//�������ϴ���
//				break;
//			case 0x06:
//				dwin_luodianguzhang();//©����ϴ���
//				break;
//			case 0x07:
//				dwin_cpguzhang();//CP���ϴ���
//				break;
//			case 0x08:
//				dwin_cpguzhang();//��ѹ���ϴ���
//				break;
//		}
	}
	else
	{
		if((Errors_Data& 0xBFFF) == 0)
		{
			switch(lcd_flag)
			{
				case 0x01:
					dwin_diyiye(qr_code,program_version);

//					rt_thread_delay(100);
					if(PilotLamp_Flag==0x01)
					{
						RGB_BLU();
					}
					else if(PilotLamp_Flag==0x02)
					{
						RGB_GER();
					}
					else if(PilotLamp_Flag==0x03)
					{
						RGB_GER();
					}
//					dwin_diyiyeSZ(dj);
					break;
				case 0x02:
//					dwin_dierye();
					dwin_dieryeSZ(qr_code,cloud_jcsj.scdy,cloud_jcsj.scdl,cloud_jcsj.ljcdsjmin,cloud_jcsj.cdds);
//					RGB_GER();
					
					break;
				case 0x03:
//					dwin_disanye();
					dwin_disanyeSZ(cloud_jyjl.zdl,cloud_jcsj.ljcdsjmin,cloud_jyjl.xfje,cloud_public_para.zhye);		//�л���������
//					rt_thread_delay(100);
					if(PilotLamp_Flag==0x01)
					{
						RGB_BLU();
					}
					else if(PilotLamp_Flag==0x02)
					{
						RGB_GER();
					}
					break;
				case 0x04:
					dwin_diyiye(qr_code,program_version);

//					rt_thread_delay(100);
					if(PilotLamp_Flag==0x01)
					{
						RGB_BLU();
					}
					else if(PilotLamp_Flag==0x02)
					{
						RGB_GER();
					}
					else if(PilotLamp_Flag==0x03)
					{
						RGB_GER();
					}
					break;
			}
		}
		else
		{
			dwin_guzhangxinxi();
			if(Errors_Data&0x0001)
			{
				dwin_jitinggz();
			}
			if(Errors_Data&0x0004)
			{
				dwin_dianliugz();
			}
			if(Errors_Data&0x0008)
			{
				dwin_qitagz();
			}
			if(Errors_Data&0x0010)
			{
				dwin_qitagz();
			}
			if(Errors_Data&0x0020)
			{
				dwin_jiedigz();
			}
			if(Errors_Data&0x0040)
			{
				dwin_wendugz();
			}
			if(Errors_Data&0x0080)
			{
				dwin_loudiangz();
			}
			if(Errors_Data&0x2000)
			{
				dwin_wangluogz();
			}
			if(Errors_Data&0x0800)
			{
				dwin_cpgz();
			}
		}
		
	}
}



int emergency_light_lcd(callBackFunc fn,uint8_t light_flag,uint8_t lcd_flag)
{
	return fn(light_flag,lcd_flag);
}



