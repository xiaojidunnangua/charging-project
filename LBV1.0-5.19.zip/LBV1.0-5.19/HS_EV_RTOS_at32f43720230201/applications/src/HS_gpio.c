#include <rtdevice.h>
#include "HS_gpio.h"
#include "HS_#define.h"
#include "HS_main.h"
#include "HS_Dds3366d.h"
#include "HS_boot.h"



uint8_t sd_flag=1;
uint8_t scram_judge_flag=0;
uint8_t rgb=1;
void key1()
{
	if(rt_pin_read(PIN_KEY)==PIN_LOW)
	{
		rt_thread_delay(10);
		if(rt_pin_read(PIN_KEY)==PIN_LOW)
		{
			while(rt_pin_read(PIN_KEY)==PIN_LOW);
			if(sd_flag==1)
			{
				sd_flag=2;
//				stand_switch=0;
				rt_pin_write(PIN_4G_RST, PIN_HIGH);
				rt_pin_write(PIN_BEEP,PIN_HIGH);
				rt_thread_delay(500);
				rt_pin_write(PIN_4G_RST, PIN_LOW);
				rt_pin_write(PIN_BEEP,PIN_LOW);
				
			}
			else if(sd_flag==2)
			{
				sd_flag=1;
//				stand_switch=1;
				rt_pin_write(PIN_4G_RST, PIN_HIGH);
				rt_pin_write(PIN_BEEP,PIN_HIGH);
				rt_thread_delay(500);
				rt_pin_write(PIN_4G_RST, PIN_LOW);
				rt_pin_write(PIN_BEEP,PIN_LOW);
				

			}
			
		}
	}
}




void Gpio_init()
{
	rt_pin_mode(LED_B,PIN_MODE_OUTPUT);
	//�������ų�ʼ��
	rt_pin_mode(PIN_KEY,PIN_MODE_INPUT);
	//4G���ų�ʼ��
	rt_pin_mode(PIN_4G_RST, PIN_MODE_OUTPUT);
	//LED�����ų�ʼ��
	rt_pin_mode(PIN_LED, PIN_MODE_OUTPUT);
	//������λ���ų�ʼ��
	rt_pin_mode(PIN_BLE_RST,PIN_MODE_OUTPUT);
	//485�������ų�ʼ��
	rt_pin_mode(RS485_CONTROL,PIN_MODE_OUTPUT);
	//��ͣ������ʼ��
	rt_pin_mode(EMERGENCY_STOP,PIN_MODE_INPUT);
	//©���Լ��ʼ��
	rt_pin_mode(PIN_ELE_TEST,PIN_MODE_OUTPUT);
	//©��澯��ʼ��
	rt_pin_mode(PIN_ELE_REP,PIN_MODE_INPUT);
	//�̵������ų�ʼ��
	rt_pin_mode(RELAY_L, PIN_MODE_OUTPUT);
	rt_pin_mode(RELAY_N, PIN_MODE_OUTPUT);
	//�������������ų�ʼ��
	rt_pin_mode(PIN_BEEP,PIN_MODE_OUTPUT);
	//RC522����SPI���ų�ʼ��
	rt_pin_mode(RC522_CS, PIN_MODE_OUTPUT);				rt_pin_write(RC522_CS, PIN_LOW);
	rt_pin_mode(RC522_SCK, PIN_MODE_OUTPUT);			rt_pin_write(RC522_SCK, PIN_LOW);
	rt_pin_mode(RC522_MISO, PIN_MODE_INPUT);			
	rt_pin_mode(RC522_MOSI, PIN_MODE_OUTPUT);			rt_pin_write(RC522_MOSI, PIN_LOW);
	rt_pin_mode(RC522_RST, PIN_MODE_OUTPUT);			rt_pin_write(RC522_RST, PIN_HIGH);
	
	rt_pin_write(RELAY_L,PIN_LOW);
	rt_pin_write(RELAY_N,PIN_LOW);
	
	rt_pin_write(PIN_LED,PIN_LOW);
	rt_pin_write(PIN_BEEP,PIN_LOW);

	
	rt_pin_write(PIN_BLE_RST,PIN_LOW);
	rt_pin_write(PIN_4G_RST, PIN_HIGH);
	rt_thread_delay(500);
	rt_pin_write(PIN_4G_RST, PIN_LOW);
	rt_pin_write(PIN_BLE_RST,PIN_HIGH);
	
	
}

//INIT_DEVICE_EXPORT(init_gpio);