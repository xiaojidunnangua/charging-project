
#include "DSP2833x_Device.h"     // DSP2833x Headerfile Include File
#include "DSP2833x_Examples.h"   // DSP2833x Examples Include File

void delay_loop(Uint16 time)
{
    long      i;
    for (i = 0; i < time; i++) {} 
}