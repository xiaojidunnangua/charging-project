#include <rtthread.h>
#include <rtdevice.h>
#include "HS_#define.h"  
#include "HS_main.h"
#include "HS_BL0939.h"
#include <stdbool.h>
#include "string.h"
#include "HS_main.h"
#include "HS_arithmetic.h"

uint8_t bl_gather_flag=1;

uint32_t newdata1[BL_LEN_MAX],newdata2[BL_LEN_MAX],newdata3[BL_LEN_MAX],newdata4[BL_LEN_MAX];

uint16_t K_Electricity=1,B_Electricity=0,K_Voltage=1,B_Voltage=0;

void bl_ass_data(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint32_t arr4[],uint16_t length)
{
//	if(bl_gather_flag==1)
//	{
//		bl_gather_flag=0;
		for(int t=0;t<length;t++)
		{
			uint32_t *value=0x00;
			value=Bl_Read_Data();
			arr1[t]=value[0];
			arr2[t]=value[1];
			arr3[t]=value[2];
			arr4[t]=value[4];
		}
//	}
}

void bl_move_Front(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint32_t arr4[],uint16_t length)
{
	for (int i = 0; i < length; i++)
	{
		arr1[i] = arr1[i + 1];
		arr2[i] = arr2[i + 1];
		arr3[i] = arr3[i + 1];
		arr4[i] = arr4[i + 1];

	}
	uint32_t *value1;
	value1=Bl_Read_Data();
	arr1[BL_LEN_MAX-1]=value1[0];
	arr2[BL_LEN_MAX-1]=value1[1];
	arr3[BL_LEN_MAX-1]=value1[2];
	arr4[BL_LEN_MAX-1]=value1[4];
}

void bl_mode_data(uint32_t arr1[],uint32_t arr2[],uint32_t arr3[],uint32_t arr4[],uint16_t len)
{
	
	uint32_t max1=0,max2=0,max3=0,max4=0,number1,number2,number3,number4,mode1,mode2,mode3,mode4;
	
	for(int i=0;i<len;i++)
	{ 
		
		number1=1;
		number2=1;
		number3=1;
    for(int j=0;j<len;j++)
	  {
      if(arr1[j]==arr1[i])
		  {
			  number1++;
      } 
      if(max1<number1)
		  {
        max1=number1;
        mode1=arr1[i];
		  }
			
			if(arr2[j]==arr2[i])
		  {
			  number2++;
      } 
      if(max2<number2)
		  {
        max2=number2;
        mode2=arr2[i];
		  }
			
			if(arr3[j]==arr3[i])
		  {
			  number3++;
      } 
      if(max3<number3)
		  {
        max3=number3;
        mode3=arr3[i];
		  }
			
			if(arr4[j]==arr4[i])
		  {
			  number4++;
      } 
      if(max4<number4)
		  {
        max4=number4;
        mode4=arr4[i];
		  }
			
    }
  }
//	if(bl2_delay_flag==1)
//	{
//		bl2_delay_switch=0;

//		
		

	
	data_scpoe[OVERCURRENT].data=mode1;//-8;
	if(ChargeStartSwitch==1)
	{
		cloud_jcsj.scdl=K_Electricity*(data_scpoe[OVERCURRENT].data/100)+B_Electricity;
	}

//	rt_kprintf("I:%d\n",EffectiveElectricCurrent_Value);
	
	
	if(electrtc_energy_select==2)
	{
		Electric_Energy_Select=mode4;
//		rt_kprintf("D:%d\n",Electric_Energy_Select);
	}
	

	data_scpoe[LEAKAGE].data=mode2;
//	rt_kprintf("L:%d\n",mode2);	

	data_scpoe[OVERVOLTAGE].data=mode3;//+63;
	if(ChargeStartSwitch==1)
	{
		cloud_jcsj.scdy=K_Voltage*(data_scpoe[OVERVOLTAGE].data/10)+B_Voltage;
	}
	
//	rt_kprintf("V:%d\n",EffectiveVoltage_Value);
}




uint32_t *result_avg;
void bl_data_filter()
{
//	if(RelayChargeStartSwitch==1)
//	{
//		bl_ass_data(newdata1,newdata2,newdata3,newdata4,BL_LEN_MAX);
////		bl_move_Front(newdata1,newdata2,newdata3,newdata4,BL_LEN_MAX);
//		bubblesort(newdata1,newdata2,newdata3,newdata4,BL_LEN_MAX);
//		result_avg=averaging(newdata1,newdata2,newdata3,newdata4,BL_LEN_MAX);
	if(electrtc_energy_select==1)
	{
		uint32_t *bl_data;
		
		bl_data=Bl_Read_Data();
		
		data_scpoe[LEAKAGE].data=bl_data[1]/100;
		read_modbus_buffer[16]=bl_data[1]>>8;
		read_modbus_buffer[17]=bl_data[1];
		
		
		
		
		rt_thread_delay(200);
//		rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
		uint8_t control1=0x11,read_len1=4;
		uint8_t read_control_data1[4]={0x33,0x34,0x34,0x35};
		Dds3366_Read_V(ds3366_addr,control1,read_len1,read_control_data1);
		
		
		rt_thread_delay(200);

		uint8_t control2=0x11,read_len2=4;
		uint8_t read_control_data2[4]={0x33,0x33,0x33,0x33};
		Dds3366_Read_E(ds3366_addr,control2,read_len2,read_control_data2);

		
		

		rt_thread_delay(200);

		uint8_t control=0x11,read_len=4;
		uint8_t read_control_data[4]={0x33,0x34,0x35,0x35};
		Dds3366_Read_I(ds3366_addr,control,read_len,read_control_data);

		
		if(ChargeStartSwitch==1)
		{
			cloud_jcsj.scdl=data_scpoe[OVERCURRENT].data/100;
			cloud_jcsj.scdy=data_scpoe[OVERVOLTAGE].data/10;
		}
	}
	else
	{
		uint32_t *bl_data;
		bl_data=Bl_Read_Data();
		data_scpoe[OVERCURRENT].data=bl_data[0];
		read_modbus_buffer[12]=bl_data[0]>>8;
		read_modbus_buffer[13]=bl_data[0];
	
		data_scpoe[LEAKAGE].data=bl_data[1]/100;
		read_modbus_buffer[16]=bl_data[1]>>8;
		read_modbus_buffer[17]=bl_data[1];
	
		data_scpoe[OVERVOLTAGE].data=bl_data[2];
		data_scpoe[UNDERVOLTAGE].data=bl_data[2];
		read_modbus_buffer[8]=bl_data[2]>>8;
		read_modbus_buffer[9]=bl_data[2];
		
		read_modbus_buffer[20]=bl_data[3]>>8;
		read_modbus_buffer[21]=bl_data[3];
	 
		Electric_Energy_Select=bl_data[4];
		read_modbus_buffer[24]=bl_data[4]>>8;
		read_modbus_buffer[25]=bl_data[4];
		
		if(ChargeStartSwitch==1)
		{
			cloud_jcsj.scdl=K_Electricity*(data_scpoe[OVERCURRENT].data/100)+B_Electricity;
			cloud_jcsj.scdy=K_Voltage*(data_scpoe[OVERVOLTAGE].data/10)+B_Voltage;
		}
	}
		
		
		
//		rt_kprintf("Tem=%d CP=%d jD=%d\n",data_scpoe[TEMPERATURE].data,CP_Voltage,data_scpoe[GROUNDING].data);
//		rt_kprintf("I=%d L=%d V=%d N=%d\n",data_scpoe[OVERCURRENT].data,data_scpoe[LEAKAGE].data,data_scpoe[UNDERVOLTAGE].data,Electric_Energy_Select);
//	}
}

void Bl_Write_Data(uint8_t addr,uint32_t data)
{
	uint8_t write_data[6];
	uint16_t data_ver=0;
	write_data[0]=0xA5;
	write_data[1]=addr;
	write_data[2]=data>>16;
	write_data[3]=data>>8;
	write_data[4]=data;
	for(int t=0;t<5;t++)
	{
		data_ver=data_ver+write_data[t];
	}
	write_data[5]=(~(data_ver&0xFF));
	rt_device_write(uart4,0,write_data,6);
	rt_device_write(uart2,0,write_data,6);
}


uint32_t* Bl_Read_Data()
{
//	if(eledj_delay_par.delay_flag==1)
//	{
		static uint32_t new_data[5];
		uint8_t data[2]={0x55,0xAA};
		uint8_t data_ver=0;
		uint8_t data_sum=0x55;
		
		
		uint32_t data32_ai=0;
		uint32_t data32_bi=0;
		uint32_t data32_v=0;
		uint32_t data32_w=0;
		uint32_t data32_d=0;
		uint32_t w_data=0;
		uint32_t d_data=0;
		
		if(rt_device_write(uart4,0,data,2)==2)
		{
			rt_thread_delay(80);
			if(uart4_device.uart_flag==1)
			{
				for(int t=0;t<34;t++)
				{
					data_sum+=uart4_device.uart_rx_buffer[t];
				}
				data_ver=~((data_sum)&0xFF);
				if(data_ver==uart4_device.uart_rx_buffer[34])
				{
					//��Ч����ֵ
					data32_ai=((uint32_t)uart4_device.uart_rx_buffer[6]<<16)+((uint32_t)uart4_device.uart_rx_buffer[5]<<8)+uart4_device.uart_rx_buffer[4];
	//				rt_kprintf("�����Ĵ���:%d\n",data32_ai);
	//				new_data[0]=((data32_ai*Vref)/(324004*(R54*1000)/RT_A))*1000;	
						new_data[0]=((data32_ai*Vref)/(324004*(R54*1000)/RT_A))*1000;
//					EffectiveElectricCurrent_Value=new_data[0];
//					modbus_buffer[7]=EffectiveElectricCurrent_Value>>8;
//					modbus_buffer[8]=EffectiveElectricCurrent_Value;
//					if(RelayChargeStartSwitch==1)
//					{
//						cloud_jcsj.scdl=new_data[0]=K_Electricity*(EffectiveElectricCurrent_Value/100)+B_Electricity;
//					}
//					rt_kprintf("����ֵ:%d\n",new_data[0]);
					
					//��Ч©��ֵ
					data32_bi=((uint32_t)uart4_device.uart_rx_buffer[9]<<16)+((uint32_t)uart4_device.uart_rx_buffer[8]<<8)+uart4_device.uart_rx_buffer[7];
	//				rt_kprintf("©�����Ĵ���:%d\n",data32_bi);
	//				new_data[1]=((data32_bi*Vref)/(32400.4*(R71*1000)/RT_B))*1000;
						new_data[1]=((data32_bi*Vref)/(32400.4*(R71*1000)/RT_B))*10000;
//					EffectiveLeakageCurrent=new_data[1];
//					rt_kprintf("©����ֵ:%d\n",new_data[1]);
					
					//��Ч��ѹֵ
					data32_v=((uint32_t)uart4_device.uart_rx_buffer[12]<<16)+((uint32_t)uart4_device.uart_rx_buffer[11]<<8)+uart4_device.uart_rx_buffer[10];
	//				rt_kprintf("��ѹ�Ĵ���:%d\n",data32_v);
	//				new_data[2]=((data32_v*Vref*(R67+R68))/(79931*R73*1000))*100;
					
					new_data[2]=((data32_v*Vref*(R67+R68))/(79931*R73*1000))*100;
//					EffectiveVoltage_Value=new_data[2];
//					if(RelayChargeStartSwitch==1)
//					{
//						cloud_jcsj.scdy=K_Voltage*(EffectiveVoltage_Value/10)+B_Voltage;
//					}
//					rt_kprintf("��ѹֵ:%d\n",new_data[2]);
					
					//��Ч�й�����
					data32_w=((uint32_t)uart4_device.uart_rx_buffer[18]<<16)+((uint32_t)uart4_device.uart_rx_buffer[17]<<8)+uart4_device.uart_rx_buffer[16];
	//							rt_kprintf("���ʼĴ���:%d\n",data32_w);
					new_data[3]=((data32_w*Vref*Vref*(R67+R68))/(4046*((R54*1000)/RT_A)*R73*1000))*100;
//								rt_kprintf("����ֵ:%d\n",new_data[3]);
					
					//��������
					data32_d=((uint32_t)uart4_device.uart_rx_buffer[24]<<16)+((uint32_t)uart4_device.uart_rx_buffer[23]<<8)+uart4_device.uart_rx_buffer[22];
//				rt_kprintf("���ܼĴ���:%d\n",data32_d);
					//				1,213,358,376.22272										14,565,600,000,000        390
//					d_data=(((1638.4*256*Vref*Vref*(R68+R67))/(3600000*4046*((R54*1000)/RT_A)*R73*1000))*data32_d);5,680,584,000,000
	//				new_data[4]=0.00008330301369*data32_d*10000;
						new_data[4]=0.00008330301369*data32_d*10000;
//					Electric_Energy_Select=new_data[4];
	//				modbus_buffer[13]=Electric_Energy_Select>>8;
	//				modbus_buffer[14]=Electric_Energy_Select;
//					rt_kprintf("����ֵ:%d\n",new_data[4]);
	//				cloud_jcsj.cdds=d_data;

				}
				uart4_device.uart_flag=0;
			}
		}
		return new_data;
//	}
	
}



