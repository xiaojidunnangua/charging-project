
#include <rtthread.h>
#include <rtdevice.h>
#include "drv_common.h"
#include "drv_gpio.h"
#include "at32f435_437_conf.h"
#include "HS_main.h" //
#include "HS_timer.h"
#include "HS_RC522.h"
void Initboard()
{
	  InitGpio_USER();				    // Initialize the User defined GPIO pins
	  rt_hw_spi_rs16_config();
	
////		Errors_Data = FM25640C_Read_Byte(0x0000);
////		Errors_Data <<=	8;
////	  Errors_Data |= FM25640C_Read_Byte(0x0001);			//�������
//		ChargeState_Flag = FM25640C_Read_Byte(0x0002);			//����־
//		Charge_Flag = FM25640C_Read_Byte(0x0003);			//���̱�־
//	if((Charge_Flag == 2)||(Charge_Flag == 3)||(Charge_Flag == 6)) Charge_Flag = 0x07;
//	//	Relay_Flag = FM25640C_Read_Byte(0x0004);			//�̵�����־
//		PWM_flag = FM25640C_Read_Byte(0x0005);			//PWM���ر�־
//		Pwm_DC = FM25640C_Read_Byte(0x0006);
//	  Pwm_DC <<=	8;
//		Pwm_DC |= FM25640C_Read_Byte(0x0007);			//Pwmռ�ձȣ�ǧ���ʣ�
//		ChargeStart = FM25640C_Read_Byte(0x0008);			//������־
////	  timecounter4 = FM25640C_Read_Byte(0x0009);			//Ƿѹ��ѹ��ʱ
Pwm_DC = 534;

//		usart_init(UART4, 4800, USART_DATA_8BITS, USART_STOP_1_BIT);

	uart_sample();
	pwm_init();
	adc_init();
	hwtimer_init();
	interrupt_init();
	uart_int();
	wdt_init();
//	uart_display();
//	rt_hw_spi_rc522_config();
#ifdef RC522


			/****************************************ˢ��******************************************/
		 PcdReset();
     PcdAntennaOff(); 
		 rt_hw_us_delay(1000);
     PcdAntennaOn();  
		 
		/**********************************************************************************/
#endif	
	

}

