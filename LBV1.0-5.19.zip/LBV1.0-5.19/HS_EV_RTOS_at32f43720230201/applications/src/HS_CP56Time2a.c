#include <rtthread.h>
#include <rtdevice.h>
#include "string.h"
#include "HS_CP56Time2a.h"
#include "HS_uart.h"
#include "HS_#define.h"
#include "HS_main.h"

time_t now;
st_cp56time2a st_cp56time2a1;
struct tm *sttm;

//����ʱ������
uint8_t* CP56_data()
{
	static uint8_t cp56_value[7];
	now = time(RT_NULL);
	sttm=localtime(&now);
	st_cp56time2a1.Compts.year=sttm->tm_year-100;
	st_cp56time2a1.Compts.month=sttm->tm_mon + 1;
	st_cp56time2a1.Compts.mday=sttm->tm_mday;
	st_cp56time2a1.Compts.hour=sttm->tm_hour;
	st_cp56time2a1.Compts.min=sttm->tm_min;
	st_cp56time2a1.Compts.msec=(sttm->tm_sec)*1000;
	for(int t=0;t<7;t++)
	{
		cp56_value[t]=st_cp56time2a1.Time>>(t*8);
	}
	return cp56_value;
}