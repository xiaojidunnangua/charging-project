
#include <rtthread.h>
#include <rtdevice.h>
#include "HS_rtc.h"

#define RTC_NAME       "rtc"

int rtc_init()
{
    rt_err_t ret = RT_EOK;
    
    rt_device_t device = RT_NULL;

    /*Ѱ���豸*/
    device = rt_device_find(RTC_NAME);
    if (!device)
    {
      rt_kprintf("find %s failed!", RTC_NAME);
    }

    /*��ʼ��RTC�豸*/
    if(rt_device_open(device, 0) != RT_EOK)
    {
      rt_kprintf("open %s failed!", RTC_NAME);
    }

//    /* �������� */
//    ret = set_date(2023, 8, 14);
//    if (ret != RT_EOK)
//    {
//        rt_kprintf("set RTC date failed\n");
//    }

//    /* ����ʱ�� */
//    ret = set_time(9, 35, 59);
//    if (ret != RT_EOK)
//    {
//        rt_kprintf("set RTC time failed\n");
//    }
    
		return 0;
		
}
//INIT_DEVICE_EXPORT(rtc_init);

