#include <rtthread.h>
#include <rtdevice.h>
#include "HS_CH9141.h"
#include "HS_struct.h"
#include "string.h"
#include "HS_#define.h"  
#include "HS_main.h"
#include "HS_uart.h"




const at_cmd_struct atble_cmd[]=													//atָ�
{
	
	{
		.index=AT_BLE,
		.executecmd="AT...\r\n",
		.data_len=7,
		.returnparameters="OK",
		.cmdannotation="����AT����",
	},
	
	{
		.index=AT_BLE_HELLO,
		.executecmd="AT+HELLO=HELLO_HS\r\n",
		.data_len=19,
		.returnparameters="OK",
		.cmdannotation="������",
	},
	
	{
		.index=AT_BLE_PASS,
		.executecmd="AT+PASS=147258\r\n",
		.data_len=17,
		.returnparameters="OK",
		.cmdannotation="��������",
	},
	
	{
		.index=AT_BLE_PNAME,
		.executecmd="AT+PNAME=HS_",
		.data_len=12,
		.returnparameters="OK",
		.cmdannotation="�����豸����",
	},
	
	{
		.index=AT_BLE_PASEN,
		.executecmd="AT+PASEN=ON\r\n",
		.data_len=13,
		.returnparameters="OK",
		.cmdannotation="ʹ������",
	},
	
	{
		.index=AT_BLE_BLEMODE,
		.executecmd="AT+BLEMODE=2\r\n",
		.data_len=14,
		.returnparameters="OK",
		.cmdannotation="��������ģʽ",
	},
	
	{
		.index=AT_BLE_RESET,
		.executecmd="AT+RESET\r\n",
		.data_len=10,
		.returnparameters="HELLO_HS",
		.cmdannotation="��λоƬ",
	},
	
};


static uint8_t esp32_bluetooth_flag1=1; 																//�������ͱ�־λ
static uint8_t esp32_bluetooth_flag2=0; 																//��������ѡ���־λ

static uint16_t ble_delay=800; 	                                           //�ӳ�ʱ��

void ch9141_connect()
{
	if(esp32_bluetooth_flag1==AT_BLE)
	{
		rt_device_write(uart6,0,(uint8_t *)atble_cmd[AT_BLE].executecmd,atble_cmd[AT_BLE].data_len);												//����ATָ��
		rt_device_write(uart2,0,(uint8_t *)atble_cmd[AT_BLE].executecmd,atble_cmd[AT_BLE].data_len);												//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE;																			//ATָ��Ӧ������
	}
	else if(esp32_bluetooth_flag1==AT_BLE_HELLO)
	{
		memset(uart5_device.uart_rx_buffer,'\0',sizeof(uart5_device.uart_rx_buffer));					//uart5���ջ�������
		rt_device_write(uart6,0,(uint8_t *)atble_cmd[AT_BLE_HELLO].executecmd,atble_cmd[AT_BLE_HELLO].data_len);												//����ATָ��
		rt_device_write(uart2,0,(uint8_t *)atble_cmd[AT_BLE_HELLO].executecmd,atble_cmd[AT_BLE_HELLO].data_len);												//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE_HELLO;																			//ATָ��Ӧ������
	}
	
	else if(esp32_bluetooth_flag1==AT_BLE_PASS)
	{
		memset(uart5_device.uart_rx_buffer,'\0',sizeof(uart5_device.uart_rx_buffer));					//uart5���ջ�������
		rt_device_write(uart6,0,(uint8_t *)atble_cmd[AT_BLE_PASS].executecmd,atble_cmd[AT_BLE_PASS].data_len);												//����ATָ��
		rt_device_write(uart2,0,(uint8_t *)atble_cmd[AT_BLE_PASS].executecmd,atble_cmd[AT_BLE_PASS].data_len);												//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE_PASS;																			//ATָ��Ӧ������
	}
	
	else if(esp32_bluetooth_flag1==AT_BLE_PNAME)
	{
		memset(uart5_device.uart_rx_buffer,'\0',sizeof(uart5_device.uart_rx_buffer));					//uart5���ջ�������
		uint8_t ble_data[30]={0x00};
		sprintf((char *)ble_data,"%s%s\r\n",atble_cmd[AT_BLE_PNAME].executecmd,device_id);
		rt_device_write(uart6,0,ble_data,atble_cmd[AT_BLE_PNAME].data_len+strlen((char *)device_id));							//����ATָ��
		rt_device_write(uart2,0,ble_data,atble_cmd[AT_BLE_PNAME].data_len+strlen((char *)device_id));							//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE_PNAME;																			//ATָ��Ӧ������
	}
	
	else if(esp32_bluetooth_flag1==AT_BLE_PASEN)
	{
		memset(uart5_device.uart_rx_buffer,'\0',sizeof(uart5_device.uart_rx_buffer));					//uart5���ջ�������
		rt_device_write(uart6,0,(uint8_t *)atble_cmd[AT_BLE_PASEN].executecmd,atble_cmd[AT_BLE_PASEN].data_len);												//����ATָ��
		rt_device_write(uart2,0,(uint8_t *)atble_cmd[AT_BLE_PASEN].executecmd,atble_cmd[AT_BLE_PASEN].data_len);												//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE_PASEN;																			//ATָ��Ӧ������
	}
	
	else if(esp32_bluetooth_flag1==AT_BLE_BLEMODE)
	{
		memset(uart5_device.uart_rx_buffer,'\0',sizeof(uart5_device.uart_rx_buffer));					//uart5���ջ�������
		rt_device_write(uart6,0,(uint8_t *)atble_cmd[AT_BLE_BLEMODE].executecmd,atble_cmd[AT_BLE_BLEMODE].data_len);												//����ATָ��
		rt_device_write(uart2,0,(uint8_t *)atble_cmd[AT_BLE_BLEMODE].executecmd,atble_cmd[AT_BLE_BLEMODE].data_len);												//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE_BLEMODE;																			//ATָ��Ӧ������
	}
	
	else if(esp32_bluetooth_flag1==AT_BLE_RESET)
	{
		memset(uart5_device.uart_rx_buffer,'\0',sizeof(uart5_device.uart_rx_buffer));					//uart5���ջ�������
		rt_device_write(uart6,0,(uint8_t *)atble_cmd[AT_BLE_RESET].executecmd,atble_cmd[AT_BLE_RESET].data_len);												//����ATָ��
		rt_device_write(uart2,0,(uint8_t *)atble_cmd[AT_BLE_RESET].executecmd,atble_cmd[AT_BLE_RESET].data_len);												//����ATָ��
		rt_thread_delay(ble_delay);																		//�ӳٺ���
		
		esp32_bluetooth_flag1=AT_BLE_NULL;																			//ATָ��ر�
		esp32_bluetooth_flag2=AT_BLE_RESET;																			//ATָ��Ӧ������
	}
	if(uart6_device.uart_rx_len==1)																						//�ж������Ƿ�������
	{
		switch(esp32_bluetooth_flag2)                                                         //�ж�AT�Ƿ�ִ�гɹ�
		{
			case AT_BLE:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_HELLO;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE;																		//
				}
			case AT_BLE_HELLO:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE_HELLO].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_PASS;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE_HELLO;																		//
				}
				break;
			case AT_BLE_PASS:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE_PASS].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_PNAME;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE_PASS;																		//
				}
				break;	
			case AT_BLE_PNAME:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE_PNAME].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_PASEN;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE_PNAME;																		//
				}
				break;	
			case AT_BLE_PASEN:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE_PASEN].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_BLEMODE;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE_PASEN;																		//
				}
				break;
			case AT_BLE_BLEMODE:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE_BLEMODE].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_RESET;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE_BLEMODE;																		//
				}
				break;
			case AT_BLE_RESET:
				if(strstr((char *)uart6_device.uart_rx_buffer,(char *)atble_cmd[AT_BLE_RESET].returnparameters)!=NULL)
				{
					esp32_bluetooth_flag1=AT_BLE_RESET;																		//
				}
				else
				{
					esp32_bluetooth_flag1=AT_BLE_RESET;																		//
				}
				break;
		}
	}
	
	
}



