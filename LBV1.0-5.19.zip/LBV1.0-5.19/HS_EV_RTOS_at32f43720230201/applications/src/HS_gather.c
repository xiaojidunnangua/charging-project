#include <rtthread.h>
#include <rtdevice.h>
#include "string.h"
#include "HS_gather.h"
#include "HS_#define.h"
#include "HS_main.h"
#include "math.h"
#include "HS_IP101GR.h"
#include "HS_FIBOCOM_4Gcat1.h"
#include "HS_BL24512.h"
#include "HS_MaintainPlatform.h"
//#include "HS_MaintainPlatform.h"




uint16_t Errors_Data = 0x0000;		//�������



uint8_t	ChargeState_Flag = 0x00;			//����־
/*	
*			0x00	-->	����
*			0x01	-->	�쳣	
*/
uint8_t	Charge_Flag = 0x00;			//�����̱�־
/*	
*			12V	-->	0	-	1
*			9 V	-->	1	-	2
*			6 V	-->	2	-	4
*			����-->	8
*/
uint8_t Pwm_Charge_Flag=0x00;

uint8_t PilotLamp_Flag = 0x00;		//�źŵƱ�־
uint8_t UrgencyLamp_Flag=0x00;		//�����¼��Ʊ�־
uint8_t DwinContent_Flag=0x00;		//��ʾ��־


uint8_t	Relay_Flag = 0x00;			//�̵�����־
/*	
*			����	-->	�̵�������
*			�ر�	-->	�̵����ر�
*			�쳣	-->	�̵�������
*/

uint8_t ChargeStartSwitch = 0x00;			//�̵�����������
//uint8_t ChargeStartSwitch = 0x00;			//��������


uint16_t cpcp_thread_flag = CP_Sampling_Loop;//CPCP�ɼ��߳��ж��л���־
uint16_t Temperature;		//�豸�¶�
uint8_t PWM_flag = 0x01;		//PWM���ر�־
uint16_t CurrentLimit = 0;			//��������
uint16_t EffectiveElectricCurrent_Value = 0;			//��Ч����
//uint16_t EffectiveGrounding_Value = 0;			//��Ч�ӵ�
uint16_t EffectiveLeakageCurrent = 0;			//��Ч©����
uint16_t EffectiveVoltage_Value = 0;			//��Ч��ѹ
uint32_t Electric_Energy_Select=0;				//����
uint16_t CP_Voltage;		//CP��ѹ
uint8_t recharge_state=0;			//���״̬
uint8_t recharge_state_flag=0;			//���״̬��־
uint8_t tem_state=0;				//�¶�״̬



data_delay_paramerter jdjc_delay_par,show_data_par;
data_delay_paramerter eledj_delay_par={
	.delay_flag=1,
};



input_data_paramerter data_scpoe[]=
{
	
	{
		.index=CP12,
		.data_scope_par=
		{
			.data_scope_max=1300,
			.data_scope_min=1100,
		},
	},
	
	
	{
		.index=CP9,
		.data_scope_par=
		{
			.data_scope_max=1000,
			.data_scope_min=800,
		},
		
	},
	
	
	{
		.index=CP6,
		.data_scope_par=
		{
			.data_scope_max=700,
			.data_scope_min=500,
		},
		
	},
	
	{
		.index=OVERVOLTAGE,
		.data_scope_par=
		{
			.data_scope_max=25000,
			.data_scope_min=22000,
		},
		
	},
	
	
	{
		.index=UNDERVOLTAGE,
		.data_scope_par=
		{
			.data_scope_max=22000,
			.data_scope_min=17600,
		},
		
	},
	
	
	{
		.index=OVERCURRENT,
		.data_scope_par=
		{
			.data_scope_max=32,
			.data_scope_min=0,
		},
	},
	
	
	{
		.index=LEAKAGE,
		.data_scope_par=
		{
			.data_scope_max=250,
			.data_scope_min=0,
		},
		
	},
	
	
	{
		.index=GROUNDING,
		.data_scope_par=
		{
			.data_scope_max=2,
			.data_scope_min=1,
		},
		
	},
	
	
	{
		.index=TRANSPOSITION,
		.data_scope_par=
		{
			.data_scope_max=1700,
			.data_scope_min=1300,
		},
		
	},
	
	
	{
		.index=TEMPERATURE,
		.data_scope_par=
		{
			.data_scope_max=1100,
			.data_scope_min=600,
		},
	},
	
	{
		.index=SCRAM,
	},
	
	{
		.index=READDARA,
	},
	
};



uint8_t overcu_mut=0,overvo_mut=0,tem_mut=0,elect_mut=0,gro_mut=0,scram_mut=0,cp_mut=0;

//��ѹ�ж�
void Voltage_Judge()
{
	if(data_scpoe[OVERVOLTAGE].data_warning_flag==0&&(data_scpoe[OVERVOLTAGE].data > data_scpoe[OVERVOLTAGE].data_scope_par.data_scope_max))	//��ѹ
	{
		data_scpoe[OVERVOLTAGE].data_delay_par.delay_switch=1;
		
		if(data_scpoe[OVERVOLTAGE].data_delay_par.delay_flag==1)
		{
			
			data_scpoe[OVERVOLTAGE].data_delay_par.delay_switch=0;
			data_scpoe[OVERVOLTAGE].data_delay_par.delay_count=0;
			data_scpoe[OVERVOLTAGE].data_delay_par.delay_flag=0;
			data_scpoe[OVERVOLTAGE].data_warning_flag=1;
			PilotLamp_Flag=2;
			if(ChargeStartSwitch==1)
			{
				recharge_state_flag=0;
				Relay_Flag = Relay_Close;			//�����̵���
				rt_pin_write(RELAY_L, PIN_LOW);
				rt_hw_us_delay(5);
				rt_pin_write(RELAY_N, PIN_LOW);
				recharge_state=4;
				
				PilotLamp_Flag=0x0000;
				DwinContent_Flag=0x02;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			}
			else if(ChargeStartSwitch==0)
			{
				lec_data_show_count=0;
				Errors_Data |= OverVoltage_bit;			//��ѹ�������
				cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
				UrgencyLamp_Flag=0x01;
				DwinContent_Flag=0x05;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
			}
			
		}
	}
	
	else if(data_scpoe[OVERVOLTAGE].data<data_scpoe[OVERVOLTAGE].data_scope_par.data_scope_min&&data_scpoe[OVERVOLTAGE].data<data_scpoe[OVERVOLTAGE].data_scope_par.data_scope_max)
	{
		data_scpoe[OVERVOLTAGE].data_delay_par.delay_switch=0;
		data_scpoe[OVERVOLTAGE].data_delay_par.delay_count=0;
		data_scpoe[OVERVOLTAGE].data_delay_par.delay_flag=0;
		
		if(data_scpoe[OVERVOLTAGE].data_warning_flag==1)
		{
			
			if(ChargeStartSwitch==1)
			{
				cp_delay_flag=1;																				//��cp�ӳٱ�־
			}
			else if(ChargeStartSwitch==0)
			{
				
				Errors_Data &=~OverVoltage_bit;			//��ѹ����������
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				
				UrgencyLamp_Flag=0x00;								//���ϵƽ��
				DwinContent_Flag=0x01;								//������ʾ�ر�
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
			}
			data_scpoe[OVERVOLTAGE].data_warning_flag=0;
			
		}
		
	}
	
	
	if(data_scpoe[UNDERVOLTAGE].data_warning_flag==0&&(data_scpoe[UNDERVOLTAGE].data<data_scpoe[UNDERVOLTAGE].data_scope_par.data_scope_min))				//Ƿѹ
	{
		data_scpoe[UNDERVOLTAGE].data_delay_par.delay_switch=1;
		
		if(data_scpoe[UNDERVOLTAGE].data_delay_par.delay_flag==1)
		{
			data_scpoe[UNDERVOLTAGE].data_delay_par.delay_switch=0;
			data_scpoe[UNDERVOLTAGE].data_delay_par.delay_count=0;
			data_scpoe[UNDERVOLTAGE].data_delay_par.delay_flag=0;
			data_scpoe[UNDERVOLTAGE].data_warning_flag=1;
			
			PilotLamp_Flag=2;
			uint8_t read_data[4]={0x00},read_len=0x00,control=0x13;
			uint8_t addr[6]={0xAA,0xAA,0xAA,0xAA,0xAA,0xAA};
			Dds3366_Read_Addr(addr,control,read_len,read_data);
			if(ChargeStartSwitch==1)
			{
				recharge_state_flag=0;
				Relay_Flag = Relay_Close;			//�رռ̵���
				rt_pin_write(RELAY_L, PIN_LOW);
				rt_hw_us_delay(5);
				rt_pin_write(RELAY_N, PIN_LOW);
				recharge_state=4;
				UrgencyLamp_Flag=0x00;
				DwinContent_Flag=0x02;								//������ʾ�ر�
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				
			}
			else if(ChargeStartSwitch==0)
			{
				lec_data_show_count=0;
				Errors_Data |= UnderVoltage_bit;			//Ƿѹ�������
				cloud_jcsj.zzt=0x01;									//���׮���б�־
				UrgencyLamp_Flag=0x01;
				DwinContent_Flag=0x05;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
			}
		}
	}
	else if(data_scpoe[UNDERVOLTAGE].data>data_scpoe[UNDERVOLTAGE].data_scope_par.data_scope_min)
	{
		
		data_scpoe[UNDERVOLTAGE].data_delay_par.delay_switch=0;
		data_scpoe[UNDERVOLTAGE].data_delay_par.delay_count=0;
		data_scpoe[UNDERVOLTAGE].data_delay_par.delay_flag=0;
		if(data_scpoe[UNDERVOLTAGE].data_warning_flag==1)
		{
			
			if(ChargeStartSwitch==1)
			{
//				Pwm_Charge_Flag = PWM_CP9VCharge_bit;										//��PWM���
				cp_delay_flag=1;																				//��cp�ӳٱ�־
			}
			else if(ChargeStartSwitch==0)
			{
				Errors_Data &=~UnderVoltage_bit;		//Ƿѹ�������
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				UrgencyLamp_Flag=0x00;								//���ϵƽ��
				DwinContent_Flag=0x01;								//������ʾ�ر�
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
			}
			
			data_scpoe[UNDERVOLTAGE].data_warning_flag=0;		
	
		}
	}
	
}






//�����ж�
void Electricity_Judge()
{
	
	if(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max > 20)			//����������жϹ�����ֵ
	{
		CurrentLimit = data_scpoe[OVERCURRENT].data_scope_par.data_scope_max*1.1*1000-1000;
	}
	else
	{
		CurrentLimit = data_scpoe[OVERCURRENT].data_scope_par.data_scope_max*1000+2;
	}
	if(data_scpoe[OVERCURRENT].data > CurrentLimit&&ChargeStartSwitch==1&&data_scpoe[OVERCURRENT].data_warning_flag==0)			//�жϹ���
	{
		data_scpoe[OVERCURRENT].data_delay_par.delay_switch=1;
		
		if(data_scpoe[OVERCURRENT].data_delay_par.delay_flag==1)
		{
			data_scpoe[OVERCURRENT].data_delay_par.delay_switch=0;
			data_scpoe[OVERCURRENT].data_delay_par.delay_count=0;
			data_scpoe[OVERCURRENT].data_delay_par.delay_flag=0;
			data_scpoe[OVERCURRENT].data_warning_flag=1;
			eledj_delay_par.delay_flag=0;
			Relay_Flag = Relay_Close;
			eledj_delay_par.delay_switch=1;
			lec_data_show_count=0;
			Errors_Data |= OverCurrent_bit;			//�����������
			PilotLamp_Flag=2;
			UrgencyLamp_Flag=0x01;
			DwinContent_Flag=0x05;
			emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			cloud_cdyc_flag=1;
			cloud_jyjl.tzyy=0x7A;				//�ܳ������쳣
			cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
			read_modbus_buffer[144]=Errors_Data>>8;
			read_modbus_buffer[145]=Errors_Data;
			if(cloud_enthernet_4g_connect==1)
			{
				rt_thread_delay(500);
				mqtt_json_devicedata(read_modbus_buffer);
				
			}
			else if(cloud_enthernet_4g_connect==2)
			{
				mqtt_json_devicedata(read_modbus_buffer);
			}
		}
	}
	else if(data_scpoe[OVERCURRENT].data < CurrentLimit&&ChargeStartSwitch==1&&data_scpoe[OVERCURRENT].data_warning_flag==0)
	{
		data_scpoe[OVERCURRENT].data_warning_flag=0;
		data_scpoe[OVERCURRENT].data_delay_par.delay_switch=0;
		data_scpoe[OVERCURRENT].data_delay_par.delay_count=0;
		data_scpoe[OVERCURRENT].data_delay_par.delay_flag=0;
	}
	if(ChargeStartSwitch==0&&eledj_delay_par.delay_flag==1)
	{
		if(data_scpoe[OVERCURRENT].data >= 2000)			//�жϹ���
		{
			data_scpoe[OVERCURRENT].data_delay_par.delay_switch=1;
			
			if(data_scpoe[OVERCURRENT].data_warning_flag==0&&data_scpoe[OVERCURRENT].data_delay_par.delay_flag==1)
			{
				data_scpoe[OVERCURRENT].data_delay_par.delay_switch=0;
				data_scpoe[OVERCURRENT].data_delay_par.delay_count=0;
				data_scpoe[OVERCURRENT].data_delay_par.delay_flag=0;
				data_scpoe[OVERCURRENT].data_warning_flag=1;
				Relay_Flag = Relay_Close;
				lec_data_show_count=0;
				Errors_Data |= OverCurrent_bit;			//�����������
				PilotLamp_Flag=2;
				UrgencyLamp_Flag=0x01;
				DwinContent_Flag=0x05;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				
				cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
				
			}
		}
		else if(data_scpoe[OVERCURRENT].data <2000)
		{
			data_scpoe[OVERCURRENT].data_delay_par.delay_switch=0;
			data_scpoe[OVERCURRENT].data_delay_par.delay_count=0;
			data_scpoe[OVERCURRENT].data_delay_par.delay_flag=0;
			if(data_scpoe[OVERCURRENT].data_warning_flag==1)
			{
				data_scpoe[OVERCURRENT].data_warning_flag=0;
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				Errors_Data &= ~OverCurrent_bit;			//���������������
				cloud_cdyc_show_flag=0;
				UrgencyLamp_Flag=0x00;								//���ϵƽ��
				DwinContent_Flag=0x01;								//������ʾ�ر�
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
			}
		}
	}
}



//©���ж�
void Electric_Judge()
{
	if(electric_leakage_select==1)
	{
		if(data_scpoe[LEAKAGE].data>data_scpoe[LEAKAGE].data_scope_par.data_scope_max)
		{
			
			data_scpoe[LEAKAGE].data_delay_par.delay_switch=1;
			
			if((data_scpoe[LEAKAGE].data_warning_flag==0)&&data_scpoe[LEAKAGE].data_delay_par.delay_flag==1)			//������־������һ��ʱ���Ժ󱨾�
			{
				data_scpoe[OVERVOLTAGE].data_recover_count=0;
				data_scpoe[LEAKAGE].data_delay_par.delay_switch=0;
				data_scpoe[LEAKAGE].data_delay_par.delay_count=0;
				data_scpoe[LEAKAGE].data_delay_par.delay_flag=0;
				data_scpoe[LEAKAGE].data_warning_flag=1;
				Relay_Flag = Relay_Close;
				lec_data_show_count=0;
				Errors_Data |= ElectricLeakage_bit;
				cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
				PilotLamp_Flag=2;
				UrgencyLamp_Flag=0x01;								//�����ƿ���
				DwinContent_Flag=0x06;								//©����ʾ
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
				if(ChargeStartSwitch==1)
				{
					cloud_cdyc_flag=1;
					cloud_jyjl.tzyy=0x6F;				//������������
				}
			}
		}
		else if(data_scpoe[LEAKAGE].data<=data_scpoe[LEAKAGE].data_scope_par.data_scope_max)
		{
			data_scpoe[LEAKAGE].data_delay_par.delay_switch=0;
			data_scpoe[LEAKAGE].data_delay_par.delay_count=0;
			data_scpoe[LEAKAGE].data_delay_par.delay_flag=0;
			if(data_scpoe[LEAKAGE].data_warning_flag==1)
			{
				data_scpoe[LEAKAGE].data_warning_flag=0;
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				Errors_Data &=~ElectricLeakage_bit;			//©��澯����������
				cloud_cdyc_show_flag=0;
				UrgencyLamp_Flag=0x00;								//���ϵƽ��
				DwinContent_Flag=0x01;								//������ʾ�ر�
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
			}
		}
	}
	else if(electric_leakage_select==2)
	{
		if((data_scpoe[LEAKAGE].data_warning_flag==0)&&(rt_pin_read(PIN_ELE_REP)==PIN_LOW))
		{
		
			data_scpoe[LEAKAGE].data_warning_flag=1;
			Relay_Flag = Relay_Close;
			Errors_Data |= ElectricLeakage_bit;
			lec_data_show_count=0;
			cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
			PilotLamp_Flag=2;
			UrgencyLamp_Flag=0x01;								//�����ƿ���
			DwinContent_Flag=0x06;								//©����ʾ
			emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			read_modbus_buffer[144]=Errors_Data>>8;
			read_modbus_buffer[145]=Errors_Data;
			if(cloud_enthernet_4g_connect==1)
			{
				rt_thread_delay(500);
				mqtt_json_devicedata(read_modbus_buffer);
			}
			else if(cloud_enthernet_4g_connect==2)
			{
				mqtt_json_devicedata(read_modbus_buffer);
				
			}
			if(ChargeStartSwitch==1)
			{
				
				cloud_cdyc_flag=1;
				cloud_jyjl.tzyy=0x6F;				//������������
				
			}
		}
		else if((data_scpoe[LEAKAGE].data_warning_flag==1)&&(rt_pin_read(PIN_ELE_REP)==PIN_HIGH))
		{
			cloud_jcsj.zzt=0x02;									//���׮���б�־
			Errors_Data &=~ElectricLeakage_bit;			//©��澯����������
			data_scpoe[LEAKAGE].data_warning_flag=0;
			cloud_cdyc_show_flag=0;
			
			UrgencyLamp_Flag=0x00;								//���ϵƽ��
			DwinContent_Flag=0x01;								//������ʾ�ر�
			emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			read_modbus_buffer[144]=Errors_Data>>8;
			read_modbus_buffer[145]=Errors_Data;
			if(cloud_enthernet_4g_connect==1)
			{
				rt_thread_delay(500);
				mqtt_json_devicedata(read_modbus_buffer);
			}
			else if(cloud_enthernet_4g_connect==2)
			{
				mqtt_json_devicedata(read_modbus_buffer);
				
			}
			
		}
	}
}

//�ӵ��ж�
void Ground_Judge()
{
//	
//	if(adc3_ordinary_valuetab[0]>600&&adc3_ordinary_valuetab[0]<1200)
//	{

//		EffectiveGrounding_Value=1;
//	}
//	
//	if(adc3_ordinary_valuetab[0]<=150)
//	{
//		jdjc_delay_par.delay_switch=1;
//		if(jdjc_delay_par.delay_flag==1)
//		{
//			jdjc_delay_par.delay_flag=0;
//			EffectiveGrounding_Value=2;
//		}
//	}
//	else
//	{
//		jdjc_delay_par.delay_switch=0;
//		jdjc_delay_par.delay_count=0;
//	}
	if(data_scpoe[GROUNDING].data==0x02)			//�жϽӵع���
	{
		data_scpoe[GROUNDING].data_delay_par.delay_switch=1;
		
		if((data_scpoe[GROUNDING].data_warning_flag==0)&&data_scpoe[GROUNDING].data_delay_par.delay_flag==1)										//������־������һ��ʱ���Ժ󱨾�
		{
			data_scpoe[GROUNDING].data_delay_par.delay_switch=0;
			data_scpoe[GROUNDING].data_delay_par.delay_count=0;
			data_scpoe[GROUNDING].data_delay_par.delay_flag=0;
			data_scpoe[GROUNDING].data_warning_flag=1;
			
			lec_data_show_count=0;
			Errors_Data |= EarthedFault_bit;			//�ӵش������
			cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
			PilotLamp_Flag=2;
			UrgencyLamp_Flag=0x01;
			DwinContent_Flag=0x03;
			read_modbus_buffer[144]=Errors_Data>>8;
			read_modbus_buffer[145]=Errors_Data;
			emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			if(cloud_enthernet_4g_connect==1)
			{
				rt_thread_delay(500);
				mqtt_json_devicedata(read_modbus_buffer);
				
			}
			else if(cloud_enthernet_4g_connect==2)
			{
				mqtt_json_devicedata(read_modbus_buffer);
			}
			
			if(ChargeStartSwitch==1)
			{
				cloud_cdyc_flag=1;
				cloud_jyjl.tzyy=0x6F;				//������������
			}
		}
	}
	else if(data_scpoe[GROUNDING].data==0x01)
	{
		data_scpoe[GROUNDING].data_delay_par.delay_switch=0;
		data_scpoe[GROUNDING].data_delay_par.delay_count=0;
		data_scpoe[GROUNDING].data_delay_par.delay_flag=0;
		
		if(data_scpoe[GROUNDING].data_warning_flag==1)
		{
			cloud_jcsj.zzt=0x02;									//���׮���б�־
			Errors_Data &= ~EarthedFault_bit;			//�����ӵش������
			data_scpoe[GROUNDING].data_warning_flag=0;

			UrgencyLamp_Flag=0x00;								//���ϵƽ��
			DwinContent_Flag=0x01;								//������ʾ�ر�
			emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			cloud_cdyc_show_flag=0;
			read_modbus_buffer[144]=Errors_Data>>8;
			read_modbus_buffer[145]=Errors_Data;
			if(cloud_enthernet_4g_connect==1)
			{
				rt_thread_delay(500);
				mqtt_json_devicedata(read_modbus_buffer);
				
			}
			else if(cloud_enthernet_4g_connect==2)
			{
				mqtt_json_devicedata(read_modbus_buffer);
				
			}
		
		}
		
	}
	
}

//�¶��ж�
void Temperature_Judge()
{
	if(tem_state==0)
	{
		if((data_scpoe[TEMPERATURE].data > data_scpoe[TEMPERATURE].data_scope_par.data_scope_max))
		{
	//		data_scpoe[READDARA].data_delay_par.delay_switch=0;
	//		data_scpoe[READDARA].data_delay_par.delay_count=0;
	//		data_scpoe[READDARA].data_delay_par.delay_flag=0;
			data_scpoe[TEMPERATURE].data_delay_par.delay_switch=1;
			
			if((data_scpoe[TEMPERATURE].data_warning_flag==0)&&data_scpoe[TEMPERATURE].data_delay_par.delay_flag==1)
			{
				data_scpoe[TEMPERATURE].data_delay_par.delay_switch=0;
				data_scpoe[TEMPERATURE].data_delay_par.delay_count=0;
				data_scpoe[TEMPERATURE].data_delay_par.delay_flag=0;
				data_scpoe[TEMPERATURE].data_warning_flag=1;
				PilotLamp_Flag=2;
				if(ChargeStartSwitch==1)					//���������¶��쳣
				{
					Relay_Flag = Relay_Close;			//�رռ̵���
					rt_pin_write(RELAY_L, PIN_LOW);
					rt_hw_us_delay(5);
					rt_pin_write(RELAY_N, PIN_LOW);
					recharge_state=3;
					PilotLamp_Flag=0x0000;
					UrgencyLamp_Flag=0x00;
					DwinContent_Flag=0x02;								//������ʾ�ر�
					emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);

					
				}
				else if(ChargeStartSwitch==0)
				{
					lec_data_show_count=0;
					Errors_Data |= OverTemperature_bit;			//���´������
					cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
					UrgencyLamp_Flag=0x01;							//���ϵƿ���
					DwinContent_Flag=0x02;							//�¶���ʾ
					emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
					read_modbus_buffer[144]=Errors_Data>>8;
					read_modbus_buffer[145]=Errors_Data;
					
				}
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
				
			}
		}
		else if((data_scpoe[TEMPERATURE].data < data_scpoe[TEMPERATURE].data_scope_par.data_scope_min))
		{
			data_scpoe[TEMPERATURE].data_delay_par.delay_switch=0;
			data_scpoe[TEMPERATURE].data_delay_par.delay_count=0;
			data_scpoe[TEMPERATURE].data_delay_par.delay_flag=0;
	//		data_scpoe[READDARA].data_delay_par.delay_switch=1;
			if(data_scpoe[TEMPERATURE].data_warning_flag==1)//&&data_scpoe[READDARA].data_delay_par.delay_flag==1)
			{
				
				if(ChargeStartSwitch==1)
				{
					cp_delay_flag=1;																				//��cp�ӳٱ�־
				}
				else if(ChargeStartSwitch==0)
				{
					Errors_Data &= ~OverTemperature_bit;			//�������´������
					cloud_jcsj.zzt=0x02;									//���׮���б�־
					UrgencyLamp_Flag=0x00;								//���ϵƽ��
					DwinContent_Flag=0x01;								//������ʾ�ر�
					emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
					read_modbus_buffer[144]=Errors_Data>>8;
					read_modbus_buffer[145]=Errors_Data;
					
				}
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
				data_scpoe[TEMPERATURE].data_warning_flag=0;
			}
		}		
	}
	
}



//��ͣ�ж�
void Scram_Judge()
{
	
	if((data_scpoe[SCRAM].data_warning_flag==0)&&(rt_pin_read(EMERGENCY_STOP) == PIN_HIGH))
	{
		data_scpoe[SCRAM].data_warning_flag=1;

		Relay_Flag = Relay_Close;
		lec_data_show_count=0;
		Errors_Data |= EmergencyStop_bit;			//��ͣ�Ѵ���
		UrgencyLamp_Flag=0x01;									//���ϵƿ���
		DwinContent_Flag=0x04;									//��ͣ��ʾ
		emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
		
		cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
		read_modbus_buffer[144]=Errors_Data>>8;
		read_modbus_buffer[145]=Errors_Data;
		if(cloud_enthernet_4g_connect==1)
		{
			rt_thread_delay(500);
			mqtt_json_devicedata(read_modbus_buffer);
		}
		else if(cloud_enthernet_4g_connect==2)
		{
			mqtt_json_devicedata(read_modbus_buffer);
			
		}
		if(ChargeStartSwitch==1)					//���������¶��쳣
		{
			cloud_cdyc_flag=1;
			cloud_jyjl.tzyy=0x72;									//��ͣ����
		}
		
	}
	else if((data_scpoe[SCRAM].data_warning_flag==1)&&(rt_pin_read(EMERGENCY_STOP) == PIN_LOW))
	{
		data_scpoe[SCRAM].data_warning_flag=0;

		Errors_Data &= ~EmergencyStop_bit;			//��ͣ�ѽ��
		PilotLamp_Flag=2;
		UrgencyLamp_Flag=0x00;								//���ϵƽ��
		DwinContent_Flag=0x01;								//������ʾ�ر�
		emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);

		cloud_cdyc_show_flag=0;
		cloud_jcsj.zzt=0x02;									//���׮���б�־
		read_modbus_buffer[144]=Errors_Data>>8;
		read_modbus_buffer[145]=Errors_Data;
		if(cloud_enthernet_4g_connect==1)
		{
			rt_thread_delay(500);
			mqtt_json_devicedata(read_modbus_buffer);
			
		}
		else if(cloud_enthernet_4g_connect==2)
		{
			mqtt_json_devicedata(read_modbus_buffer);
		}
	}

}

void NetWork_Judge()
{
	if((accomplish_connect_flag==0)&&(accomplish_sd_flag==0))
	{
		Errors_Data |=IOTAbnormal_bit;
		
	}
	else
	{
		Errors_Data &= ~IOTAbnormal_bit;
	}
}

//CP��ѹ�ж�
void Cp_Judge()
{
	if((CP_Voltage < data_scpoe[CP12].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP12].data_scope_par.data_scope_min))			//CP������ѹ
	{
		rt_thread_delay(50);
		if((CP_Voltage < data_scpoe[CP12].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP12].data_scope_par.data_scope_min))
		{
			cloud_jcsj.sfcq=0;						//δ��ǹ
			Charge_Flag = CP12VCharge_bit;			//CP12V��־
	//		Errors_Data &= ~CPAbnormal_bit;			//CP�������
			data_scpoe[CP9].data_delay_par.delay_switch=0;
			data_scpoe[CP9].data_delay_par.delay_count=0;
			data_scpoe[CP9].data_delay_par.delay_flag=0;
			if(data_scpoe[CP9].data_warning_flag==1)
			{
			
				data_scpoe[CP9].data_warning_flag=0;
				Errors_Data &= ~CPAbnormal_bit;			//CP�������
				
				PilotLamp_Flag=0x01;
				DwinContent_Flag=0x01;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				cloud_cdyc_show_flag=0;
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
			}
		
			
			
		}
		
	}
	else if((CP_Voltage < data_scpoe[CP9].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP9].data_scope_par.data_scope_min))			//CP����ʶ���ѹ
	{
		rt_thread_delay(50);
		if((CP_Voltage < data_scpoe[CP9].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP9].data_scope_par.data_scope_min))
		{
			cloud_jcsj.sfcq=1;								//�Ѳ�ǹ
			Charge_Flag = CP9VCharge_bit;			//CP9V��־
	//		Errors_Data &= ~CPAbnormal_bit;			//CP�������
			data_scpoe[CP9].data_delay_par.delay_switch=0;
			data_scpoe[CP9].data_delay_par.delay_count=0;
			data_scpoe[CP9].data_delay_par.delay_flag=0;
			if(data_scpoe[CP9].data_warning_flag==1)
			{
				data_scpoe[CP9].data_warning_flag=0;
				Errors_Data &= ~CPAbnormal_bit;			//CP�������
				PilotLamp_Flag=0x02;
				DwinContent_Flag=0x01;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				cloud_cdyc_show_flag=0;
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
			}
		}
		
	}
	else if((CP_Voltage < data_scpoe[CP6].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP6].data_scope_par.data_scope_min))			//CP����ʶ��ɹ���ѹ
	{
		rt_thread_delay(50);
		if((CP_Voltage < data_scpoe[CP6].data_scope_par.data_scope_max)&&(CP_Voltage > data_scpoe[CP6].data_scope_par.data_scope_min))
		{
			Charge_Flag = CP6VCharge_bit;			//CP6V��־
			cloud_jcsj.sfcq=1;								//�Ѳ�ǹ
	//		Errors_Data &= ~CPAbnormal_bit;			//CP�������
			data_scpoe[CP9].data_delay_par.delay_switch=0;
			data_scpoe[CP9].data_delay_par.delay_count=0;
			data_scpoe[CP9].data_delay_par.delay_flag=0;
			if(data_scpoe[CP9].data_warning_flag==1)
			{
				data_scpoe[CP9].data_warning_flag=0;
				Errors_Data &= ~CPAbnormal_bit;			//CP�������

				PilotLamp_Flag=0x02;
				DwinContent_Flag=0x01;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				cloud_cdyc_show_flag=0;
				cloud_jcsj.zzt=0x02;									//���׮���б�־
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
					
				}
			}
		}
		
	}
	else
	{

		if(data_scpoe[CP9].data_warning_flag==0)
		{
			data_scpoe[CP9].data_delay_par.delay_switch=1;
			if(data_scpoe[CP9].data_delay_par.delay_flag==1)
			{
				data_scpoe[CP9].data_delay_par.delay_switch=0;
				data_scpoe[CP9].data_delay_par.delay_count=0;
				data_scpoe[CP9].data_delay_par.delay_flag=0;
				data_scpoe[CP9].data_warning_flag=1;
				Errors_Data |= CPAbnormal_bit;			//CP�����Ѵ���
				Relay_Flag = Relay_Close;
				rt_pin_write(RELAY_L, PIN_LOW);
				rt_hw_us_delay(5);
				rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
				PilotLamp_Flag=2;
				UrgencyLamp_Flag=0x01;									//���ϵƿ���
				DwinContent_Flag=0x07;									//��ͣ��ʾ
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				
				cloud_jcsj.zzt=0x01;									//���׮���ϱ�־
				read_modbus_buffer[144]=Errors_Data>>8;
				read_modbus_buffer[145]=Errors_Data;
				
				if(cloud_enthernet_4g_connect==1)
				{
					rt_thread_delay(500);
					mqtt_json_devicedata(read_modbus_buffer);
				}
				else if(cloud_enthernet_4g_connect==2)
				{
					mqtt_json_devicedata(read_modbus_buffer);
				}
				if(ChargeStartSwitch==1)	
				{
					cloud_cdyc_flag=1;
					cloud_jyjl.tzyy=0x6B;									//�����Ͽ�
				}
			}	
		}
	}
}


void Show_Judge()
{
	if(show_data_par.delay_flag==1)
	{
		show_data_par.delay_flag=0;
		if((Errors_Data& 0xBFFF) == 0)
		{
			
			
			if(DwinContent_Flag!=0x03&&ChargeStartSwitch!=1&&cloud_skcw_delay_par.delay_switch==0)//
			{
//				dwin_diyiye_cp(data_scpoe[TEMPERATURE].data);
				dwin_diyiye_cp(CP_Voltage);
				dwin_diyiye_cq();
				
			}
			
			show_dj_resh();
			dwin_diyiye_network();
		}
		
		
		read_modbus_buffer[135]=cloud_jcsj.zzt;
		read_modbus_buffer[137]=recharge_state;
		read_modbus_buffer[139]=cloud_jcsj.sfcq;
		read_modbus_buffer[141]=cloud_jyjl.jybs;
		read_modbus_buffer[143]=cloud_jyjl.tzyy;
		
		
//		Dds3366_Read_Dn();
	}
	if(lec_data_show_count==1)
	{
		lec_data_show_count=0;
		if(ChargeStartSwitch==1&&PWM_flag == Pwm_Open&&Charge_Flag != CP12VCharge_bit&&sk_switch!=1)
		{
//				PilotLamp_Flag=0x0003;
			DwinContent_Flag=0x02;								//������ʾ�ر�
			UrgencyLamp_Flag=0x00;
			emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
		}
	}
	
	
}


void Cp_Logic_Judge()
{
	if((Errors_Data& 0xBFFF) == 0)	
	{
		if(Charge_Flag == CP12VCharge_bit&&Pwm_Charge_Flag == PWM_Charge_bit)		//CP��ѹΪ12V
		{
//			rt_kprintf("CP12\n");
			if(PilotLamp_Flag<=0x0003)
			{
				PilotLamp_Flag=0x0001;
			}

			if(PWM_flag == Pwm_Open)
			{
				
				PWM_flag = Pwm_Close;			//PWM�ر�
				pwm3_pulse = PwmDC_100;			//CP��ѹһֱ�����ڸ�λ
				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
			}
//			if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>=6)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=51))
//				{
//					pwm3_pulse=(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max/60.00)*100;
//				}
//				else if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>52.5)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=63))
//				{
//					pwm3_pulse=((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max+160.00)/250)*100;
//				}
//				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
//				rt_pwm_enable(pwm3_dev,PWM_DEV_CHANNEL);
			
			Relay_Flag = Relay_Close;			//�رռ̵���
			rt_pin_write(RELAY_L, PIN_LOW);
			rt_hw_us_delay(5);
			rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
			cpcp_thread_flag = CP_Sampling_Loop;			//ѭ���ɼ�CP
		}
		else if(Charge_Flag == CP12VCharge_bit&&(Pwm_Charge_Flag == PWM_CP12VCharge_bit||Pwm_Charge_Flag == PWM_CP9VCharge_bit||Pwm_Charge_Flag == PWM_CP6VCharge_bit))		//PWM CP��ѹΪ12V
		{
//			rt_kprintf("PWM_CP12\n");
			if(PilotLamp_Flag<=0x0003)
			{
				PilotLamp_Flag=0x0001;
			}
			
			if(Pwm_Charge_Flag == PWM_CP9VCharge_bit)
			{
				
				Pwm_Charge_Flag = PWM_Charge_bit;
			}
			if(PWM_flag == Pwm_Close)	//�̵���֮ǰ��״̬Ϊ�ر�
			{
				PWM_flag = Pwm_Open;			//PWM����
				
				if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>=6)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=51))
				{
					pwm3_pulse=(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max/60.00)*100;
				}
				else if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>52.5)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=63))
				{
					pwm3_pulse=((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max+160.00)/250)*100;
				}
				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
				rt_pwm_enable(pwm3_dev,PWM_DEV_CHANNEL);
			}			
			Relay_Flag = Relay_Close;			//�رռ̵���
			rt_pin_write(RELAY_L, PIN_LOW);
			rt_hw_us_delay(5);
			rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
			cpcp_thread_flag = CP_Sampling_Eint;			//�жϲɼ�CP
		}
		else if(Charge_Flag == CP9VCharge_bit&&Pwm_Charge_Flag == PWM_Charge_bit)		//CP��ѹΪ9V
		{
//			rt_kprintf("CP9\n");
			if(PilotLamp_Flag<=0x0003)
			{
				PilotLamp_Flag=0x0002;
			}
			
//			if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>=6)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=51))
//				{
//					pwm3_pulse=(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max/60.00)*100;
//				}
//				else if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>52.5)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=63))
//				{
//					pwm3_pulse=((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max+160.00)/250)*100;
//				}
//				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
//				rt_pwm_enable(pwm3_dev,PWM_DEV_CHANNEL);
			
			if(PWM_flag == Pwm_Open)
			{
				
				PWM_flag = Pwm_Close;			//PWM�ر�
				pwm3_pulse = PwmDC_100;			//CP��ѹһֱ�����ڸ�λ
				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
			}
			
			Relay_Flag = Relay_Close;			//�رռ̵���
			rt_pin_write(RELAY_L, PIN_LOW);
			rt_hw_us_delay(5);
			rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
			cpcp_thread_flag = CP_Sampling_Loop;			//ѭ���ɼ�CP
			
		}
		else if(Charge_Flag == CP9VCharge_bit&&(Pwm_Charge_Flag == PWM_CP9VCharge_bit||Pwm_Charge_Flag == PWM_CP6VCharge_bit||Pwm_Charge_Flag == PWM_CP12VCharge_bit))		//PWM CP��ѹΪ9V
		{
//			rt_kprintf("PWM_CP9\n");
			Relay_Flag = Relay_Close;			//�رռ̵���
			if(PilotLamp_Flag<=0x0003)
			{
				PilotLamp_Flag=0x0002;
			}
			
			
			
//			ChargeStartSwitch=0;
			cp_delay_flag=1;
//				Pwm_Charge_Flag = PWM_CP9VCharge_bit;
			if(PWM_flag == Pwm_Close)
			{
				PWM_flag = Pwm_Open;			//PWM����
				
				if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>=6)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=51))
				{
					pwm3_pulse=(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max/60.00)*100;
				}
				else if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>52.5)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=63))
				{
					pwm3_pulse=((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max+160.00)/250)*100;
				}
				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
				rt_pwm_enable(pwm3_dev,PWM_DEV_CHANNEL);
			}			
			
			rt_pin_write(RELAY_L, PIN_LOW);
			rt_hw_us_delay(5);
			rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
			cpcp_thread_flag = CP_Sampling_Eint;			//�жϲɼ�CP
			if(ChargeStartSwitch==1&&recharge_state_flag==1&&sk_switch!=0x01)
			{
				recharge_state_flag=0;
				recharge_state=2;
				RGB_YEL();
				rt_thread_delay(50);
				RGB_YEL();
				PilotLamp_Flag=0x0000;
				DwinContent_Flag=0x02;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
			}
		}
		else if(Charge_Flag == CP6VCharge_bit&&Pwm_Charge_Flag == PWM_Charge_bit)		//CP��ѹΪ6V
		{
//			rt_kprintf("CP6\n");
			if(PilotLamp_Flag<=0x0003)
			{
				PilotLamp_Flag=0x0002;
			}
			
			if(PWM_flag == Pwm_Open)
			{
				
				PWM_flag = Pwm_Close;			//PWM�ر�
				pwm3_pulse = PwmDC_100;			//CP��ѹһֱ�����ڸ�λ
				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
			}
							
			Relay_Flag = Relay_Close;			//�رռ̵���
			rt_pin_write(RELAY_L, PIN_LOW);
			rt_hw_us_delay(5);
			rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
			cpcp_thread_flag = CP_Sampling_Loop;			//ѭ���ɼ�CP
		}
		else if(Charge_Flag == CP6VCharge_bit&&(Pwm_Charge_Flag == PWM_CP6VCharge_bit||Pwm_Charge_Flag == PWM_CP9VCharge_bit))		//PWM CP��ѹΪ6V
		{
//			rt_kprintf("PWM_CP6\n");
			if(PilotLamp_Flag<=0x0003)
			{
				PilotLamp_Flag=0x0003;
			}
			if(cp_delay_flag==1)
			{
				cp_delay_flag=0;
				cp_delay_count=0;
				cp_delay_switch=1;
				recharge_state_flag=1;
//				recharge_state=5;
				PilotLamp_Flag=0x0003;
				DwinContent_Flag=0x02;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);	
			}
			if(cp_delay_count>=1000)
			{
				ChargeStartSwitch=1;
//				UrgencyLamp_Flag=0x00;								//���ϵƽ��
//				DwinContent_Flag=0x00;								//������ʾ�ر�
//				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				recharge_state=1;
				RGB_GER();
				rt_thread_delay(50);
				RGB_GER();
				PilotLamp_Flag=0x0003;
				DwinContent_Flag=0x02;								//������ʾ�ر�
				UrgencyLamp_Flag=0x00;
				emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
				
//				rt_adc_disable(adc1_dev, ADC1_DEV_CHANNEL10);		
				Relay_Flag = Relay_Open;			//�����̵���
				rt_pin_write(RELAY_L, PIN_HIGH);
				rt_hw_us_delay(5);
				rt_pin_write(RELAY_N, PIN_HIGH);				//�̵�����
//				rt_adc_enable(adc1_dev, ADC1_DEV_CHANNEL10);									//�ӵ�	
				
				cp_delay_switch=0;
				cp_delay_count=0;	
			}
			if(PWM_flag == Pwm_Close)
			{
				PWM_flag = Pwm_Open;			//PWM����
				if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>=6)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=51))
				{
					pwm3_pulse=(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max/60.00)*100;
				}
				else if((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max>52.5)&&(data_scpoe[OVERCURRENT].data_scope_par.data_scope_max<=63))
				{
					pwm3_pulse=((data_scpoe[OVERCURRENT].data_scope_par.data_scope_max+160.00)/250)*100;
				}
				rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);
				rt_pwm_enable(pwm3_dev,PWM_DEV_CHANNEL);
			}
			
			cpcp_thread_flag = CP_Sampling_Eint;			//�жϲɼ�CP
		}
		else	//�޷����
		{
			PilotLamp_Flag=0x0004;
			cpcp_thread_flag = CP_Sampling_Loop;			//ѭ���ɼ�CP
			Relay_Flag = Relay_Close;			//�رռ̵���
			rt_pin_write(RELAY_L, PIN_LOW);
			rt_hw_us_delay(5);
			rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
			Pwm_Charge_Flag = PWM_Charge_bit;
			PWM_flag = Pwm_Close;			//PWM��־�ر�
			pwm3_pulse=PwmDC_100;		
			rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);	//PWM����
		}
	}
	else	//�޷����
	{
		RGB_RED();
		cpcp_thread_flag = CP_Sampling_Loop;			//ѭ���ɼ�CP
		Relay_Flag = Relay_Close;			//�رռ̵���
		rt_pin_write(RELAY_L, PIN_LOW);
		rt_hw_us_delay(5);
		rt_pin_write(RELAY_N, PIN_LOW);				//�̵����ر�
		Pwm_Charge_Flag = PWM_Charge_bit;
		PWM_flag = Pwm_Close;			//PWM��־�ر�
		pwm3_pulse=PwmDC_100;		
		rt_pwm_set(pwm3_dev, PWM_DEV_CHANNEL, pwm3_period, pwm3_pulse*10000);	//PWM����
	}
}


//����߼�����
void Recharge_Combine()
{
	//�����ж�
		Electricity_Judge();
	//��ѹ�ж�
		Voltage_Judge();
	//©���ж�
	Electric_Judge();
	//�ӵ��ж�
	Ground_Judge();
	//�¶��ж�
	Temperature_Judge();
	//CP��ѹ�ж�
	Cp_Judge();
	//��ͣ�ж�
	Scram_Judge();
	//CP��ѹ�߼��ж�
	Cp_Logic_Judge();
	//��ʾ�ж�
	Show_Judge();
}

