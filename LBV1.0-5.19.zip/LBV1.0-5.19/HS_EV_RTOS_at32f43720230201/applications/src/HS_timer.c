#include <rtthread.h>
#include <rtdevice.h>
#include "HS_timer.h"
#include "HS_#define.h"  
#include "HS_main.h" 
#include <rthw.h>
#include <board.h>


//#define HWTIMER_DEV_NAME   "timer4"     /* ��ʱ������ */

////uint16_t timecounter4 = 0;
//unsigned char Theory_SamplingPoint = 0;
//unsigned long EffectiveGrounding = 0;


/* ��ʱ����ʱֵ */
rt_hwtimerval_t time2out_s,time3out_s,time4out_s,time5out_s,time6out_s;      

/* ��ʱ���豸��� */
rt_device_t time2_dev = RT_NULL;   
rt_device_t time3_dev = RT_NULL; 
rt_device_t time4_dev = RT_NULL; 
rt_device_t time5_dev = RT_NULL;
rt_device_t time6_dev = RT_NULL;

rt_hwtimer_mode_t mode;         /* ��ʱ��ģʽ */
rt_uint32_t freq = 10000;               /* ����Ƶ�� */

// ����������ʱ�����ƿ�
rt_timer_t tmr1 = RT_NULL,tmr2 = RT_NULL;
// �����õ���ȫ�ֱ���
//static rt_uint32_t TmrCb_Cnt1 = 0;
rt_hwtimerval_t time4_t;

uint16_t frequency_count_record1=0,frequency_count_record2=0,frequency_flag_record=0;
uint16_t led_count_fast=0,led_count_slow=0;


uint16_t sk_delay_count=0,cp_delay_count=0,ota_delay_count=0,ljcdsj_count=0,wl_overtime_count=0,show_delay_count=0,mqtt_device_pub_count=0;
uint8_t cp_delay_flag=0,ota_delay_flag=0,sk_delay_flag=0,show_delay_flag=0,mqtt_device_pub_flag=0;
uint8_t sk_delay_switch=1,ljcdsj_switch=0,cp_delay_switch=0,ota_delay_switch=0;

uint8_t wl_overtime_switch=0;

uint16_t xt_count,jcsj_count=270,cdgcbms_count=0,cdgcbmsxx_count=0,jyjlqr_overtime_count=0,lec_data_show_count=0;;


/* ��ʱ��5��ʱ�ص����� */
static rt_err_t time5out_cb(rt_device_t dev, rt_size_t size)
{
	
	//���������״̬ת�������ʱ
	if(eledj_delay_par.delay_switch==1)
	{
		eledj_delay_par.delay_count++;
		if(eledj_delay_par.delay_count>=5000)
		{
			eledj_delay_par.delay_flag=1;
			eledj_delay_par.delay_count=0;
			eledj_delay_par.delay_switch=0;
		}
	}
	
	//ˢ���쳣���Լ�ʱ
	if(cloud_skcw_delay_par.delay_switch==1)
	{
		cloud_skcw_delay_par.delay_count++;
		if(cloud_skcw_delay_par.delay_count>5000)
		{
			cloud_skcw_delay_par.delay_flag=1;
			cloud_skcw_delay_par.delay_switch=0;
			cloud_skcw_delay_par.delay_count=0;
		}
	}
	//��ѹ������ʱ
	if(data_scpoe[OVERVOLTAGE].data_delay_par.delay_switch==1)
	{
		data_scpoe[OVERVOLTAGE].data_delay_par.delay_count++;
		if(data_scpoe[OVERVOLTAGE].data_delay_par.delay_count==3000)
		{
			data_scpoe[OVERVOLTAGE].data_delay_par.delay_flag=1;
			
		}
	}
	//Ƿѹ������ʱ
	if(data_scpoe[UNDERVOLTAGE].data_delay_par.delay_switch==1)
	{
		data_scpoe[UNDERVOLTAGE].data_delay_par.delay_count++;
//		rt_kprintf("%d\n",data_scpoe[UNDERVOLTAGE].data_delay_par.delay_count);
		if(data_scpoe[UNDERVOLTAGE].data_delay_par.delay_count==3000)
		{
			data_scpoe[UNDERVOLTAGE].data_delay_par.delay_flag=1;
			
		}
	}
	
	//©�籨����ʱ
	if(data_scpoe[LEAKAGE].data_delay_par.delay_switch==1)
	{
		data_scpoe[LEAKAGE].data_delay_par.delay_count++;
		if(data_scpoe[LEAKAGE].data_delay_par.delay_count==3000)
		{
			data_scpoe[LEAKAGE].data_delay_par.delay_flag=1;
			
		}
	}
	
	//����������ʱ
	if(data_scpoe[OVERCURRENT].data_delay_par.delay_switch==1)
	{
		data_scpoe[OVERCURRENT].data_delay_par.delay_count++;
//		rt_kprintf("time:%d\n",data_scpoe[OVERCURRENT].data_delay_par.delay_count);
		if(data_scpoe[OVERCURRENT].data_delay_par.delay_count==3000)
		{
			data_scpoe[OVERCURRENT].data_delay_par.delay_flag=1;
		}
	}
	

	//�ӵر�����ʱ
	if(data_scpoe[GROUNDING].data_delay_par.delay_switch==1)
	{
		data_scpoe[GROUNDING].data_delay_par.delay_count++;
//		rt_kprintf("%d\n",data_scpoe[GROUNDING].data_delay_par.delay_count);
		if(data_scpoe[GROUNDING].data_delay_par.delay_count==1)
		{
			data_scpoe[GROUNDING].data_delay_par.delay_flag=1;
			
		}
	}
	
	//�¶ȱ�����ʱ
	if(data_scpoe[TEMPERATURE].data_delay_par.delay_switch==1)
	{
		data_scpoe[TEMPERATURE].data_delay_par.delay_count++;
		if(data_scpoe[TEMPERATURE].data_delay_par.delay_count==3000)
		{
			data_scpoe[TEMPERATURE].data_delay_par.delay_flag=1;
			
		}
	}
	
	//CP������ʱ
	if(data_scpoe[CP9].data_delay_par.delay_switch==1)
	{
		data_scpoe[CP9].data_delay_par.delay_count++;
//		rt_kprintf("data_delay_par.delay_count��%d\n",data_scpoe[CP9].data_delay_par.delay_count);
		if(data_scpoe[CP9].data_delay_par.delay_count==50)
		{
			data_scpoe[CP9].data_delay_par.delay_count=0;
			data_scpoe[CP9].data_delay_par.delay_flag=1;
			
		}
	}
	
	
	
	
  return 0;
}


uint16_t rgb_delay_count=0;
uint8_t rgb_delay_flag=0;


/* ��ʱ��2��ʱ�ص����� 1s*/
static rt_err_t time2out_cb(rt_device_t dev, rt_size_t size)
{
	if(Relay_Flag == Relay_Open)
	{
		rgb_delay_count++;
		if(rgb_delay_count==50)
		{
			WS281x_SetPixelRGB(0,0,255,0);
			WS281x_Show();
	//		WS281x_CloseAll();

		}
		else if(rgb_delay_count==100)
		{
			WS281x_SetPixelRGB(1,0,255,0);
			WS281x_Show();
	//		WS281x_CloseAll();

		}
		else if(rgb_delay_count==150)
		{
			WS281x_SetPixelRGB(2,0,255,0);
			WS281x_Show();
	//		WS281x_CloseAll();

		}
		else if(rgb_delay_count==200)
		{
			WS281x_SetPixelRGB(3,0,255,0);
			WS281x_Show();
	//		WS281x_CloseAll();
		}
		else if(rgb_delay_count==250)
		{
			WS281x_SetPixelRGB(4,0,255,0);
			WS281x_Show();
		}
		else if(rgb_delay_count==300)
		{
			WS281x_SetPixelRGB(5,0,255,0);
			WS281x_Show();
//			WS281x_CloseAll();
//			rgb_delay_count=0;
		}
		else if(rgb_delay_count==400)
		{
//		WS281x_SetPixelRGB(5,0,255,0);
//		WS281x_Show();
			WS281x_CloseAll();
			rgb_delay_count=0;
		}
		
	}
	
	
	
	sk_delay_count++;
	if(sk_delay_count==1000)
	{
		sk_delay_flag=1;
	}
	
	
	
	if(cp_delay_switch==1)
	{
		cp_delay_count++;
	}
	
	if(accomplish_sd_flag==0)
	{
		led_count_fast++;
		if(led_count_fast==800)
		{
			rt_pin_write(PIN_LED,PIN_HIGH);
		}
		else if(led_count_fast>=1600)
		{
			rt_pin_write(PIN_LED,PIN_LOW);
			led_count_fast=0;
		}
	}
	else if(accomplish_sd_flag==1)
	{
		led_count_slow++;
		if(led_count_slow==200)
		{
			rt_pin_write(PIN_LED,PIN_HIGH);
		}
		else if(led_count_slow>=400)
		{
			rt_pin_write(PIN_LED,PIN_LOW);
			led_count_slow=0;
		}
	}
	
}


/* ��ʱ��4��ʱ�ص����� 1s*/
static rt_err_t time4out_cb(rt_device_t dev, rt_size_t size)
{
	jcsj_count++;
	lec_data_show_count++;
	cdgcbmsxx_count++;
	wcq_overtime_count++;
	jyjlqr_overtime_count++;
	xt_count++;
	cdgcbms_count++;
	show_data_par.delay_count++;
	mqtt_device_pub_count++;
	
	if(mqtt_device_pub_count>18)
	{
		mqtt_device_pub_flag=1;
		mqtt_device_pub_count=0;
	}
	
	if(show_data_par.delay_count>=3)
	{
		show_data_par.delay_count=0;
		show_data_par.delay_flag=1;
	}
	
	if(ljcdsj_switch==1)
	{
		ljcdsj_count++;
		if(ljcdsj_count==60)
		{
			cloud_jcsj.ljcdsjmin++;
			if(cloud_jcsj.ljcdsjmin==60)
			{
				cloud_jcsj.ljcdsjhour++;
			}
			ljcdsj_count=0;
		}
		
	}

	if(lec_data_show_count>1)
	{
		lec_data_show_count=1;
	}
	if(sssj_timer_cut==1)
	{
		if(jcsj_count>15)
		{
			jcsj_count=15;
		}
	}
	else if(sssj_timer_cut==2)
	{
		if(jcsj_count>300)
		{
			jcsj_count=300;
		}
	}
	
	if(wl_delay_par.delay_switch==1)
	{
		wl_delay_par.delay_count++;
//		rt_kprintf("wl_delay_par.delay_count:%d\n",wl_delay_par.delay_count);
		if(wl_delay_par.delay_count>=60)
		{
			wl_delay_par.delay_flag=1;
			wl_delay_par.delay_count=0;
		}
		
	}
	
	if(cdgcbmsxx_count>15)
	{
		cdgcbmsxx_count=15;
	}
	
	if(wcq_overtime_count>60)
	{
		wcq_overtime_count=60;
	}
	if(jyjlqr_overtime_count>30)
	{
		jyjlqr_overtime_count=30;
	}
	if(xt_count>10)
	{
		xt_count=10;
	}
	if(cdgcbms_count>15)
	{
		cdgcbms_count=15;
	}
	
	
	if(ota_delay_switch==1)
	{
		ota_delay_count++;
		if(ota_delay_count==3600)
		{
			ota_delay_count=0;
			ota_delay_switch=0;
			ota_delay_flag=1;
		}
	}
	
	if(mqtt_delay_par.delay_switch==1)
	{
//		rt_kprintf("mqtt_delay_par.delay_count:%d\n",mqtt_delay_par.delay_count);
		mqtt_delay_par.delay_count++;
		if(mqtt_delay_par.delay_count>=mqtt_interval_time*60)
		{
			mqtt_delay_par.delay_flag=1;
			mqtt_delay_par.delay_count=0;
		}
	}
	
	
}


uint16_t count;
/* ��ʱ��6��ʱ�ص����� 1s*/
static rt_err_t time6out_cb(rt_device_t dev, rt_size_t size)
{
	
	count++;
//	rt_kprintf("%d\n",count);
}







int hwtimer_init()
{

//  /* ���Ҷ�ʱ���豸 */
  time2_dev = rt_device_find(HWTIMER_DEV_TIME2);
//	time3_dev = rt_device_find(HWTIMER_DEV_TIME3);
	time4_dev = rt_device_find(HWTIMER_DEV_TIME4);
	time5_dev = rt_device_find(HWTIMER_DEV_TIME5);
//	time6_dev = rt_device_find(HWTIMER_DEV_TIME6);

//  /* �Զ�д��ʽ���豸 */
  rt_device_open(time2_dev, RT_DEVICE_OFLAG_RDWR);
//	rt_device_open(time3_dev, RT_DEVICE_OFLAG_RDWR);
	rt_device_open(time4_dev, RT_DEVICE_OFLAG_RDWR);
	rt_device_open(time5_dev, RT_DEVICE_OFLAG_RDWR);
//	rt_device_open(time6_dev, RT_DEVICE_OFLAG_RDWR);

//  /* ���ó�ʱ�ص����� */
  rt_device_set_rx_indicate(time2_dev, time2out_cb);
//	rt_device_set_rx_indicate(time3_dev, time3out_cb);
	rt_device_set_rx_indicate(time4_dev, time4out_cb);
	rt_device_set_rx_indicate(time5_dev, time5out_cb);
//	rt_device_set_rx_indicate(time6_dev, time6out_cb);

//  /* ���ü���Ƶ��(��δ���ø��Ĭ��Ϊ1Mhz �� ֧�ֵ���С����Ƶ��) */
  rt_device_control(time2_dev, HWTIMER_CTRL_FREQ_SET, &freq);
//	rt_device_control(time3_dev, HWTIMER_CTRL_FREQ_SET, &freq);
	rt_device_control(time4_dev, HWTIMER_CTRL_FREQ_SET, &freq);
	rt_device_control(time5_dev, HWTIMER_CTRL_FREQ_SET, &freq);
//	rt_device_control(time6_dev, HWTIMER_CTRL_FREQ_SET, &freq);
//		
//  /* ����ģʽΪ�����Զ�ʱ������δ���ã�Ĭ����HWTIMER_MODE_ONESHOT��*/
  mode = HWTIMER_MODE_PERIOD;
  rt_device_control(time2_dev, HWTIMER_CTRL_MODE_SET, &mode);
//	rt_device_control(time3_dev, HWTIMER_CTRL_MODE_SET, &mode);
	rt_device_control(time4_dev, HWTIMER_CTRL_MODE_SET, &mode);
	rt_device_control(time5_dev, HWTIMER_CTRL_MODE_SET, &mode);
//	rt_device_control(time6_dev, HWTIMER_CTRL_MODE_SET, &mode);

//  /* ���ö�ʱ��2��ʱֵ */
  time2out_s.sec = 0;
  time2out_s.usec = 1000;
//	/* ���ö�ʱ��3��ʱֵ */
//  time3out_s.sec = 1;
//  time3out_s.usec = 0;
	/* ���ö�ʱ��4��ʱֵ */
  time4out_s.sec =1;
  time4out_s.usec = 0;
//	/* ���ö�ʱ��5��ʱֵ */
  time5out_s.sec = 0;
  time5out_s.usec = 1000;
////	/* ���ö�ʱ��6��ʱֵ */
//	time6out_s.sec = 1;
//  time6out_s.usec = 0;
  rt_device_write(time2_dev, 0, &time2out_s, sizeof(time2out_s));
//	rt_device_write(time3_dev, 0, &time3out_s, sizeof(time3out_s));
	rt_device_write(time4_dev, 0, &time4out_s, sizeof(time4out_s));
	rt_device_write(time5_dev, 0, &time5out_s, sizeof(time5out_s));
//	rt_device_write(time6_dev, 0, &time6out_s, sizeof(time6out_s));
		
   
}
//INIT_DEVICE_EXPORT(hwtimer_init);
