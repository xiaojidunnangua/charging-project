//###########################################################################
//
// �ļ���:   xxx.c
//
// ����:   
//
//����: Liu
// ����:
// 
//

//
//###########################################################################
// ��������: 2022.11.30
//###########################################################################

#include <rtthread.h>
#include <rtdevice.h>
#include "drv_common.h"
#include "drv_gpio.h"

#include "HS_#define.h"  


//void GPIO_OUT_LEVEL(rt_base_t GPIOx_pin,UINT8 LEVEL)
//{
//	rt_pin_mode(GPIOx_pin, PIN_MODE_OUTPUT);
//	if(LEVEL == 0)
//	rt_pin_write(GPIOx_pin, PIN_LOW);
//	else
//	rt_pin_write(GPIOx_pin, PIN_HIGH);
//}
//int GPIO_IN_LEVEL(rt_base_t GPIOx_pin)
//{
//	rt_pin_mode(GPIOx_pin, PIN_MODE_INPUT);
//  return rt_pin_read(GPIOx_pin);
//}
/***************************************GPIO��ʼ��*********************************************/
void InitGpio_USER(void)			//GPIO��ʼ��
{     
//---------------------------------------�����������
	rt_pin_mode(LED_R, PIN_MODE_OUTPUT);					rt_pin_write(LED_R, PIN_LOW);
	rt_pin_mode(LED_G, PIN_MODE_OUTPUT);					rt_pin_write(LED_G, PIN_LOW);
	rt_pin_mode(LED_B, PIN_MODE_OUTPUT);					rt_pin_write(LED_B, PIN_LOW);
	rt_pin_mode(L610_RST, PIN_MODE_OUTPUT);				//rt_pin_write(L610_RST, PIN_LOW);
	rt_pin_mode(RELAY_L, PIN_MODE_OUTPUT);				//rt_pin_write(RELAY_L, PIN_LOW);
	rt_pin_mode(RELAY_N, PIN_MODE_OUTPUT);				//rt_pin_write(RELAY_N, PIN_LOW);
	rt_pin_mode(WIFIBT_EN, PIN_MODE_OUTPUT);			rt_pin_write(WIFIBT_EN, PIN_LOW);
	rt_pin_mode(ID_RST, PIN_MODE_OUTPUT);					//rt_pin_write(ID_RST, PIN_LOW);
	rt_pin_mode(RS485_CONTROL, PIN_MODE_OUTPUT);	rt_pin_write(RS485_CONTROL, PIN_LOW);
	rt_pin_mode(EMAC_ETH_RESET, PIN_MODE_OUTPUT);	rt_pin_write(EMAC_ETH_RESET, PIN_LOW);
	rt_pin_mode(RS16_CS, PIN_MODE_OUTPUT);				rt_pin_write(RS16_CS, PIN_LOW);
	
	rt_pin_mode(RC522_CS, PIN_MODE_OUTPUT);				rt_pin_write(RC522_CS, PIN_LOW);
	rt_pin_mode(RC522_SCK, PIN_MODE_OUTPUT);			rt_pin_write(RC522_SCK, PIN_LOW);
	rt_pin_mode(RC522_MISO, PIN_MODE_INPUT);			
	rt_pin_mode(RC522_MOSI, PIN_MODE_OUTPUT);			rt_pin_write(RC522_MOSI, PIN_LOW);
	rt_pin_mode(RC522_RST, PIN_MODE_OUTPUT);			rt_pin_write(RC522_RST, PIN_HIGH);
	
  rt_pin_mode(PIN_LED, PIN_MODE_OUTPUT);				rt_pin_write(PIN_LED, PIN_LOW);
//---------------------------------------������������	
	rt_pin_mode(KEY, PIN_MODE_INPUT);
	rt_pin_mode(EMERGENCY_STOP, PIN_MODE_INPUT);
	rt_pin_mode(EV_CC, PIN_MODE_INPUT);
	rt_pin_mode(ELECTRIC_ENERGY_POLSE, PIN_MODE_INPUT);
	rt_pin_mode(ZERO_CROSSING, PIN_MODE_INPUT);
	rt_pin_mode(ELECTRIC_LEAKAGE, PIN_MODE_INPUT);
	
//	rt_pin_write(WIFIBT_EN,PIN_HIGH);
//	rt_hw_us_delay(500000);
//rt_thread_mdelay(500);
//	rt_pin_write(WIFIBT_EN,PIN_LOW);
	rt_thread_mdelay(500);
		rt_pin_write(WIFIBT_EN,PIN_HIGH);
}





