#include <rtthread.h>
#include <rtdevice.h>
#include "string.h"
#include "HS_Dds3366d.h"
#include "HS_main.h"
#include "HS_#define.h"
#include "HS_crc.h"
#include "rs485.h"
#include "HS_BL24512.h"
#include "HS_uart.h"

//��������һ�μ�¼,�����ֵֹ
uint32_t cdds_one=0,dbzzz_son=0;





//ǰ���ֽ�
uint8_t ds3366_read_bellwether[4]={0xFE,0xFE,0xFE,0xFE};
//�㲥��ַ
uint8_t ds3366_read_addr[6]={0xAA,0xAA,0xAA,0xAA,0xAA,0xAA};
//�豸��ַ
uint8_t ds3366_addr[6]={0x00};

uint16_t dds3366_send(uint8_t *data,uint16_t len)
{
	rt_pin_write(RS485_CONTROL, PIN_HIGH);
	uart_tx_string(USART3,data,len);
//	rt_device_write(uart3,0,data,len);
	rt_pin_write(RS485_CONTROL, PIN_LOW);
}

//������
uint8_t* Dds3366_Read(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data)
{
	uint8_t write_data[50]={0x00};
	uint8_t write_data_crc[30]={0x00};
	static uint8_t write_data_return[100]={0x00};
	rt_memcpy((char *)write_data,(char *)ds3366_read_bellwether,4);
	write_data[4]=0x68;
	rt_memcpy((char *)&write_data[5],(char *)addr,6);
	write_data[11]=0x68;
	write_data[12]=control;
	write_data[13]=read_len;
	for(int t=0;t<read_len;t++)
	{
		write_data[t+14]=read_data[t];
	}

	
	rt_memcpy((char *)write_data_crc,(char *)&write_data[4],13+read_len);
	write_data[14+read_len]=checksum8(write_data_crc,10+read_len);
	write_data[15+read_len]=0x16;
	dds3366_send(write_data,14+read_len+2);
	rt_thread_delay(100);
	if(uart3_device.uart_flag==1)
	{
		uint8_t ds3366_offset_addr=0;
		for(int t=0;t<255;t++)
		{
			if(uart3_device.uart_rx_buffer[t]==0x68&&uart3_device.uart_rx_buffer[t+7]==0x68)
			{
				ds3366_offset_addr=t;
				break;
			}
		}
		if(uart3_device.uart_rx_buffer[0+ds3366_offset_addr]==0x68&&uart3_device.uart_rx_buffer[7+ds3366_offset_addr]==0x68)
		{
			
			rt_memcpy((char *)write_data_return,(char *)&uart3_device.uart_rx_buffer[0+ds3366_offset_addr],10+(uart3_device.uart_rx_buffer[9+ds3366_offset_addr]+2));
			
			rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
			
			
		}
		return write_data_return;
//		write_data_return[0]=0xF5;
//		return write_data_return;

	}
}



//������
uint8_t* Dds3366_Read_Addr(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data)
{
	uint8_t write_data[50]={0x00};
	uint8_t write_data_crc[30]={0x00};
	static uint8_t write_data_return[100]={0x00};
	rt_memcpy((char *)write_data,(char *)ds3366_read_bellwether,4);
	write_data[4]=0x68;
	rt_memcpy((char *)&write_data[5],(char *)addr,6);
	write_data[11]=0x68;
	write_data[12]=control;
	write_data[13]=read_len;
	for(int t=0;t<read_len;t++)
	{
		write_data[t+14]=read_data[t];
	}

	
	rt_memcpy((char *)write_data_crc,(char *)&write_data[4],13+read_len);
	write_data[14+read_len]=checksum8(write_data_crc,10+read_len);
	write_data[15+read_len]=0x16;
	rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
	dds3366_send(write_data,14+read_len+2);
	rt_thread_delay(300);
	if(uart3_device.uart_flag==1)
	{
		uint8_t ds3366_offset_addr=0;
		for(int t=0;t<255;t++)
		{
			if(uart3_device.uart_rx_buffer[t]==0x68&&uart3_device.uart_rx_buffer[t+7]==0x68)
			{
				ds3366_offset_addr=t;
				break;
			}
		}
		if(uart3_device.uart_rx_buffer[0+ds3366_offset_addr]==0x68&&uart3_device.uart_rx_buffer[7+ds3366_offset_addr]==0x68)
		{
			
			rt_memcpy((char *)write_data_return,(char *)&uart3_device.uart_rx_buffer[0+ds3366_offset_addr],10+(uart3_device.uart_rx_buffer[9+ds3366_offset_addr]+2));
			for(int t=0;t<6;t++)
			{
				ds3366_addr[t]=write_data_return[t+1];
			}
			rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
			
			
		}
		return write_data_return;
//		write_data_return[0]=0xF5;
//		return write_data_return;

	}
}



//������
uint8_t* Dds3366_Read_I(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data)
{
	uint8_t write_data[50]={0x00};
	uint8_t write_data_crc[30]={0x00};
	static uint8_t write_data_return[100]={0x00};
	rt_memcpy((char *)write_data,(char *)ds3366_read_bellwether,4);
	write_data[4]=0x68;
	rt_memcpy((char *)&write_data[5],(char *)addr,6);
	write_data[11]=0x68;
	write_data[12]=control;
	write_data[13]=read_len;
	for(int t=0;t<read_len;t++)
	{
		write_data[t+14]=read_data[t];
	}

	rt_memcpy((char *)write_data_crc,(char *)&write_data[4],13+read_len);
	write_data[14+read_len]=checksum8(write_data_crc,10+read_len);
	write_data[15+read_len]=0x16;
	rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
	dds3366_send(write_data,14+read_len+2);
	rt_thread_delay(300);
	if(uart3_device.uart_flag==1)
	{
		uint8_t ds3366_offset_addr=0;
		for(int t=0;t<255;t++)
		{
			if(uart3_device.uart_rx_buffer[t]==0x68&&uart3_device.uart_rx_buffer[t+7]==0x68)
			{
				ds3366_offset_addr=t;
				break;
			}
		}
		if(uart3_device.uart_rx_buffer[0+ds3366_offset_addr]==0x68&&uart3_device.uart_rx_buffer[7+ds3366_offset_addr]==0x68)
		{
			
			rt_memcpy((char *)write_data_return,(char *)&uart3_device.uart_rx_buffer[0+ds3366_offset_addr],10+(uart3_device.uart_rx_buffer[9+ds3366_offset_addr]+2));

			rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
			
			
		}

		
		
		uint32_t read_return=0;
		uint8_t read_return_str[20]={0x00};



		if(write_data_return[8]==0x91&&write_data_return[10]==0x33&&write_data_return[11]==0x34&&write_data_return[12]==0x35&&write_data_return[13]==0x35)
		{
			read_return=(((uint16_t)(write_data_return[16]-0x33)<<16)+((uint16_t)(write_data_return[15]-0x33)<<8)+((uint16_t)(write_data_return[14]-0x33)));
			rt_sprintf((char *)read_return_str,"%x",read_return);
			read_return=strtol((char *)read_return_str,NULL,0);
			data_scpoe[OVERCURRENT].data=read_return;
			read_modbus_buffer[12]=data_scpoe[OVERCURRENT].data>>16;
			read_modbus_buffer[13]=data_scpoe[OVERCURRENT].data>>8;
			
		}

	}
}


//������
uint8_t* Dds3366_Read_V(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data)
{
	uint8_t write_data[50]={0x00};
	uint8_t write_data_crc[30]={0x00};
	uint8_t write_data_return[100]={0x00};
	rt_memcpy((char *)write_data,(char *)ds3366_read_bellwether,4);
	write_data[4]=0x68;
	for(int t=0;t<6;t++)
	{
		write_data[t+5]=addr[t];
	}
//	rt_memcpy((char *)&write_data[5],(char *)addr,6);
	write_data[11]=0x68;
	write_data[12]=control;
	write_data[13]=read_len;
	for(int t=0;t<read_len;t++)
	{
		write_data[t+14]=read_data[t];
	}

	rt_memcpy((char *)write_data_crc,(char *)&write_data[4],13+read_len);
	write_data[14+read_len]=checksum8(write_data_crc,10+read_len);
	write_data[15+read_len]=0x16;
	rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
	dds3366_send(write_data,14+read_len+2);
	rt_thread_delay(300);
	if(uart3_device.uart_flag==1)
	{
		uint8_t ds3366_offset_addr=0;
		for(int t=0;t<255;t++)
		{
			if(uart3_device.uart_rx_buffer[t]==0x68&&uart3_device.uart_rx_buffer[t+7]==0x68)
			{
				ds3366_offset_addr=t;
				break;
			}
		}
		if(uart3_device.uart_rx_buffer[0+ds3366_offset_addr]==0x68&&uart3_device.uart_rx_buffer[7+ds3366_offset_addr]==0x68)
		{
			
			rt_memcpy((char *)write_data_return,(char *)&uart3_device.uart_rx_buffer[0+ds3366_offset_addr],10+(uart3_device.uart_rx_buffer[9+ds3366_offset_addr]+2));

		}
		
		
		
		
		
		uint32_t read_return=0;
		uint8_t read_return_str[20]={0x00};

		if(write_data_return[8]==0x91&&write_data_return[10]==0x33&&write_data_return[11]==0x34&&write_data_return[12]==0x34&&write_data_return[13]==0x35)
		{
			read_return=(((uint16_t)(write_data_return[15]-0x33)<<8)+((uint16_t)(write_data_return[14]-0x33)));
			rt_sprintf((char *)read_return_str,"%x",read_return);
			read_return=strtol((char *)read_return_str,NULL,0);
			data_scpoe[OVERVOLTAGE].data=read_return*10;
			data_scpoe[UNDERVOLTAGE].data=read_return*10;
			read_modbus_buffer[8]=data_scpoe[OVERVOLTAGE].data>>8;
			read_modbus_buffer[9]=data_scpoe[OVERVOLTAGE].data;
		}

	}
}


uint32_t electric_energy_data=0;

//������
uint8_t* Dds3366_Read_Init_E(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data)
{
	uint8_t write_data[50]={0x00};
	uint8_t write_data_crc[30]={0x00};
	static uint8_t write_data_return[100]={0x00};
	
	uint32_t read_return=0;
	uint8_t read_return_str[20]={0x00};
	uint8_t read_ve_data[20]={0x00};
	
	rt_memcpy((char *)write_data,(char *)ds3366_read_bellwether,4);
	write_data[4]=0x68;
	rt_memcpy((char *)&write_data[5],(char *)addr,6);
	write_data[11]=0x68;
	write_data[12]=control;
	write_data[13]=read_len;
	for(int t=0;t<read_len;t++)
	{
		write_data[t+14]=read_data[t];
	}

	rt_memcpy((char *)write_data_crc,(char *)&write_data[4],13+read_len);
	write_data[14+read_len]=checksum8(write_data_crc,10+read_len);
	write_data[15+read_len]=0x16;
	rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
	dds3366_send(write_data,14+read_len+2);
	rt_thread_delay(100);
	if(uart3_device.uart_flag==1)
	{
		uint8_t ds3366_offset_addr=0;
		for(int t=0;t<255;t++)
		{
			if(uart3_device.uart_rx_buffer[t]==0x68&&uart3_device.uart_rx_buffer[t+7]==0x68)
			{
				ds3366_offset_addr=t;
				break;
			}
		}
		if(uart3_device.uart_rx_buffer[0+ds3366_offset_addr]==0x68&&uart3_device.uart_rx_buffer[7+ds3366_offset_addr]==0x68)
		{
			
			rt_memcpy((char *)write_data_return,(char *)&uart3_device.uart_rx_buffer[0+ds3366_offset_addr],10+(uart3_device.uart_rx_buffer[9+ds3366_offset_addr]+2));

			rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);

			
		}


//		rt_memcpy((char *)read_ve_data,(char *)&write_data_return[0],20);
		if(write_data_return[8]==0x91&&write_data_return[10]==0x33&&write_data_return[11]==0x33&&write_data_return[12]==0x33&&write_data_return[13]==0x33)
		{
			read_return=(((uint16_t)(write_data_return[17]-0x33)<<24)+((uint16_t)(write_data_return[16]-0x33)<<16)+((uint16_t)(write_data_return[15]-0x33)<<8)+((uint16_t)(write_data_return[14]-0x33)));
			rt_sprintf((char *)read_return_str,"%x",read_return);
			read_return=strtol((char *)read_return_str,NULL,0);
			
			Electric_Energy_Select=read_return*100;
			read_modbus_buffer[24]=Electric_Energy_Select>>24;
			read_modbus_buffer[25]=Electric_Energy_Select>>16;
			
		}

	}
}


//������
uint8_t* Dds3366_Read_E(uint8_t *addr,uint8_t control,uint8_t read_len,uint8_t* read_data)
{
	uint8_t write_data[50]={0x00};
	uint8_t write_data_crc[30]={0x00};
	static uint8_t write_data_return[100]={0x00};
	
	uint32_t read_return=0;
	uint8_t read_return_str[20]={0x00};
	uint8_t read_ve_data[20]={0x00};
	
	rt_memcpy((char *)write_data,(char *)ds3366_read_bellwether,4);
	write_data[4]=0x68;
	rt_memcpy((char *)&write_data[5],(char *)addr,6);
	write_data[11]=0x68;
	write_data[12]=control;
	write_data[13]=read_len;
	for(int t=0;t<read_len;t++)
	{
		write_data[t+14]=read_data[t];
	}

	rt_memcpy((char *)write_data_crc,(char *)&write_data[4],13+read_len);
	write_data[14+read_len]=checksum8(write_data_crc,10+read_len);
	write_data[15+read_len]=0x16;
	rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
	dds3366_send(write_data,14+read_len+2);
	rt_thread_delay(300);
	if(uart3_device.uart_flag==1)
	{
		uint8_t ds3366_offset_addr=0;
		for(int t=0;t<255;t++)
		{
			if(uart3_device.uart_rx_buffer[t]==0x68&&uart3_device.uart_rx_buffer[t+7]==0x68)
			{
				ds3366_offset_addr=t;
				break;
			}
		}
		if(uart3_device.uart_rx_buffer[0+ds3366_offset_addr]==0x68&&uart3_device.uart_rx_buffer[7+ds3366_offset_addr]==0x68)
		{
			
			rt_memcpy((char *)write_data_return,(char *)&uart3_device.uart_rx_buffer[0+ds3366_offset_addr],10+(uart3_device.uart_rx_buffer[9+ds3366_offset_addr]+2));

			rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);

			
		}



		if(write_data_return[8]==0x91&&write_data_return[10]==0x33&&write_data_return[11]==0x33&&write_data_return[12]==0x33&&write_data_return[13]==0x33)
		{
			read_return=(((uint16_t)(write_data_return[17]-0x33)<<24)+((uint16_t)(write_data_return[16]-0x33)<<16)+((uint16_t)(write_data_return[15]-0x33)<<8)+((uint16_t)(write_data_return[14]-0x33)));
			rt_sprintf((char *)read_return_str,"%x",read_return);
			read_return=strtol((char *)read_return_str,NULL,0);
			
//			if((electric_energy_data-Electric_Energy_Select)<1000)
//			{
				Electric_Energy_Select=read_return*100;
				
				read_modbus_buffer[24]=Electric_Energy_Select>>24;
				read_modbus_buffer[25]=Electric_Energy_Select>>16;
//			}
			
		}

	}
}





//��ȡ�豸��ַ
void Read_Device_Addr()
{
	uint8_t *read_buffer=0;
	uint8_t read_data[4]={0x00},read_len=0x00,control=0x13;
	uint8_t addr[6]={0xAA,0xAA,0xAA,0xAA,0xAA,0xAA};
	read_buffer=Dds3366_Read(addr,control,read_len,read_data);
	if(read_buffer[0]==0xF5)
	{
		Read_Device_Addr();
	}
	else
	{
		rt_memcpy((char *)ds3366_addr,(char *)&read_buffer[1],6);
	}
//	for(int t=0;t<6;t++)
//	{
//		ds3366_addr[t]=read_buffer[t+1];
//	}
	
}

//��ȡ�豸����
uint32_t Read_Device_Ey(uint8_t *addr)
{
	uint8_t *read_buffer;
	uint32_t read_return=0;
	uint8_t read_return_str[20]={0x00};
	uint8_t read_ve_data[20]={0x00};
	uint8_t control=0x11,read_len=4;
	uint8_t read_control_data[4]={0x33,0x33,0x33,0x33};//7357
	read_buffer=Dds3366_Read(addr,control,read_len,read_control_data);


		rt_memcpy((char *)read_ve_data,(char *)&read_buffer[0],20);
		if(read_ve_data[8]==0x91)
		{
			read_return=(((uint16_t)(read_ve_data[17]-0x33)<<24)+((uint16_t)(read_ve_data[16]-0x33)<<16)+((uint16_t)(read_ve_data[15]-0x33)<<8)+((uint16_t)(read_ve_data[14]-0x33)));
			rt_sprintf((char *)read_return_str,"%x",read_return);
			read_return=strtol((char *)read_return_str,NULL,0);
			
		}
	//		rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
		return read_return;

	
	
	
}


//��ȡ�豸��ѹ
uint16_t Read_Device_Ve(uint8_t *addr)
{
	uint8_t *read_buffer;
	uint16_t read_return=0;
	uint8_t read_return_str[20]={0x00};
	uint8_t read_ve_data[20]={0x00};
	uint8_t control=0x11,read_len=4;
	uint8_t read_control_data[4]={0x33,0x34,0x34,0x35};
	read_buffer=Dds3366_Read(addr,control,read_len,read_control_data);
	rt_memcpy((char *)read_ve_data,(char *)&read_buffer[0],20);
	if(read_ve_data[8]==0x91)
	{
		read_return=(((uint16_t)(read_ve_data[15]-0x33)<<8)+((uint16_t)(read_ve_data[14]-0x33)));
		rt_sprintf((char *)read_return_str,"%x",read_return);
		read_return=strtol((char *)read_return_str,NULL,0);
		
	}
	return read_return;
//		rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
	
	
	
}

//��ȡ�豸����
uint32_t Read_Device_Ie(uint8_t *addr)
{
	uint8_t *read_buffer;
	uint32_t read_return=0;
	uint8_t read_return_str[20]={0x00};
	uint8_t read_ve_data[20]={0x00};
	uint8_t control=0x11,read_len=4;
	uint8_t read_control_data[4]={0x33,0x34,0x35,0x35};
	read_buffer=Dds3366_Read(addr,control,read_len,read_control_data);


		rt_memcpy((char *)read_ve_data,(char *)&read_buffer[0],20);
		if(read_ve_data[8]==0x91)
		{
			read_return=(((uint16_t)(read_ve_data[16]-0x33)<<16)+((uint16_t)(read_ve_data[15]-0x33)<<8)+((uint16_t)(read_ve_data[14]-0x33)));
			rt_sprintf((char *)read_return_str,"%x",read_return);
			read_return=strtol((char *)read_return_str,NULL,0);
			
		}
		return read_return;
//		rt_memcpy((char *)uart3_device.uart_rx_buffer,"\0",255);
		

	

	
}

uint32_t Dds3366_Read_Dn()
{
	
	static uint8_t tx_data[8]={0x01,0x03,0x00,0x00,0x00,0x02};
	static uint8_t crc_data[6];
	static uint32_t power_value=0;
	uint8_t len;
	for(int t=0;t<6;t++)
	{
		crc_data[t]=tx_data[t];
	}
	tx_data[6]=ModbusCRC(crc_data,6)>>8;
	tx_data[7]=ModbusCRC(crc_data,6);
	dds3366_send(tx_data,8);
	
	rt_thread_delay(10);
	if(uart3_device.uart_flag==1)
	{
		uint8_t tx_crc_data[7];																			//CRC����
		uint8_t tx_crc_lh[2];																				//CRC�ߵ�λ����
		for(int t=0;t<7;t++)
		{
			tx_crc_data[t]=uart3_device.uart_rx_buffer[t];
		}
		tx_crc_lh[0]=ModbusCRC(tx_crc_data,7)>>8;
		tx_crc_lh[1]=ModbusCRC(tx_crc_data,7);
		if(tx_crc_lh[0]==uart3_device.uart_rx_buffer[7]&&tx_crc_lh[1]==uart3_device.uart_rx_buffer[8])
		{
			power_value=(int)uart3_device.uart_rx_buffer[5]<<8;
			power_value=(power_value+(int)uart3_device.uart_rx_buffer[6])*100;
//			rt_kprintf("����2��%d\n",power_value);

			return power_value;
		}
	}
}


