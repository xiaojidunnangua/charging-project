#include <rtthread.h>
#include <rtdevice.h>
#include "string.h"
#include "HS_#define.h"
#include "HS_BL24512.h"
#include "HS_main.h"
#include "HS_modbus.h"
#include "HS_crc.h"
#include "HS_uart.h"

uint8_t write_modbus_buffer[400]={0x00};
uint8_t read_modbus_buffer[200]={0x00};
uint8_t slave_addr=0x01;				//��ַ

void rs485_send(uint8_t *data,uint16_t len)
{
	rt_pin_write(RS485_CONTROL, PIN_HIGH);
	uart_tx_string(USART3,data,len);
	rt_pin_write(RS485_CONTROL, PIN_LOW);
}

//02������
void modbus_02_function()
{
	if(uart3_device.uart_flag==1)
	{
		
		
		if(uart3_device.uart_rx_buffer[0]==slave_addr&&uart3_device.uart_rx_buffer[1]==0x02)
		{
			uint16_t reg_addr=0;
			uint16_t char_len=0;
			uint16_t uart3_data16_crc=0;
			uint8_t uart3_read_crc[6]={0x00},write_modbus_return_data[7]={0x00},uart3_return_crc[6]={0x00};
			uint16_t error_data=0x00,error_return_data=0x00;
			reg_addr=uart3_device.uart_rx_buffer[2];
			reg_addr=reg_addr<<8;
			reg_addr|=uart3_device.uart_rx_buffer[3];
			char_len=uart3_device.uart_rx_buffer[4];
			char_len=char_len<<8;
			char_len|=uart3_device.uart_rx_buffer[5];
			for(int t=0;t<6;t++)
			{
				uart3_read_crc[t]=uart3_device.uart_rx_buffer[t];
			}
			uart3_data16_crc=ModbusCRC(uart3_read_crc,6);
			if(uart3_data16_crc>>8==uart3_device.uart_rx_buffer[6]&&(uint8_t)uart3_data16_crc==uart3_device.uart_rx_buffer[7])
			{
				if(Errors_Data&0x0040)
				{
					error_data|=0x0001;
				}
				if(Errors_Data&0x0001)
				{
					error_data|=0x0002;
				}
				if(Errors_Data&0x0080)
				{
					error_data|=0x0004;
				}
				if(Errors_Data&0x2000)
				{
					error_data|=0x0008;
				}
				if(Errors_Data&0x0020)
				{
					error_data|=0x0010;
				}
				if(Errors_Data&0x0004)
				{
					error_data|=0x0020;
				}
				if(Errors_Data&0x0800)
				{
					error_data|=0x0040;
				}
				if(Errors_Data&0x0008||Errors_Data&0x0010)
				{
					error_data|=0x0080;
				}
				
				
				write_modbus_return_data[0]=slave_addr;
				write_modbus_return_data[1]=0x02;
				write_modbus_return_data[2]=0x02;
				write_modbus_return_data[3]=error_data>>8;
				write_modbus_return_data[4]=error_data;
				for(int t=0;t<5;t++)
				{
					uart3_return_crc[t]=write_modbus_return_data[t];
				}
				uart3_data16_crc=ModbusCRC(uart3_return_crc,5);
				write_modbus_return_data[5]=uart3_data16_crc>>8;
				write_modbus_return_data[6]=uart3_data16_crc;
				
				rs485_send(write_modbus_return_data,7);
				memset(uart3_device.uart_rx_buffer,'\0',sizeof(uart3_device.uart_rx_buffer));
			}
		}
//		uart3_device.uart_flag=0;
	}
}



//03������
void modbus_03_function()
{
	if(uart3_device.uart_flag==1)
	{
		
		if(uart3_device.uart_rx_buffer[0]==slave_addr&&uart3_device.uart_rx_buffer[1]==0x03)
		{
			uint16_t reg_addr=0;
			uint16_t reg_len=0;
			uint8_t char_len=0;
			uint8_t uart3_read_crc[255]={0x00},uart3_return_crc[255]={0x00};
			uint8_t read_modbus_return_data[255]={0x00};
			uint16_t uart3_data16_crc;
			uint8_t num=0;
			
			rt_err_t result;
			reg_addr=uart3_device.uart_rx_buffer[2];
			reg_addr=reg_addr<<8;
			reg_addr|=uart3_device.uart_rx_buffer[3];
			reg_len=uart3_device.uart_rx_buffer[4];
			reg_len=reg_len<<8;
			reg_len|=uart3_device.uart_rx_buffer[5];
			rt_thread_delay(10);
			for(int t=0;t<uart3_device.uart_rx_len-2;t++)
			{
				uart3_read_crc[t]=uart3_device.uart_rx_buffer[t];
			}
			uart3_data16_crc=ModbusCRC(uart3_read_crc,uart3_device.uart_rx_len-2);
			if(uart3_data16_crc>>8==uart3_device.uart_rx_buffer[uart3_device.uart_rx_len-2]&&(uint8_t)uart3_data16_crc==uart3_device.uart_rx_buffer[uart3_device.uart_rx_len-1])
			{
				read_modbus_return_data[0]=slave_addr;
				read_modbus_return_data[1]=0x03;
				read_modbus_return_data[2]=reg_len*2;
				for(int t=0;t<reg_len;t++)
				{
					for(int n=0x00;n<0x08;n++)
					{
						
						if(reg_addr==n)
						{
							
							read_modbus_return_data[(num*2)+3]=read_modbus_buffer[n*2];
							read_modbus_return_data[(2*num)+1+3]=read_modbus_buffer[(2*n)+1];
							num++;
						}
						
					}
					for(int n=0x08;n<0x2E;n++)
					{
						if(reg_addr==n)
						{
							
							read_modbus_return_data[(num*2)+3]=read_modbus_buffer[n*2]=write_modbus_buffer[(n*2)-16];
							read_modbus_return_data[(2*num)+1+3]=read_modbus_buffer[(2*n)+1]=write_modbus_buffer[(n*2)-15];
							num++;
						}
						
					}
					reg_addr=reg_addr+1;
				}
				for(int t=0;t<(reg_len*2)+3;t++)
				{
					uart3_return_crc[t]=read_modbus_return_data[t];
				}
				uart3_data16_crc=ModbusCRC(uart3_return_crc,(reg_len*2)+3);
				read_modbus_return_data[(reg_len*2)+3]=uart3_data16_crc>>8;
				read_modbus_return_data[(reg_len*2)+3+1]=uart3_data16_crc;
				rs485_send(read_modbus_return_data,(reg_len*2)+5);
				memset(uart3_device.uart_rx_buffer,'\0',sizeof(uart3_device.uart_rx_buffer));
			}
		}
	}
}



void modbus_05_function()
{
	if(uart3_device.uart_flag==1)
	{
		
		if(uart3_device.uart_rx_buffer[0]==slave_addr&&uart3_device.uart_rx_buffer[1]==0x05)
		{
			uint16_t reg_addr=0;
			uint16_t control_command=0;
			uint8_t uart3_read_crc[255]={0x00},uart3_return_crc[255]={0x00};
			uint8_t write_modbus_return_data[255]={0x00};
			uint16_t uart3_data16_crc;
			reg_addr=uart3_device.uart_rx_buffer[2];
			reg_addr=reg_addr<<8;
			reg_addr|=uart3_device.uart_rx_buffer[3];
			control_command=uart3_device.uart_rx_buffer[4];
			control_command=control_command<<8;
			control_command|=uart3_device.uart_rx_buffer[5];
			for(int t=0;t<6;t++)
			{
				uart3_read_crc[t]=uart3_device.uart_rx_buffer[t];
			}
			uart3_data16_crc=ModbusCRC(uart3_read_crc,6);
			if(uart3_data16_crc>>8==uart3_device.uart_rx_buffer[6]&&(uint8_t)uart3_data16_crc==uart3_device.uart_rx_buffer[7])
			{
				if(control_command==0xFF00)
				{
					if(reg_addr&0x0001)
					{
						rt_pin_write(RELAY_L,PIN_HIGH);
					}
					if(reg_addr&0x0002)
					{
						rt_pin_write(RELAY_N,PIN_HIGH);
					}
					if(reg_addr&0x0004)
					{
						rt_pin_write(PIN_BEEP,PIN_HIGH);
					}
					if(reg_addr&0x0008)
					{
						RGB_BLU();
					}
					if(reg_addr&0x0010)
					{
						RGB_GER();
					}
					if(reg_addr&0x0020)
					{
						RGB_RED();
					}
					if(reg_addr&0x0040)
					{
						rt_pin_write(PIN_LED,PIN_HIGH);
					}
					if(reg_addr&0x0080)
					{
						//Ԥ��
					}
					if(reg_addr&0x0100)
					{
						//Ԥ��
					}
					if(reg_addr&0x0100)
					{
						//Ԥ��
					}
					if(reg_addr&0x0200)
					{
						//Ԥ��
					}
					if(reg_addr&0x0400)
					{
						//Ԥ��
					}
					if(reg_addr&0x0800)
					{
						//Ԥ��
					}
					if(reg_addr&0x1000)
					{
						//Ԥ��
					}
				}
				else if(control_command==0x0000)
				{
					if(reg_addr&0x0001)
					{
						rt_pin_write(RELAY_L,PIN_LOW);
					}
					if(reg_addr&0x0002)
					{
						rt_pin_write(RELAY_N,PIN_LOW);
					}
					if(reg_addr&0x0004)
					{
						rt_pin_write(PIN_BEEP,PIN_LOW);
					}
					if(reg_addr&0x0008)
					{
						WS281x_CloseAll();
					}
					if(reg_addr&0x0010)
					{
						WS281x_CloseAll();
					}
					if(reg_addr&0x0020)
					{
						WS281x_CloseAll();
					}
					if(reg_addr&0x0040)
					{
						rt_pin_write(PIN_LED,PIN_LOW);
					}
					if(reg_addr&0x0080)
					{
						//Ԥ��
					}
					if(reg_addr&0x0100)
					{
						//Ԥ��
					}
					if(reg_addr&0x0100)
					{
						//Ԥ��
					}
					if(reg_addr&0x0200)
					{
						//Ԥ��
					}
					if(reg_addr&0x0400)
					{
						//Ԥ��
					}
					if(reg_addr&0x0800)
					{
						//Ԥ��
					}
					if(reg_addr&0x1000)
					{
						//Ԥ��
					}
				}
				rs485_send(uart3_device.uart_rx_buffer,8);
			}
		}
	}
}




//10������
void modbus_10_function()
{
	
	if(uart3_device.uart_flag==1)
	{
		

		if(uart3_device.uart_rx_buffer[0]==slave_addr&&uart3_device.uart_rx_buffer[1]==0x10)
		{
			uint16_t reg_addr=0;
			uint16_t reg_len=0;
			uint8_t char_len=0;
			uint8_t uart3_read_crc[255]={0x00},uart3_return_crc[255]={0x00};
			uint8_t write_modbus_return_data[255]={0x00};
			uint16_t uart3_data16_crc=0;
			
			rt_err_t result;
			reg_addr=uart3_device.uart_rx_buffer[2];
			reg_addr=reg_addr<<8;
			reg_addr|=uart3_device.uart_rx_buffer[3];
			reg_len=uart3_device.uart_rx_buffer[4];
			reg_len=reg_len<<8;
			reg_len|=uart3_device.uart_rx_buffer[5];
			char_len=uart3_device.uart_rx_buffer[6];
			rt_thread_delay(10);
			for(int t=0;t<uart3_device.uart_rx_len-2;t++)
			{
				rt_thread_delay(1);
				uart3_read_crc[t]=uart3_device.uart_rx_buffer[t];
			}
			uart3_data16_crc=ModbusCRC(uart3_read_crc,uart3_device.uart_rx_len-2);
			if(uart3_data16_crc>>8==uart3_device.uart_rx_buffer[uart3_device.uart_rx_len-2]&&(uint8_t)uart3_data16_crc==uart3_device.uart_rx_buffer[uart3_device.uart_rx_len-1])
			{
				for(int t=0;t<char_len;t++)
				{
					write_modbus_buffer[reg_addr*2+t]=uart3_device.uart_rx_buffer[t+7];
				}
				result=bl24cxx_write(bl24512_device,0x8000+(reg_addr*2),&write_modbus_buffer[reg_addr*2],char_len);
				if(result!=RT_EOK)
				{
					rs485_send((uint8_t *)"write error!\n",sizeof("write error!\n"));
				}
				else
				{
					
					write_modbus_return_data[0]=slave_addr;
					write_modbus_return_data[1]=0x10;
					reg_addr=reg_addr-reg_len;
					write_modbus_return_data[2]=reg_addr>>8;
					write_modbus_return_data[3]=reg_addr;
					write_modbus_return_data[4]=reg_len>>8;
					write_modbus_return_data[5]=reg_len;
					for(int t=0;t<6;t++)
					{
						uart3_return_crc[t]=write_modbus_return_data[t];
					}
					uart3_data16_crc=ModbusCRC(uart3_return_crc,6);
					write_modbus_return_data[6]=uart3_data16_crc>>8;
					write_modbus_return_data[7]=uart3_data16_crc;
					
					rs485_send(write_modbus_return_data,8);
					memset(uart3_device.uart_rx_buffer,'\0',sizeof(uart3_device.uart_rx_buffer));
				}
				

			}
			else
			{
				rt_thread_delay(10);
				rs485_send((uint8_t *)"crc error!\n",sizeof("crc error!\n"));
				memset(uart3_device.uart_rx_buffer,'\0',sizeof(uart3_device.uart_rx_buffer));
			}
		}
//		uart3_device.uart_flag=0;
	}
}

//65������
void modbus_65_function()
{
	
	if(uart3_device.uart_flag==1)
	{
		
		
		if(uart3_device.uart_rx_buffer[0]==slave_addr&&uart3_device.uart_rx_buffer[1]==0x65)
		{
			
			uint8_t reg_addr=0;
			uint8_t uart3_read_crc[255]={0x00},uart3_return_crc[255]={0x00};
			uint8_t write_modbus_return_data[255]={0x00};
			uint16_t uart3_data16_crc=0;
			reg_addr=uart3_device.uart_rx_buffer[2];
			for(int t=0;t<3;t++)
			{
				uart3_read_crc[t]=uart3_device.uart_rx_buffer[t];
			}
			uart3_data16_crc=ModbusCRC(uart3_read_crc,3);
			if(uart3_data16_crc>>8==uart3_device.uart_rx_buffer[3]&&(uint8_t)uart3_data16_crc==uart3_device.uart_rx_buffer[4])
			{

				
				
				rs485_send(uart3_device.uart_rx_buffer,5);
//				if(reg_addr==0xBB)
//				{
//					rt_hw_cpu_reset();
//				}
				memset(uart3_device.uart_rx_buffer,'\0',sizeof(uart3_device.uart_rx_buffer));
			}
		}
	}
}
