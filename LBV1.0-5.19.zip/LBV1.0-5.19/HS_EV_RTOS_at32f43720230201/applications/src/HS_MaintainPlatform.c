#include <rtthread.h>
#include <rtdevice.h>
#include "stdlib.h"
#include "HS_#define.h"  
#include "HS_main.h"
#include "HS_MaintainPlatform.h"
#include "mqttclient.h"
#include "cJSON.h"
#include "HS_arithmetic.h"
#include "HS_uart.h"
#include "HS_struct.h"


mqtt_client_t *client = NULL;

uint8_t AT_RDY[]="RDY";

const at_cmd_struct at_4g_cmd[]=													//atָ�
{
	
	//������������
	{
		.index=AT_4G,
		.executecmd="AT\r\n",
		.data_len=6,
		.returnparameters="OK",
		.cmdannotation="�������",
		
	},
	{
		.index=AT_4G_GSN,
		.executecmd="ATE0\r\n",
		.data_len=6,
		.returnparameters="OK",
		.cmdannotation="��ȡ���к�",
	},
	{
		.index=AT_4G_CIMI,
		.executecmd="AT+CPIN?\r\n",
		.data_len=10,
		.returnparameters="+CPIN: READY",
		.cmdannotation="��ȡsim����Ϣ"
	},
	{
		.index=AT_4G_CREG,
		.executecmd="AT+CIMI?\r\n",
		.data_len=10,
		.returnparameters="+CIMI",//"+CREG: 0,1",
		.cmdannotation="CS������ע��״̬",
	},
	{
		.index=AT_4G_CGREG,
		.executecmd="AT+CGDCONT=1,\"IP\",\"cmnet\"\r\n",
		.data_len=27,
		.returnparameters="OK",//"+CGREG: 0,1",
		.cmdannotation="��·ע��״̬",
	},
	{
		.index=AT_4G_CEREG,
		.executecmd="AT+CGREG?\r\n",
		.data_len=11,
		.returnparameters="+CGREG: 0,1",//"+CEREG: 0,1",
		.cmdannotation="EPS��·ע��״̬",
	},
	{
		.index=AT_4G_QICSGP,
		.executecmd="AT+GTSET=\"IPRFMT\",1\r\n",
		.data_len=21,
		.returnparameters="OK",
		.cmdannotation="����TCP/IP��������",
	},
	{
		.index=AT_4G_QIACT,
		.executecmd="AT+MIPCALL=1\r\n",
		.data_len=14,
		.returnparameters="+MIPCALL",
		.cmdannotation="����PDP����",
	},
	{
		.index=AT_4G_QIACTIP,
		.executecmd="AT+MIPODM=1,,\"114.55.7.88\",8776,0\r\n",
		.data_len=40,
		.returnparameters="+MIPOPEN: 1,1",
		.cmdannotation="��ѯIP",
	},
	{
		.index=AT_4G_QIOPEN,
		.executecmd="AT+QIOPEN=1,0,\"TCP\",\"115.236.153.177\",50760,0,1\r\n",		
		.data_len=47,
		.returnparameters="+QIOPEN: 0,0",
		.cmdannotation="����TCP������",
	},
	{
		.index=AT_4G_QISEND,
		.executecmd="AT+MIPSEND=1",		
		.data_len=47,
		.returnparameters="+MIPPUSH: 1,0",
		.cmdannotation="TCP���ݷ���",
	},
	
	
	//MQTTָ��
	
	{
		.index=AT_4G_QMTCFG,
		.executecmd="AT+MQTTUSER=2,\"g510/test1\",\"LeKH43ojsvwzlNS15EGImf5JIuPkCv9cPnu1DQUxGOk=\r\n\"",		
		.data_len=28,
		.returnparameters="OK",
		.cmdannotation="���ý���ģʽ",
	},
	
	{
		.index=AT_4G_QMTOPEN,
		.executecmd="AT+QMTOPEN=2,",		
		.data_len=28,
		.returnparameters="OK",
		.cmdannotation="�򿪿ͻ���",
	},
	
	{
		.index=AT_4G_QMTCONN,
		.executecmd="AT+QMTCONN=2,",		
		.data_len=16,
		.returnparameters="+MQTTOPEN: 2,1",
		.cmdannotation="�ͻ�������",
	},
	
	{
		.index=AT_4G_QMTPUB,
		.executecmd="AT+MQTTPUB=2,",		
		.data_len=13,
		.returnparameters="+MQTTPUB",
		.cmdannotation="������Ϣ",
	},
	
};


uint8_t mqtt_connect_accomplish=0;											//mqtt�������
uint16_t at_mqtt_delay=800;
data_delay_paramerter mqtt_delay_par;

uint8_t tcp_interlocking=0,mqtt_interlocking=0;

void sub_topic_handle1(void* client, message_data_t* msg)
{
    (void) client;
    KAWAII_MQTT_LOG_I("-----------------------------------------------------------------------------------");
    KAWAII_MQTT_LOG_I("%s:%d %s()...\ntopic: %s\nmessage:%s", __FILE__, __LINE__, __FUNCTION__, msg->topic_name, (char*)msg->message->payload);
    KAWAII_MQTT_LOG_I("-----------------------------------------------------------------------------------");
}


int mqtt_publish_handle1(mqtt_client_t *client,char *str_data)
{
    mqtt_message_t msg;
    memset(&msg, 0, sizeof(msg));

    msg.qos = QOS0;
    msg.payload = (void *)str_data;

    return mqtt_publish(client, (char *)mqtt_pubtopic, &msg);
}


char* mqtt_json_devicedata(uint8_t *device_data)
{
	cJSON *root;
	uint8_t finish_zbm_str[14]={0x00},finish_zbm_strdata[14]={0x00};
	
	uint8_t finish_code_versions[14]={0x00},finish_code_versions_str[14]={0x00};
	uint8_t manufacturers_str[2]={0x00},manufacturers_strdata[2]={0x00};
	uint8_t device_id_str[18]={0x00},device_id_strdata[18]={0x00};
	uint8_t platform_str[4]={0x00},platform_strdata[4]={0x00};
	static char *str=NULL;
	
	read_modbus_buffer[135]=cloud_jcsj.zzt;
	read_modbus_buffer[137]=recharge_state;
	read_modbus_buffer[139]=cloud_jcsj.sfcq;
	read_modbus_buffer[141]=cloud_jyjl.jybs;
	read_modbus_buffer[143]=cloud_jyjl.tzyy;
	cJSON *cupload;
	/* ����һ��JSON���ݶ���(����ͷ���) */
	cupload = cJSON_CreateObject();
	
	
	strncpy((char *)finish_zbm_str,(char *)&device_data[36],14);
	sprintf((char *)finish_zbm_strdata,"%s",finish_zbm_str);
	cJSON *encoding = cJSON_CreateString((char *)finish_zbm_strdata);
	
	strncpy((char *)finish_code_versions,(char *)&device_data[92],14);
	sprintf((char *)finish_code_versions_str,"%s",finish_code_versions);
	cJSON *versions = cJSON_CreateString((char *)finish_code_versions_str);
	
	cJSON *gun_mark = cJSON_CreateString("01");
	cJSON *recharge_duration = cJSON_CreateNumber(((uint32_t)device_data[130]<<24)+((uint32_t)device_data[131]<<16)+((uint32_t)device_data[132]<<8)+((uint32_t)device_data[133]));
	cJSON *tem = cJSON_CreateNumber(((uint16_t)device_data[0]<<8)+(uint16_t)device_data[1]);
	cJSON *grounding = cJSON_CreateNumber(((uint16_t)device_data[2]<<8)+(uint16_t)device_data[3]);
	
	strncpy((char *)platform_str,(char *)&device_data[200],4);
	sprintf((char *)platform_strdata,"%s",platform_str);
	cJSON *operation = cJSON_CreateString((char *)platform_strdata);
	
	strncpy((char *)manufacturers_str,(char *)&device_data[196],2);
	sprintf((char *)manufacturers_strdata,"%s",manufacturers_str);
	cJSON *manufacturers = cJSON_CreateString((char *)manufacturers_strdata);
	
	cJSON *cp = cJSON_CreateNumber(((uint16_t)device_data[4]<<8)+(uint16_t)device_data[5]);
	cJSON *electricity = cJSON_CreateNumber(((uint16_t)device_data[12]<<8)+(uint16_t)device_data[13]);
	cJSON *voltage = cJSON_CreateNumber(((uint16_t)device_data[8]<<8)+(uint16_t)device_data[9]);
	cJSON *electric_leakage = cJSON_CreateNumber(((uint16_t)device_data[16]<<8)+(uint16_t)device_data[17]);
//	cJSON *power = cJSON_CreateNumber(((uint16_t)device_data[20]<<8)+(uint16_t)device_data[21]);
//	cJSON *electric_energy = cJSON_CreateNumber(((uint16_t)device_data[24]<<8)+(uint16_t)device_data[25]);
	cJSON *pile_state = cJSON_CreateNumber(device_data[135]);
	cJSON *recharge_state = cJSON_CreateNumber(device_data[137]);
	cJSON *gun_state = cJSON_CreateNumber(device_data[139]);
	cJSON *starting_mode = cJSON_CreateNumber(device_data[141]);
	cJSON *finish_mode = cJSON_CreateNumber(device_data[143]);
	cJSON *malfunction = cJSON_CreateNumber(((uint16_t)device_data[144]<<8)+(uint16_t)device_data[145]);
	/* ����һ��JSON���ݶ���(�������) //����JSON���󣬣�����������*/
	cJSON *cparams = cJSON_CreateObject();
	/* ���� "date": cdate��ֵ�ԣ����뵽 cparams������*/
	cJSON_AddItemToObject(cparams, "encoding", encoding);
	cJSON_AddItemToObject(cparams, "versions", versions);
	cJSON_AddItemToObject(cparams, "operation", operation);
	cJSON_AddItemToObject(cparams, "manufacturers", manufacturers);
	cJSON_AddItemToObject(cparams, "gun_mark", gun_mark);
	cJSON_AddItemToObject(cparams, "recharge_duration", recharge_duration);
	cJSON_AddItemToObject(cparams, "tem", tem);
	cJSON_AddItemToObject(cparams, "grounding", grounding);
	cJSON_AddItemToObject(cparams, "cp", cp);
	cJSON_AddItemToObject(cparams, "electricity", electricity);
	cJSON_AddItemToObject(cparams, "voltage", voltage);
	cJSON_AddItemToObject(cparams, "electric_leakage", electric_leakage);
//	cJSON_AddItemToObject(cparams, "power", power);
//	cJSON_AddItemToObject(cparams, "electric_energy", electric_energy);
	cJSON_AddItemToObject(cparams, "pile_state", pile_state);
	cJSON_AddItemToObject(cparams, "recharge_state", recharge_state);
	cJSON_AddItemToObject(cparams, "gun_state", gun_state);
	cJSON_AddItemToObject(cparams, "starting_mode", starting_mode);
	cJSON_AddItemToObject(cparams, "finish_mode", finish_mode);
	cJSON_AddItemToObject(cparams, "malfunction", malfunction);
	/* �����ַ����������� */
	strncpy((char *)device_id_str,(char *)&device_data[106],18);
//	sprintf((char *)device_id_strdata,"%s",device_id_str);
	cJSON *cclientToken = cJSON_CreateString((char *)device_id_str);
	
	/* ���뵽JSON���ݶ���cupload */
	cJSON_AddItemToObject(cupload, "id", cclientToken);
	cJSON_AddItemToObject(cupload, "devicedata", cparams);
	/* ת��Ϊ��׼JSON���ݸ�ʽ */
	str=cJSON_Print(cupload);
	if(cloud_enthernet_4g_connect==1)
	{
		tcp_interlocking=1;
		
		
		uint8_t mqtt_data[100]={0x00};
		uint8_t json_buffer[500]={0x00};
		uint8_t json_len_str[10]={0x00};
		uint16_t json_len=0;
		rt_strncpy((char *)json_buffer,str,500);
		json_len=rt_strlen((char *)json_buffer);
		rt_sprintf((char *)mqtt_data,"%s\"%s\",0,0,%d\r\n",at_4g_cmd[AT_4G_QMTPUB].executecmd,mqtt_pubtopic,json_len);
		rt_thread_delay(50);	
		uart_tx_string(USART1,mqtt_data,rt_strlen((char *)mqtt_data));	
		rt_thread_delay(50);																		//�ӳٺ���
		uart_tx_string(USART1,json_buffer,json_len);

		tcp_interlocking=0;
	}
	
	else if(cloud_enthernet_4g_connect==2)
	{
		mqtt_publish_handle1(client,str);
	}
	
	/* �ͷ�str�ڴ� */
	cJSON_free(str);
	/* ɾ��json�����ͷ��ڴ� */
	cJSON_Delete(cupload);
	return str;
}



char* mqtt_json_finaldata(uint8_t *finaldata_data,uint8_t *zbm,uint8_t *manufacturers_data,uint8_t *device_id_data,uint8_t *platform)
{
	cJSON *root;
	uint8_t finish_zbm_str[14]={0x00},finish_zbm_strdata[14]={0x00};
	uint8_t start_time_data[30]={0x00},finish_time_data[30]={0x00};
	uint8_t manufacturers_str[2]={0x00},manufacturers_strdata[2]={0x00};
	uint8_t device_id_str[18]={0x00},device_id_strdata[18]={0x00};
	uint8_t platform_str[4]={0x00},platform_strdata[4]={0x00};
	static char *str=NULL;
	/* ����һ��JSON���ݶ���(����ͷ���) */
	cJSON *cupload = cJSON_CreateObject();
	/* ����int�������� */
	strncpy((char *)finish_zbm_str,(char *)zbm,14);
	sprintf((char *)finish_zbm_strdata,"%s",finish_zbm_str);
	cJSON *encoding = cJSON_CreateString((char *)finish_zbm_strdata);
	cJSON *gun_mark = cJSON_CreateString("01");
	
	strncpy((char *)platform_str,(char *)&platform[0],4);
	sprintf((char *)platform_strdata,"%s",platform_str);
	cJSON *operation = cJSON_CreateString((char *)platform_strdata);
//	cJSON *operation = cJSON_CreateNumber(((uint16_t)finaldata_data[184]<<8)+(uint16_t)finaldata_data[185]);
	
	strncpy((char *)manufacturers_str,(char *)&manufacturers_data[0],2);
	sprintf((char *)manufacturers_strdata,"%s",manufacturers_str);
	cJSON *manufacturers = cJSON_CreateString((char *)manufacturers_strdata);
	
	cJSON *balance = cJSON_CreateNumber(((uint64_t)finaldata_data[408]<<24)+((uint64_t)finaldata_data[407]<<16)+((uint64_t)finaldata_data[406]<<8)+((uint64_t)finaldata_data[405]));
	sprintf((char *)start_time_data,"%d-%d-%d %d:%d:%d",finaldata_data[263]+2000,finaldata_data[262],finaldata_data[261],finaldata_data[260],finaldata_data[259],(((uint16_t)finaldata_data[258]<<8)+(uint16_t)finaldata_data[257])/1000);
	cJSON *start_time = cJSON_CreateString((char *)start_time_data);
	sprintf((char *)finish_time_data,"%d-%d-%d %d:%d:%d",finaldata_data[270]+2000,finaldata_data[269],finaldata_data[268],finaldata_data[267],finaldata_data[266],(((uint16_t)finaldata_data[265]<<8)+(uint16_t)finaldata_data[264])/1000);
	cJSON *end_time = cJSON_CreateString((char *)finish_time_data);
	cJSON *consumption = cJSON_CreateNumber(((uint64_t)finaldata_data[356]<<24)+((uint64_t)finaldata_data[355]<<16)+((uint64_t)finaldata_data[354]<<8)+((uint64_t)finaldata_data[355]));
	cJSON *begin_electricity = cJSON_CreateNumber(((uint64_t)finaldata_data[339]<<32)+((uint64_t)finaldata_data[338]<<24)+((uint64_t)finaldata_data[337]<<16)+((uint64_t)finaldata_data[336]<<8)+((uint64_t)finaldata_data[335]));
	cJSON *finish_electricity = cJSON_CreateNumber(((uint64_t)finaldata_data[344]<<32)+((uint64_t)finaldata_data[343]<<24)+((uint64_t)finaldata_data[342]<<16)+((uint64_t)finaldata_data[341]<<8)+((uint64_t)finaldata_data[340]));
	cJSON *electric_quantity = cJSON_CreateNumber(((uint64_t)finaldata_data[348]<<24)+((uint64_t)finaldata_data[347]<<16)+((uint64_t)finaldata_data[346]<<8)+((uint64_t)finaldata_data[345]));
	cJSON *deal_identification = cJSON_CreateNumber(finaldata_data[374]);
	cJSON *stop_reason = cJSON_CreateNumber(finaldata_data[382]);
	cJSON *bill_uploading = cJSON_CreateNumber(finaldata_data[404]);

	/* ����һ��JSON���ݶ���(�������) //����JSON���󣬣�����������*/
	cJSON *cparams = cJSON_CreateObject();
	/* ���� "date": cdate��ֵ�ԣ����뵽 cparams������*/
	cJSON_AddItemToObject(cparams, "encoding", encoding);
	cJSON_AddItemToObject(cparams, "gun_mark", gun_mark);
	cJSON_AddItemToObject(cparams, "operation", operation);
	cJSON_AddItemToObject(cparams, "manufacturers", manufacturers);
	cJSON_AddItemToObject(cparams, "balance", balance);
	cJSON_AddItemToObject(cparams, "start_time", start_time);
	cJSON_AddItemToObject(cparams, "end_time", end_time);
	cJSON_AddItemToObject(cparams, "consumption", consumption);
	cJSON_AddItemToObject(cparams, "begin_electricity", begin_electricity);
	cJSON_AddItemToObject(cparams, "finish_electricity", finish_electricity);
	cJSON_AddItemToObject(cparams, "electric_quantity", electric_quantity);
	cJSON_AddItemToObject(cparams, "deal_identification", deal_identification);
	cJSON_AddItemToObject(cparams, "stop_reason", stop_reason);
	cJSON_AddItemToObject(cparams, "bill_uploading", bill_uploading);
	/* �����ַ����������� */
	strncpy((char *)device_id_str,(char *)&device_id_data[0],18);
//	sprintf((char *)device_id_strdata,"%s",device_id_str);
	cJSON *cclientToken = cJSON_CreateString((char *)device_id_str);
	/* ���뵽JSON���ݶ���cupload */
	cJSON_AddItemToObject(cupload, "id", cclientToken);
	cJSON_AddItemToObject(cupload, "finaldata", cparams);
	
	/* ת��Ϊ��׼JSON���ݸ�ʽ */
	str=cJSON_Print(cupload);
	
	if(cloud_enthernet_4g_connect==1)
	{
		uint8_t mqtt_data[100];
		uint8_t json_buffer[500]={0x00};
		uint8_t json_len_str[10];
		uint16_t json_len=0;
		rt_strncpy((char *)json_buffer,str,500);
		json_len=rt_strlen((char *)json_buffer);
		rt_sprintf((char *)mqtt_data,"%s\"%s\",0,0,%d\r\n",at_4g_cmd[AT_4G_QMTPUB].executecmd,mqtt_pubtopic,json_len);
		uart_tx_string(USART1,mqtt_data,rt_strlen((char *)mqtt_data));	
		rt_thread_delay(50);																		//�ӳٺ���
		uart_tx_string(USART1,json_buffer,json_len);
	}
	else if(cloud_enthernet_4g_connect==2)
	{
		mqtt_publish_handle1(client,str);
	}
	
	
	
	/* �ͷ�str�ڴ� */
	cJSON_free(str);
	/* ɾ��json�����ͷ��ڴ� */
	cJSON_Delete(cupload);
	return str;
}




void mqtt_4g_pub_device()
{
	tcp_interlocking=1;
//	if(accomplish_sd_flag==1)
//	{
		read_modbus_buffer[135]=cloud_jcsj.zzt;
		read_modbus_buffer[137]=recharge_state;
		read_modbus_buffer[139]=cloud_jcsj.sfcq;
		read_modbus_buffer[141]=cloud_jyjl.jybs;
		read_modbus_buffer[143]=cloud_jyjl.tzyy;
		
		uint8_t mqtt_data[100];
		uint8_t json_buffer[500]={0x00};
		uint8_t json_len_str[10];
		uint16_t json_len=0;
		rt_strncpy((char *)json_buffer,mqtt_json_devicedata(read_modbus_buffer),500);
		json_len=rt_strlen((char *)json_buffer);
		rt_sprintf((char *)mqtt_data,"%s\"%s\",%d\r\n",at_4g_cmd[AT_4G_QMTPUB].executecmd,mqtt_pubtopic,json_len);
		rt_thread_delay(50);	
		uart_tx_string(USART1,mqtt_data,rt_strlen((char *)mqtt_data));	
		rt_thread_delay(50);																		//�ӳٺ���
		uart_tx_string(USART1,json_buffer,json_len);
//	}
		tcp_interlocking=0;
	
}


void mqtt_4g_pub_finaldata()
{

	uint8_t mqtt_data[100];
	uint8_t json_buffer[500]={0x00};
	uint8_t json_len_str[10];
	uint16_t json_len=0;
	rt_strncpy((char *)json_buffer,mqtt_json_finaldata(tx_buffer,qr_code,manufacturer_name,device_id,platform_select),500);
	json_len=rt_strlen((char *)json_buffer);
	rt_sprintf((char *)mqtt_data,"%s\"%s\",%d\r\n",at_4g_cmd[AT_4G_QMTPUB].executecmd,mqtt_pubtopic,json_len);
	uart_tx_string(USART1,mqtt_data,rt_strlen((char *)mqtt_data));	
	rt_thread_delay(50);																		//�ӳٺ���
	uart_tx_string(USART1,json_buffer,json_len);
}


uint8_t yy_4g_flag1=1,yy_4g_flag2=0,yy_4g_flag3=0;
static uint16_t yy_delay_count=1000;
data_delay_paramerter wl_delay_par;



void yy_4g_connect()
{
	if(yy_4g_flag1==1)
	{
		xt_overtime_count=0;
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G].executecmd,at_4g_cmd[AT_4G].data_len);												
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G].executecmd,at_4g_cmd[AT_4G].data_len);									
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=1;
		yy_4g_flag3=1;
//		wl_delay_par.delay_count=0;
		wl_delay_par.delay_switch=1;
		jcsj_count=240;
	}
	else if(yy_4g_flag1==2)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_GSN].executecmd,at_4g_cmd[AT_4G_GSN].data_len);			
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_GSN].executecmd,at_4g_cmd[AT_4G_GSN].data_len);								
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=2;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==3)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_CIMI].executecmd,at_4g_cmd[AT_4G_CIMI].data_len);											
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_CIMI].executecmd,at_4g_cmd[AT_4G_CIMI].data_len);																
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=3;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==4)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_CREG].executecmd,at_4g_cmd[AT_4G_CREG].data_len);		
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_CREG].executecmd,at_4g_cmd[AT_4G_CREG].data_len);																
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=4;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==5)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_CGREG].executecmd,at_4g_cmd[AT_4G_CGREG].data_len);	
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_CGREG].executecmd,at_4g_cmd[AT_4G_CGREG].data_len);																			
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=5;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==6)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_CEREG].executecmd,at_4g_cmd[AT_4G_CEREG].data_len);	
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_CEREG].executecmd,at_4g_cmd[AT_4G_CEREG].data_len);																			
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=6;
		yy_4g_flag3=1;
	}

	else if(yy_4g_flag1==7)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_QICSGP].executecmd,at_4g_cmd[AT_4G_QICSGP].data_len);	
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_QICSGP].executecmd,at_4g_cmd[AT_4G_QICSGP].data_len);																												
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=7;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==8)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_QIACT].executecmd,at_4g_cmd[AT_4G_QIACT].data_len);													
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_QIACT].executecmd,at_4g_cmd[AT_4G_QIACT].data_len);																													
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=8;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==9)
	{
		uint8_t at_tx_data[100]={0x00};
		rt_sprintf((char *)at_tx_data,"AT+MIPOPEN=1,,\"%s\",%d,0\r\n",operator_ip,operator_port);
		uint8_t port_str[10]={0x00};
		rt_sprintf((char *)port_str,"%d",operator_port);
		uart_tx_string(USART1,at_tx_data,21+strlen((char *)port_str)+strlen((char *)operator_ip));														//����ATָ��
		uart_tx_string(USART2,at_tx_data,21+strlen((char *)port_str)+strlen((char *)operator_ip));														//����ATָ��																														
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=9;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==10)
	{
		uart_tx_string(USART1,(uint8_t *)at_4g_cmd[AT_4G_QMTCFG].executecmd,at_4g_cmd[AT_4G_QMTCFG].data_len);										
		uart_tx_string(USART2,(uint8_t *)at_4g_cmd[AT_4G_QMTCFG].executecmd,at_4g_cmd[AT_4G_QMTCFG].data_len);																											
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=10;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==11)
	{
		uint8_t mqtt_data[200]={0x00};
		rt_sprintf((char *)mqtt_data,"AT+MQTTUSER=2,\"%s\",\"%s\"\r\n",device_id,manufacturer_pass);
		uart_tx_string(USART1,mqtt_data,21+rt_strlen((char *)device_id)+rt_strlen((char *)manufacturer_pass));	
		uart_tx_string(USART2,mqtt_data,21+rt_strlen((char *)device_id)+rt_strlen((char *)manufacturer_pass));	
	
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=11;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==12)
	{
		uint8_t at_tx_data[50]={0x00};
		rt_sprintf((char *)at_tx_data,"AT+MQTTOPEN=2,\"%s\",%s,0,60\r\n",manufacturer_ip,manufacturer_port);
//		uint8_t port_str[10]={0x00};
//		rt_sprintf((char *)port_str,"%d",operator_port);
		uart_tx_string(USART1,at_tx_data,24+strlen((char *)manufacturer_ip)+strlen((char *)manufacturer_port));														//����ATָ��
		uart_tx_string(USART2,at_tx_data,24+strlen((char *)manufacturer_ip)+strlen((char *)manufacturer_port));														//����ATָ��																											
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=12;
		yy_4g_flag3=1;
	}
	else if(yy_4g_flag1==13)
	{
		uint8_t at_tx_data[40]={0x00};
		rt_sprintf((char *)at_tx_data,"AT+MIPOPEN=1,,\"%s\",%d,0\r\n",operator_ip,operator_port);
		uint8_t port_str[10]={0x00};
		rt_sprintf((char *)port_str,"%d",operator_port);
		uart_tx_string(USART1,at_tx_data,21+strlen((char *)port_str)+strlen((char *)operator_ip));														//����ATָ��
		uart_tx_string(USART2,at_tx_data,21+strlen((char *)port_str)+strlen((char *)operator_ip));														//����ATָ��																														
		rt_thread_delay(yy_delay_count);
		yy_4g_flag1=0;
		yy_4g_flag2=13;
		yy_4g_flag3=1;
	}
	
	if(yy_4g_flag3==1)
	{

		uint16_t uart1_len=0;
		uint8_t uart1_ringbuffer[255]={0x00};
		uart1_len=rt_ringbuffer_data_len(uart1_device.ringbuffer);
		rt_ringbuffer_get(uart1_device.ringbuffer,uart1_ringbuffer,255);
		switch(yy_4g_flag2)
		{
			case 0:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)AT_RDY)!=NULL)
				{
					yy_4g_flag1=1;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=0;
					yy_4g_flag3=1;					
				}
				break;
			case 1:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G].returnparameters)!=NULL)	
				{
					yy_4g_flag1=2;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=1;
					yy_4g_flag3=0;					
				}
				break;
			case 2:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_GSN].returnparameters)!=NULL)
				{
					yy_4g_flag1=3;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=2;
					yy_4g_flag3=0;					
				}
				break;
			case 3:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_CIMI].returnparameters)!=NULL)
				{
					yy_4g_flag1=4;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=3;
					yy_4g_flag3=0;					
				}
				break;
			case 4:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_CREG].returnparameters)!=NULL)
				{
					yy_4g_flag1=5;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=4;
					yy_4g_flag3=0;					
				}
				break;
			case 5:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_CGREG].returnparameters)!=NULL)
				{
					yy_4g_flag1=6;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=5;
					yy_4g_flag3=0;					
				}
				break;
			case 6:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_CEREG].returnparameters)!=NULL)
				{
					yy_4g_flag1=7;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=6;
					yy_4g_flag3=0;					
				}
				break;
			case 7:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QICSGP].returnparameters)!=NULL)
				{
					yy_4g_flag1=8;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=7;
					yy_4g_flag3=0;					
				}
				break;
			case 8:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QIACT].returnparameters)!=NULL)
				{
					yy_4g_flag1=11;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=8;
					yy_4g_flag3=0;					
				}
				break;
			case 9:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QIACTIP].returnparameters)!=NULL)	
				{
					yy_4g_flag1=11;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=9;
					yy_4g_flag3=0;					
				}
				break;
			case 10:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QMTCFG].returnparameters)!=NULL)	
				{
					yy_4g_flag1=11;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=10;
					yy_4g_flag3=0;					
				}
				break;
			case 11:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QMTOPEN].returnparameters)!=NULL)	
				{
					yy_4g_flag1=12;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=11;
					yy_4g_flag3=0;					
				}
				break;
			case 12:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QMTCONN].returnparameters)!=NULL)	
				{
					yy_4g_flag1=13;																				
					yy_4g_flag3=0;
				}
				else
				{
					yy_4g_flag1=12;
					yy_4g_flag3=0;					
				}
				break;
			case 13:	
				if(rt_strstr((char *)uart1_ringbuffer,(char *)at_4g_cmd[AT_4G_QIACTIP].returnparameters)!=NULL)	
				{
					yy_4g_flag1=14;																				
					yy_4g_flag3=0;
					accomplish_connect_flag=1;
					
				}
				else
				{
					yy_4g_flag1=13;
					yy_4g_flag3=0;					
				}
				break;
		}
	}
	if((wl_delay_par.delay_flag==1)&&(cloud_enthernet_4g_connect==1))															//4gģ����50s���Ƿ����ӳɹ������û�����ӳɹ�����������
	{
		wl_delay_par.delay_flag=0;
		if(accomplish_sd_flag!=1)														//�Ƿ����ӳɹ�
		{
			
			wl_delay_par.delay_count=0;															//�������ʱʱ��
			rt_pin_write(PIN_4G_RST, PIN_HIGH);								//4gģ�鸴λ���Ÿߵ�ƽ
			rt_thread_delay(500);															//��ʱ500ms
			rt_pin_write(PIN_4G_RST, PIN_LOW);								//4gģ�鸴λ���ŵ͵�ƽ
			yy_4g_flag1=1;
			yy_4g_flag2=0;
			yy_4g_flag3=0;
			yy_sd_flag1=1;																				//�ϵ����ӱ�־λ1��1
			yy_sd_flag2=0;																				//�ϵ����ӱ�־λ2����
			yy_sd_flag3=0;																				//�ϵ����ӱ�־λ3����
			accomplish_connect_flag=0;												//4gģ�����ӳɹ���־λ����
			accomplish_sd_flag=0;															//�ϵ����ӳɹ���־λ����
			xt_overtime_count=0;															//������ʱ����
		}
	}
	
}







////mqtt�߳�
//static void mqtt_thread(void *parameter)
//{
//	
////	rt_thread_delay(5000);
//	if(cloud_enthernet_4g_connect==1)
//	{
//		
//	}
//	else if(cloud_enthernet_4g_connect==2)
//	{
//		mqtt_log_init();

//		client = mqtt_lease();

//		mqtt_set_host(client, (char *)manufacturer_ip);
//		mqtt_set_port(client, (char *)manufacturer_port);
//		mqtt_set_user_name(client, (char *)device_id);
//		mqtt_set_password(client, (char *)manufacturer_pass);
//		mqtt_set_client_id(client, (char *)device_id);
//		mqtt_set_clean_session(client, 1);
//		KAWAII_MQTT_LOG_I("The ID of the Kawaii client is: %s ", device_id);
//		mqtt_connect(client);
//	}
//	
//	
//	while (1)
//	{
//		
////    mqtt_subscribe(client, KAWAII_MQTT_SUBTOPIC, QOS0, sub_topic_handle1);
//		if(cloud_enthernet_4g_connect==1)
//		{
//			yy_4g_connect();
//			if(mqtt_device_pub_flag==1)
//			{
//				if(mqtt_interlocking==0)
//				{
//					
////					tcp_interlocking=1;
////					rt_thread_delay(100);
////					mqtt_4g_pub_device();
//					mqtt_device_pub_flag=0;
////					tcp_interlocking=0;
//				}
//				
//			}
//		}
//		else if(cloud_enthernet_4g_connect==2)
//		{
////			mqtt_publish_handle1(client,mqtt_json_devicedata(read_modbus_buffer));
////			rt_thread_delay(20000);
//		}
//		
//		rt_thread_delay(10);
//		
//	}
//}



//int mqtt_init(void)
//{
//    rt_thread_t tid_mqtt;

//    tid_mqtt = rt_thread_create("mqtt_thread", mqtt_thread, RT_NULL, 2048, 3, 10);
//    if (tid_mqtt == RT_NULL) {
//        return -RT_ERROR;
//    }

//    rt_thread_startup(tid_mqtt);

//    return RT_EOK;
//}


