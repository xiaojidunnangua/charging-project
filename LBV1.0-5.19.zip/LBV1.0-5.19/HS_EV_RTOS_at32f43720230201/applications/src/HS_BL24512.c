/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2019-04-13     XiaojieFan   the first version
 * 2019-12-04     RenMing      ADD PAGE WRITE and input address can be selected
 * 2022-10-11     GuangweiRen  Delay 2ms after writing one byte
 */
#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>
#include "HS_main.h"
#include "HS_calculate.h"

#include <string.h>
#include <stdlib.h>

#define DBG_ENABLE
#define DBG_SECTION_NAME "at24xx"
#define DBG_LEVEL DBG_LOG
#define DBG_COLOR
#include <rtdbg.h>

#include "HS_BL24512.h"

#ifdef PKG_USING_BL24CXX
#define BL24CXX_ADDR (0xA0 >> 1)                      //A0 A1 A2 connect GND

#if (EE_TYPE == BL24C01)
    #define BL24CXX_PAGE_BYTE               8
    #define BL24CXX_MAX_MEM_ADDRESS         128
#elif (EE_TYPE == BL24C02)
    #define BL24CXX_PAGE_BYTE               8
    #define BL24CXX_MAX_MEM_ADDRESS         256
#elif (EE_TYPE == BL24C04)
    #define BL24CXX_PAGE_BYTE               16
    #define BL24CXX_MAX_MEM_ADDRESS         512
#elif (EE_TYPE == BL24C08)
    #define BL24CXX_PAGE_BYTE               16
    #define BL24CXX_MAX_MEM_ADDRESS         1024
#elif (EE_TYPE == BL24C16)
    #define BL24CXX_PAGE_BYTE               16
    #define BL24CXX_MAX_MEM_ADDRESS         2048
#elif (EE_TYPE == BL24C32)
    #define BL24CXX_PAGE_BYTE               32
    #define BL24CXX_MAX_MEM_ADDRESS         4096
#elif (EE_TYPE == BL24C64)
    #define BL24CXX_PAGE_BYTE               32
    #define BL24CXX_MAX_MEM_ADDRESS         8192
#elif (EE_TYPE == BL24C128)
    #define BL24CXX_PAGE_BYTE               64
    #define BL24CXX_MAX_MEM_ADDRESS         16384
#elif (EE_TYPE == BL24C256)
    #define BL24CXX_PAGE_BYTE               64
    #define BL24CXX_MAX_MEM_ADDRESS         32768
#elif (EE_TYPE == BL24C512)
    #define BL24CXX_PAGE_BYTE               128
    #define BL24CXX_MAX_MEM_ADDRESS         65536
#endif

struct bl24cxx_device *bl24512_device;			//bl24512���

void bl24512_init()
{
	rt_err_t result;
	uint8_t rx1_buffer[128];
	bl24512_device=bl24cxx_init("i2c3",0);
//	result=bl24cxx_write(bl24512_device,0x0000,cloud_public_para.zbh,7);
//	if(result!=RT_EOK)
//	{
//		rt_kprintf("�洢ʧ�ܣ�����\n");
//	}
//	rt_thread_delay(10);
//	result=bl24cxx_read(bl24512_device,0x0000,rx1_buffer,7);
//	if(result==RT_EOK)
//	{
//		int t=0;
////		for(int t=0;t<20;t++)
////		{
//			rt_kprintf("%x %x %x %x %x %x %x \n",rx1_buffer[t],rx1_buffer[t+1],rx1_buffer[t+2],rx1_buffer[t+3],rx1_buffer[t+4],rx1_buffer[t+5],rx1_buffer[t+6]);
////		}
//		
//	}
////	bl24cxx_page_read(bl24512_device);
}


static rt_err_t read_regs(bl24cxx_device_t dev, rt_uint8_t len, rt_uint8_t *buf)
{
    struct rt_i2c_msg msgs;

    msgs.addr = BL24CXX_ADDR | dev->AddrInput;
    msgs.flags = RT_I2C_RD;
    msgs.buf = buf;
    msgs.len = len;

    if (rt_i2c_transfer(dev->i2c, &msgs, 1) == 1)
    {
        return RT_EOK;
    }
    else
    {
        return -RT_ERROR;
    }
}

uint8_t bl24cxx_read_one_byte(bl24cxx_device_t dev, uint16_t readAddr)
{
    rt_uint8_t buf[2];
    rt_uint8_t temp;
#if (EE_TYPE > BL24C16)
    buf[0] = (uint8_t)(readAddr>>8);
    buf[1] = (uint8_t)readAddr;
    if (rt_i2c_master_send(dev->i2c, BL24CXX_ADDR, 0, buf, 2) == 0)
#else
    buf[0] = readAddr;
    if (rt_i2c_master_send(dev->i2c, AT24CXX_ADDR | dev->AddrInput, 0, buf, 1) == 0)
#endif
    {
        return RT_ERROR;
    }
    read_regs(dev, 1, &temp);
    return temp;
}

rt_err_t bl24cxx_write_one_byte(bl24cxx_device_t dev, uint16_t writeAddr, uint8_t dataToWrite)
{
    rt_uint8_t buf[3];
#if (EE_TYPE > BL24C16)
    buf[0] = (uint8_t)(writeAddr>>8);
    buf[1] = (uint8_t)writeAddr;
    buf[2] = dataToWrite;
    if (rt_i2c_master_send(dev->i2c, BL24CXX_ADDR, 0, buf, 3) == 3)
#else
    buf[0] = writeAddr; //cmd
    buf[1] = dataToWrite;
    //buf[2] = data[1];


    if (rt_i2c_master_send(dev->i2c, AT24CXX_ADDR | dev->AddrInput, 0, buf, 2) == 2)
#endif
        return RT_EOK;
    else
        return -RT_ERROR;

}

rt_err_t bl24cxx_read_page(bl24cxx_device_t dev, uint32_t readAddr, uint8_t *pBuffer, uint16_t numToRead)
{
    struct rt_i2c_msg msgs[2];
    uint8_t AddrBuf[2];

    msgs[0].addr = BL24CXX_ADDR | dev->AddrInput;
    msgs[0].flags = RT_I2C_WR ;

#if (EE_TYPE > BL24C16)
    AddrBuf[0] = readAddr >> 8;
    AddrBuf[1] = readAddr;
    msgs[0].buf = AddrBuf;
    msgs[0].len = 2;
#else
    AddrBuf[0] = readAddr;
    msgs[0].buf = AddrBuf;
    msgs[0].len = 1;
#endif

    msgs[1].addr = BL24CXX_ADDR | dev->AddrInput;
    msgs[1].flags = RT_I2C_RD;
    msgs[1].buf = pBuffer;
    msgs[1].len = numToRead;

    if(rt_i2c_transfer(dev->i2c, msgs, 2) == 0)
    {
        return RT_ERROR;
    }

    return RT_EOK;
}

rt_err_t bl24cxx_write_page(bl24cxx_device_t dev, uint32_t wirteAddr, uint8_t *pBuffer, uint16_t numToWrite)
{
    struct rt_i2c_msg msgs[2];
    uint8_t AddrBuf[2];

    msgs[0].addr = BL24CXX_ADDR | dev->AddrInput;
    msgs[0].flags = RT_I2C_WR ;

#if (EE_TYPE > BL24C16)
    AddrBuf[0] = wirteAddr >> 8;
    AddrBuf[1] = wirteAddr;
    msgs[0].buf = AddrBuf;
    msgs[0].len = 2;
#else
    AddrBuf[0] = wirteAddr;
    msgs[0].buf = AddrBuf;
    msgs[0].len = 1;
#endif

    msgs[1].addr = BL24CXX_ADDR | dev->AddrInput;
    msgs[1].flags = RT_I2C_WR | RT_I2C_NO_START;
    msgs[1].buf = pBuffer;
    msgs[1].len = numToWrite;

    if(rt_i2c_transfer(dev->i2c, msgs, 2) <= 0)
    {
        return RT_ERROR;
    }

    return RT_EOK;
}

rt_err_t bl24cxx_check(bl24cxx_device_t dev)
{
    uint8_t temp;
    RT_ASSERT(dev);

    temp = bl24cxx_read_one_byte(dev, BL24CXX_MAX_MEM_ADDRESS - 1);
    if (temp == 0x55) return RT_EOK;
    else
    {
        bl24cxx_write_one_byte(dev, BL24CXX_MAX_MEM_ADDRESS - 1, 0x55);
        rt_thread_mdelay(EE_TWR);                 // wait 5ms befor next operation
        temp = bl24cxx_read_one_byte(dev, BL24CXX_MAX_MEM_ADDRESS - 1);
        if (temp == 0x55) return RT_EOK;
    }
    return RT_ERROR;
}

/**
 * This function read the specific numbers of data to the specific position
 *
 * @param bus the name of bl24cxx device
 * @param ReadAddr the start position to read
 * @param pBuffer  the read data store position
 * @param NumToRead
 * @return RT_EOK  write ok.
 */
rt_err_t bl24cxx_read(bl24cxx_device_t dev, uint32_t ReadAddr, uint8_t *pBuffer, uint16_t NumToRead)
{
    rt_err_t result;
    RT_ASSERT(dev);

    if(ReadAddr + NumToRead > BL24CXX_MAX_MEM_ADDRESS)
    {
        return RT_ERROR;
    }

    result = rt_mutex_take(dev->lock, RT_WAITING_FOREVER);
    if (result == RT_EOK)
    {
        while (NumToRead)
        {
            *pBuffer++ = bl24cxx_read_one_byte(dev, ReadAddr++);
            NumToRead--;
        }
    }
    else
    {
        LOG_E("The bl24cxx could not respond  at this time. Please try again");
    }
    rt_mutex_release(dev->lock);

    return RT_EOK;
}

/**
 * This function read the specific numbers of data to the specific position
 *
 * @param bus the name of bl24cxx device
 * @param ReadAddr the start position to read
 * @param pBuffer  the read data store position
 * @param NumToRead
 * @return RT_EOK  write ok.
 */
rt_err_t bl24cxx_page_read(bl24cxx_device_t dev, uint32_t ReadAddr, uint8_t *pBuffer, uint16_t NumToRead)
{
    rt_err_t result = RT_EOK;
    uint16_t pageReadSize = BL24CXX_PAGE_BYTE - ReadAddr % BL24CXX_PAGE_BYTE;

    RT_ASSERT(dev);

    if(ReadAddr + NumToRead > BL24CXX_MAX_MEM_ADDRESS)
    {
        return RT_ERROR;
    }

    result = rt_mutex_take(dev->lock, RT_WAITING_FOREVER);
    if(result == RT_EOK)
    {
        while (NumToRead)
        {
            if(NumToRead > pageReadSize)
            {
                if(bl24cxx_read_page(dev, ReadAddr, pBuffer, pageReadSize))
                {
                    result = RT_ERROR;
                }

                ReadAddr += pageReadSize;
                pBuffer += pageReadSize;
                NumToRead -= pageReadSize;
                pageReadSize = BL24CXX_PAGE_BYTE;
            }
            else
            {
                if(bl24cxx_read_page(dev, ReadAddr, pBuffer, NumToRead))
                {
                    result = RT_ERROR;
                }
                NumToRead = 0;
            }
        }
    }
    else
    {
        LOG_E("The bl24cxx could not respond  at this time. Please try again");
    }

    rt_mutex_release(dev->lock);
    return result;
}

/**
 * This function write the specific numbers of data to the specific position
 *
 * @param bus the name of bl24cxx device
 * @param WriteAddr the start position to write
 * @param pBuffer  the data need to write
 * @param NumToWrite
 * @return RT_EOK  write ok.bl24cxx_device_t dev
 */
rt_err_t bl24cxx_write(bl24cxx_device_t dev, uint32_t WriteAddr, uint8_t *pBuffer, uint16_t NumToWrite)
{
    uint16_t i = 0;
    rt_err_t result;
    RT_ASSERT(dev);

    if(WriteAddr + NumToWrite > BL24CXX_MAX_MEM_ADDRESS)
    {
        return RT_ERROR;
    }

    result = rt_mutex_take(dev->lock, RT_WAITING_FOREVER);
    if (result == RT_EOK)
    {
        while (1) //NumToWrite--
        {
            if (bl24cxx_write_one_byte(dev, WriteAddr, pBuffer[i]) == RT_EOK)
            {
                rt_thread_mdelay(2);
                WriteAddr++;
            }
            if (++i == NumToWrite)
            {
                break;
            }
            rt_thread_mdelay(EE_TWR);
        }
    }
    else
    {
        LOG_E("The bl24cxx could not respond  at this time. Please try again");
    }
    rt_mutex_release(dev->lock);

    return RT_EOK;
}

/**
 * This function write the specific numbers of data to the specific position
 *
 * @param bus the name of bl24cxx device
 * @param WriteAddr the start position to write
 * @param pBuffer  the data need to write
 * @param NumToWrite
 * @return RT_EOK  write ok.bl24cxx_device_t dev
 */
rt_err_t bl24cxx_page_write(bl24cxx_device_t dev, uint32_t WriteAddr, uint8_t *pBuffer, uint16_t NumToWrite)
{
    rt_err_t result = RT_EOK;
    uint16_t pageWriteSize = BL24CXX_PAGE_BYTE - WriteAddr % BL24CXX_PAGE_BYTE;

    RT_ASSERT(dev);

    if(WriteAddr + NumToWrite > BL24CXX_MAX_MEM_ADDRESS)
    {
        return RT_ERROR;
    }

    result = rt_mutex_take(dev->lock, RT_WAITING_FOREVER);
    if(result == RT_EOK)
    {
        while (NumToWrite)
        {
            if(NumToWrite > pageWriteSize)
            {
                if(bl24cxx_write_page(dev, WriteAddr, pBuffer, pageWriteSize))
                {
                    result = RT_ERROR;
                }
                rt_thread_mdelay(EE_TWR);    // wait 5ms befor next operation

                WriteAddr += pageWriteSize;
                pBuffer += pageWriteSize;
                NumToWrite -= pageWriteSize;
                pageWriteSize = BL24CXX_PAGE_BYTE;
            }
            else
            {
                if(bl24cxx_write_page(dev, WriteAddr, pBuffer, NumToWrite))
                {
                    result = RT_ERROR;
                }
                rt_thread_mdelay(EE_TWR);   // wait 5ms befor next operation

                NumToWrite = 0;
            }
        }
    }
    else
    {
        LOG_E("The bl24cxx could not respond  at this time. Please try again");
    }

    rt_mutex_release(dev->lock);
    return result;
}

/**
 * This function initializes bl24cxx registered device driver
 *
 * @param dev the name of bl24cxx device
 *
 * @return the bl24cxx device.
 */
bl24cxx_device_t bl24cxx_init(const char *i2c_bus_name, uint8_t AddrInput)
{
    bl24cxx_device_t dev;

    RT_ASSERT(i2c_bus_name);

    dev = rt_calloc(1, sizeof(struct bl24cxx_device));
    if (dev == RT_NULL)
    {
        LOG_E("Can't allocate memory for bl24cxx device on '%s' ", i2c_bus_name);
        return RT_NULL;
    }

    dev->i2c = rt_i2c_bus_device_find(i2c_bus_name);
    if (dev->i2c == RT_NULL)
    {
        LOG_E("Can't find bl24cxx device on '%s' ", i2c_bus_name);
        rt_free(dev);
        return RT_NULL;
    }

    dev->lock = rt_mutex_create("mutex_bl24cxx", RT_IPC_FLAG_FIFO);
    if (dev->lock == RT_NULL)
    {
        LOG_E("Can't create mutex for bl24cxx device on '%s' ", i2c_bus_name);
        rt_free(dev);
        return RT_NULL;
    }

    dev->AddrInput = AddrInput;
    return dev;
}


#endif