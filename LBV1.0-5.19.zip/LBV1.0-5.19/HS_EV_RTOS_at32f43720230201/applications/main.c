/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-05-16     shelton      first version
 */

#include <rtthread.h>
#include <rtdevice.h>
#include "string.h"
#include "math.h"
#include "HS_CP56Time2a.h"

#include <sys/socket.h> /* ʹ��BSD socket����Ҫ����socket.hͷ�ļ� */
#include "netdev.h"
#include "HS_#define.h"  
#include "HS_main.h"
#include "HS_uart.h"
#include "HS_gpio.h"
#include "HS_FIBOCOM_4Gcat1.h"
#include "HS_timer.h"
#include "HS_IP101GR.h"
#include "HS_rtc.h"
#include "HS_RC522.h"
#include "HS_BL24512.h"
#include "HS_BL0939.h"
#include "HS_calculate.h"
#include "HS_adc.h"
#include "HS_pwm.h"
#include "HS_gather.h"
#include "HS_interrupt.h"
#include "HS_Dds3366d.h"
#include "HS_ESP32_C3_BLE.h"
#include "fal.h"
#include "drv_flash.h"
#include "HS_ws2815.h"
#include "HS_rgb_con.h"
#include "HS_modbus.h"
#include "usb_host.h"
#include "HS_MaintainPlatform.h"
#include "drv_emac.h"
#include "HS_crc.h"

//��̬�߳�1
 rt_thread_t T1_thread = RT_NULL;
rt_thread_t T2_thread = RT_NULL;
rt_thread_t T3_thread = RT_NULL;
rt_thread_t T4_thread = RT_NULL;
rt_thread_t T5_thread = RT_NULL;
rt_thread_t T6_thread = RT_NULL;
rt_thread_t T7_thread = RT_NULL;
rt_thread_t T8_thread = RT_NULL;
rt_thread_t T9_thread = RT_NULL;
 
//32 01 06 00 06 98 35 00 
//3201060000014701
 //0x32,0x01,0x06,0x00,0x06,0x98,0x35
//	

uint8_t at_qicsgp_operator[]="CMNET"; //CMNET��UNINET��CTNET���й��ƶ����й���ͨ���й����ţ�
Cloud_Public_Para cloud_public_para={.zbh={0x32,0x01,0x06,0x00,0x00,0x03,0x38},.qh=0x01};

uint8_t qr_code[16];//={0x33,0x32,0x30,0x31,0x30,0x36,0x30,0x30,0x30,0x36,0x39,0x38,0x33,0x35,0x30,0x31};	//��ά��
uint8_t operator_ip[15]="114.55.7.88";		//��Ӫ��ip//"121.43.69.62"
uint16_t operator_port=8776;  //��Ӫ�̶˿�//8767
uint8_t manufacturer_ip[15]="113.141.176.32";	//����ip
uint8_t manufacturer_port[4]="8092";	//���̶˿�
uint8_t manufacturer_user[5]="test8";		//�û���
uint8_t manufacturer_pass[]="dab09c48a2e9c4154494e2f86db31992";		//����
uint8_t mqtt_pubtopic[]="/sys/jd_exchange_device/jd_7kw_device/thing/event/property/post";	//����toppic
uint8_t mqtt_subscrip[64]={0x00};
uint8_t manufacturer_id[]="rtthread001";		//id
uint8_t program_version[14]="HS_7KW_V01.2.5";  //����汾
uint8_t device_id[]="HXADCB12DJ07240403";		//�豸id
uint8_t manufacturer_name[2]={0};		//��������
uint8_t bluetooth_switch=0;				//��������
uint8_t polarity_switch=0;				//���Կ���
uint8_t adhesion_switch=0;				//ճ������
uint8_t cloud_enthernet_4g_connect=3;   //1:4g 2:���� 3:����
uint8_t electrtc_energy_select=2;   //1:��� 2:����оƬ
uint8_t electric_leakage_select=1;	//1:A�ͣ�2:B��
uint8_t operator_select=0;				//1:�й��ƶ� 2:�й���ͨ 3:�й�����
uint8_t screen_selsect=0;					//��Ļѡ��
uint8_t light_selsect=0;					//����ѡ��
uint16_t mqtt_interval_time=3;			//mqtt���ͼ��ʱ��
uint8_t platform_select[]="YKC";		//ƽ̨ѡ��


//��ʼ��״̬����
void init_inspection()
{
	
	uint8_t read_data[400]={0x00};
	struct bl24cxx_device *bl24512_init_read_Device;			//bl24512���
	rt_err_t result;
	uint16_t leakage_select=0,network_select=0,energy_select=0;
	uint16_t manufacturer_port_16=0;
	result=bl24cxx_read(bl24512_device,0x8000,read_data,400);
	if(result!=RT_EOK)
	{
		rt_kprintf("read error!\n");
	}
	//׮����
	for(int t=0;t<7;t++)
	{
		cloud_public_para.zbh[t]=read_data[t];
	}
	
	//��ά��
	for(int t=0;t<16;t++)
	{
		qr_code[t]=read_data[t+8];
	}
	//��Ӫ��IP
	for(int t=0;t<16;t++)
	{
		operator_ip[t]=read_data[t+24];
	}
	//��Ӫ�̶˿�
	operator_port=((uint16_t)read_data[42]<<8)+((uint16_t)read_data[43]);
	//����IP
	for(int t=0;t<16;t++)
	{
		manufacturer_ip[t]=read_data[t+44];
	}
	//���̶˿�
	manufacturer_port_16=((uint16_t)read_data[62]<<8)+((uint16_t)read_data[63]);
	rt_sprintf((char *)manufacturer_port,"%d",manufacturer_port_16);
	//����汾
	for(int t=0;t<14;t++)
	{
		program_version[t]=read_data[t+64];
	}
	//�豸ID
	for(int t=0;t<18;t++)
	{
		device_id[t]=read_data[t+78];
	}
	//MQTT����
	for(int t=0;t<32;t++)
	{
		manufacturer_pass[t]=read_data[t+96];
	}
	//����toppic
	for(int t=0;t<64;t++)
	{
		mqtt_pubtopic[t]=read_data[t+132];
	}
	//����toppic
	for(int t=0;t<64;t++)
	{
		mqtt_subscrip[t]=read_data[t+196];
	}
	//ճ�����
//	adhesion_switch=((uint16_t)read_data[320]<<8)+((uint16_t)read_data[321]);
	//���Լ��
//	polarity_switch=((uint16_t)read_data[318]<<8)+((uint16_t)read_data[319]);
	//������ֵ
	data_scpoe[OVERCURRENT].data_scope_par.data_scope_max=((uint16_t)read_data[280]<<8)+((uint16_t)read_data[281]);
	//��ѹ��ѹ���ֵ
	data_scpoe[OVERVOLTAGE].data_scope_par.data_scope_max=((uint16_t)read_data[282]<<8)+((uint16_t)read_data[283]);
	//��ѹ��ѹ��Сֵ
	data_scpoe[OVERVOLTAGE].data_scope_par.data_scope_min=((uint16_t)read_data[284]<<8)+((uint16_t)read_data[285]);
	//Ƿѹ��ѹ���ֵ
	data_scpoe[UNDERVOLTAGE].data_scope_par.data_scope_max=((uint16_t)read_data[286]<<8)+((uint16_t)read_data[287]);
	//Ƿѹ��ѹ��Сֵ
	data_scpoe[UNDERVOLTAGE].data_scope_par.data_scope_min=((uint16_t)read_data[288]<<8)+((uint16_t)read_data[289]);
	//©����ֵ
	data_scpoe[LEAKAGE].data_scope_par.data_scope_max=((uint16_t)read_data[290]<<8)+((uint16_t)read_data[291]);
	//�ӵ����ֵ
	data_scpoe[GROUNDING].data_scope_par.data_scope_max=((uint16_t)read_data[292]<<8)+((uint16_t)read_data[293]);
	//�ӵ���Сֵ
	data_scpoe[GROUNDING].data_scope_par.data_scope_min=((uint16_t)read_data[294]<<8)+((uint16_t)read_data[295]);
	//�������ֵ
	data_scpoe[TRANSPOSITION].data_scope_par.data_scope_max=((uint16_t)read_data[296]<<8)+((uint16_t)read_data[297]);
	//������Сֵ
	data_scpoe[TRANSPOSITION].data_scope_par.data_scope_min=((uint16_t)read_data[298]<<8)+((uint16_t)read_data[299]);
	//�¶����ֵ
	data_scpoe[TEMPERATURE].data_scope_par.data_scope_max=((uint16_t)read_data[300]<<8)+((uint16_t)read_data[301]);
	//�¶���Сֵ
	data_scpoe[TEMPERATURE].data_scope_par.data_scope_min=((uint16_t)read_data[302]<<8)+((uint16_t)read_data[303]);
	//CP12���ֵ
	data_scpoe[CP12].data_scope_par.data_scope_max=((uint16_t)read_data[304]<<8)+((uint16_t)read_data[305]);
	//CP12��Сֵ
	data_scpoe[CP12].data_scope_par.data_scope_min=((uint16_t)read_data[306]<<8)+((uint16_t)read_data[307]);
	//CP9���ֵ
	data_scpoe[CP9].data_scope_par.data_scope_max=((uint16_t)read_data[308]<<8)+((uint16_t)read_data[309]);
	//CP9��Сֵ
	data_scpoe[CP9].data_scope_par.data_scope_min=((uint16_t)read_data[310]<<8)+((uint16_t)read_data[311]);
	//CP6���ֵ
	data_scpoe[CP6].data_scope_par.data_scope_max=((uint16_t)read_data[312]<<8)+((uint16_t)read_data[313]);
	//CP6��Сֵ
	data_scpoe[CP6].data_scope_par.data_scope_min=((uint16_t)read_data[314]<<8)+((uint16_t)read_data[315]);
	//�����豸����
	bluetooth_switch=((uint16_t)read_data[316]<<8)+((uint16_t)read_data[317]);
	//���Լ�⿪��
	polarity_switch=((uint16_t)read_data[318]<<8)+((uint16_t)read_data[319]);
	//ճ����⿪��
	adhesion_switch=((uint16_t)read_data[320]<<8)+((uint16_t)read_data[321]);
	//��Ӫ��ѡ��
	operator_select=((uint16_t)read_data[322]<<8)+((uint16_t)read_data[323]);
	if(operator_select==0x01)
	{
		rt_memcpy((char *)at_qicsgp_operator,"CMNET",5);
	}
	else if(operator_select==0x02)
	{
		rt_memcpy((char *)at_qicsgp_operator,"UNINET",6);
	}
	else
	{
		rt_memcpy((char *)at_qicsgp_operator,"CTNET",5);
	}
	//��Ļѡ��
	screen_selsect=((uint16_t)read_data[324]<<8)+((uint16_t)read_data[325]);
	//©��ѡ��
	leakage_select=((uint16_t)read_data[326]<<8)+((uint16_t)read_data[327]);
	if(leakage_select==0x0002)
	{
		electric_leakage_select=2;		//B��
	}
	else
	{
		electric_leakage_select=1;		//A��
	}
	//����ѡ��
	network_select=((uint16_t)read_data[328]<<8)+((uint16_t)read_data[329]);
	if(network_select==0x0001)
	{
		cloud_enthernet_4g_connect=1;			//4G
	}
	else if(network_select==0x0002)
	{
		cloud_enthernet_4g_connect=2;			//����
	}
	else
	{
		cloud_enthernet_4g_connect=3;			//����
	}
	
	//����ѡ��
	light_selsect=((uint16_t)read_data[330]<<8)+((uint16_t)read_data[331]);
	//���ѡ��
	energy_select=((uint16_t)read_data[332]<<8)+((uint16_t)read_data[333]);
	if(energy_select==0x0001)
	{
		electrtc_energy_select=1;			//���
	}
	else
	{
		electrtc_energy_select=2;			//����
	}
	//��������
	manufacturer_name[0]=read_data[334];
	manufacturer_name[1]=read_data[335];
	//mqtt���ͼ��ʱ��
	mqtt_interval_time=((uint16_t)read_data[336]<<8)+((uint16_t)read_data[337]);
	
	for(int t=0;t<4;t++)
	{
		platform_select[t]=read_data[t+338];
	}
	
	
	//�洢���ݸ�ֵ��03������Ĵ�����
	for(int t=0;t<18;t++)
	{
		read_modbus_buffer[106+t]=device_id[t];
	}
	
	for(int t=0;t<7;t++)
	{
		read_modbus_buffer[28+t]=cloud_public_para.zbh[t];
	}
	for(int t=0;t<16;t++)
	{
		read_modbus_buffer[36+t]=qr_code[t];
	}
	for(int t=0;t<16;t++)
	{
		read_modbus_buffer[92+t]=program_version[t];
	}
	read_modbus_buffer[196]=manufacturer_name[0];
	read_modbus_buffer[197]=manufacturer_name[1];
	
	//ƽ̨ѡ��
	for(int t=0;t<4;t++)
	{
		read_modbus_buffer[t+200]=platform_select[t];
	}
	
	
	
	
	
	
}


//��ƽ̨�����߳�
static void Thread1_entry(void *parameter)
{
//	rt_thread_delay(2000);
//	init_inspection();
	while (1)
	{
		
		f4g_connect_cloud();
		if(cloud_enthernet_4g_connect==1)
		{
			yy_4g_connect();
		}
//		rt_kprintf("1\n");
		rt_thread_delay(10);
	}
}


//�������߳�
static void Thread2_entry(void *parameter)
{
	
	while (1)
	{
		rt_thread_delay(10);
		
		
//		rt_kprintf("2\n");
	}
}
 

//����߼��ж��߳�
static void Thread3_entry(void *parameter)
{
	rt_thread_delay(8000);

	
	while (1)
	{

		
		Recharge_Combine();
//		rt_kprintf("3\n");
		
		rt_thread_delay(10);
	}
	
}


//led���߳�
static void Thread4_entry(void *parameter)
{

	while (1)
	{
//		if(Relay_Flag == Relay_Open)
//		{
//			for(int t=0;t<PIXEL_NUM1;t++)
//			{
//				WS281x_SetPixelRGB(t,0,255,0);
//				WS281x_Show();
//				rt_hw_us_delay(500000);
//				rt_hw_us_delay(500000);
//				rt_hw_us_delay(500000);
//			}
//			WS281x_CloseAll();
//		}
		rt_thread_delay(10);
//		if((Relay_Flag != Relay_Open)&&(Errors_Data& 0xBFFF) == 0)
//		{
//			if(cloud_jcsj.sfcq==1)
//			{
//				if(ChargeStartSwitch==0&&Charge_Flag!=CP12VCharge_bit)
//				{
//					lec_data_show_count=0;
//					RGB_GER();
//				}
////				else if(ChargeStartSwitch==1&&Charge_Flag==CP9VCharge_bit&&recharge_state_flag==0)
//				else if(ChargeStartSwitch==1&&Relay_Flag == Relay_Close)
//				{
//					RGB_YEL();
//				}
//			}
//			else if(cloud_jcsj.sfcq==0)
//			{
//				RGB_BLU();
//			}
//		}
//		rt_kprintf("4\n");
		
		
	}
}



//BL0939�ɼ��߳�
static void Thread5_entry(void *parameter)
{
	
	while (1)
	{
		
		bl_data_filter();
		
		
//		rt_kprintf("5\n");
		rt_thread_delay(10);
		
	}
}


//485ָ���߳�
static void Thread6_entry(void *parameter)
{
	
	while (1)
	{
//		WS281x_TheaterChase(WS281x_Color(127, 0, 0), 10); // Red
//		rt_thread_delay(10);
//		modbus_05_function();
//		rt_thread_delay(10);
//		modbus_02_function();
		rt_thread_delay(10);
		modbus_03_function();
		rt_thread_delay(10);
		modbus_10_function();
//		rt_thread_delay(10);
//		modbus_65_function();
//		rt_kprintf("6\n");
//		rt_thread_delay(10);
		
	}
}

//ADC�ɼ��߳�
static void Thread7_entry(void *parameter)
{
	rt_thread_startup(T9_thread);
	while (1)
	{
		
		sensor_data_filter();

		
//		rt_kprintf("7\n");
		rt_thread_delay(10);
	}
}

//�ɿ����߳�
static void Thread8_entry(void *parameter)
{
	
	while (1)
	{

		rt_thread_delay(10);
	}
}



//rgb���߳�
static void Thread9_entry(void *parameter)
{
	rt_thread_delay(1000);
	dwin_diyiye(qr_code,program_version);			//������Ļ��ʾ
	if(cloud_jcsj.sfcq==1)
	{
		PilotLamp_Flag=0x02;
		DwinContent_Flag=0x01;								//������ʾ�ر�
		UrgencyLamp_Flag=0x00;
		emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
	}
	else if(cloud_jcsj.sfcq==0)
	{
		PilotLamp_Flag=0x01;
		DwinContent_Flag=0x01;								//������ʾ�ر�
		UrgencyLamp_Flag=0x00;
		emergency_light_lcd(emergency_callback,UrgencyLamp_Flag,DwinContent_Flag);
	}
}





int main(void)
{
	
//	uint32_t CpuID[3] = {0};
//	CpuID[0]=*(uint32_t *)(0x1FFFF7E8);
//	CpuID[1]=*(uint32_t*)(0x1FFFF7EC);
//	CpuID[2]=*(uint32_t*)(0x1FFFF7F0);
	
	
	ws2812_init();
//	uart_init();
	Gpio_init();
	rc522_init();
	pwm_init();
	hwtimer_init();
	adc_init();
	rtc_init();
	interrupt_init();
	bl24512_init();
	
	uart_init();
	cloud_jcsj.zzt=0x02;																//���׮����״̬��־
	init_inspection();
	if(electrtc_energy_select==1)
	{
			//��ȡ�豸��ַ
//		Read_Device_Addr();
		uint8_t read_data[4]={0x00},read_len=0x00,control=0x13;
		uint8_t addr[6]={0xAA,0xAA,0xAA,0xAA,0xAA,0xAA};
		Dds3366_Read_Addr(addr,control,read_len,read_data);
		rt_thread_delay(500);
		Dds3366_Read_Addr(addr,control,read_len,read_data);
		rt_thread_delay(500);
		Dds3366_Read_Addr(addr,control,read_len,read_data);
		rt_thread_delay(500);
		Dds3366_Read_Addr(addr,control,read_len,read_data);
		rt_thread_delay(500);
		Dds3366_Read_Addr(addr,control,read_len,read_data);
		rt_thread_delay(500);
		
	}
	
	
	
	if(cloud_enthernet_4g_connect==2)
	{
		rt_hw_at32_emac_init();
		mqtt_log_init();
		rt_thread_delay(5000);
		client = mqtt_lease();
		mqtt_set_host(client, (char *)manufacturer_ip);
		mqtt_set_port(client, (char *)manufacturer_port);
		mqtt_set_user_name(client, (char *)device_id);
		mqtt_set_password(client, (char *)manufacturer_pass);
		mqtt_set_client_id(client, (char *)device_id);
		mqtt_set_clean_session(client, 1);
		KAWAII_MQTT_LOG_I("The ID of the Kawaii client is: %s ", device_id);
		mqtt_connect(client);
		mqtt_subscribe(client, KAWAII_MQTT_SUBTOPIC, QOS0, sub_topic_handle1);
	}
	
	uint8_t read_data_time[4];
	uint32_t ljcdsj_min=0;
	bl24cxx_read(bl24512_device,0x0099,read_data_time,4);	
//	ljcdsj_min=((uint32_t)read_data_time[0]<<24)+((uint32_t)read_data_time[1]<<16)+((uint32_t)read_data_time[2]<<8)+((uint32_t)read_data_time[3]);
//	ljcdsj_min=ljcdsj_min+cloud_jcsj.ljcdsjmin;
	for(int t=0;t<4;t++)
	{
		read_modbus_buffer[t+130]=read_data_time[t];
	}
			
	T1_thread = rt_thread_create("cloud_connect_thread",Thread1_entry, RT_NULL, 9216, 1, 5);
//	T2_thread = rt_thread_create("network_thread",Thread2_entry, RT_NULL, 2048, 1, 5);
	T3_thread = rt_thread_create("recharge_thread",Thread3_entry, RT_NULL, 4096, 0, 5);
//	T4_thread = rt_thread_create("led_thread",Thread4_entry, RT_NULL, 4096, 3, 5);
	T5_thread = rt_thread_create("bl0939_thread",Thread5_entry, RT_NULL, 4096, 2, 5);
	T6_thread = rt_thread_create("485_thread",Thread6_entry, RT_NULL, 4096, 3, 5);
	T7_thread = rt_thread_create("adc_thread",Thread7_entry, RT_NULL, 4096, 2, 5);
//	T8_thread = rt_thread_create("mqtt_thread",Thread8_entry, RT_NULL, 2048, 3, 10);
	T9_thread = rt_thread_create("rgb_thread",Thread9_entry, RT_NULL, 4096, 3, 5);



	
	rt_thread_startup(T1_thread);
////	rt_thread_startup(T2_thread);
	rt_thread_startup(T3_thread);
////	rt_thread_startup(T4_thread);
	rt_thread_startup(T5_thread);
	rt_thread_startup(T6_thread);
	rt_thread_startup(T7_thread);
	
	
//	rt_thread_startup(T8_thread);

//	dwin_dierye();
//	dwin_dieryeSZ(2312,321,2,2330,10000,6000);
	
	return 0;
}





//���������ַΪ0x08000000 256kb
//Ӧ�ó����ַΪ0x08080000 300kb

//�ж�������ת��ַ
static int ota_app_vtor_reconfig()
{
	#define RT_APP_PART_ADDR 0x08040000
	#define NVIC_VTOR_MASK 0xFFFFFF80
	SCB->VTOR=RT_APP_PART_ADDR;
	return 0;
}

INIT_BOARD_EXPORT(ota_app_vtor_reconfig);







