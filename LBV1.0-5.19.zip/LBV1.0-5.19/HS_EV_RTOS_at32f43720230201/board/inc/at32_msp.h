/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-03-31     shelton      first version
 */

#ifndef __AT32_MSP_H__
#define __AT32_MSP_H__

void at32_msp_usart_init(void *instance);
void at32_msp_spi_init(void *instance);
void at32_msp_tmr_init(void *instance);
void at32_msp_i2c_init(void *instance);
void at32_msp_sdio_init(void *instance);
void at32_msp_adc_init(void *instance);
void at32_msp_hwtmr_init(void *instance);
void at32_msp_can_init(void *instance);
void at32_msp_qspi_init(void *instance);
void at32_msp_sdram_init(void *instance);
void at32_msp_emac_init(void *instance);
void at32_msp_exint_init(void *instance);
void at32_msp_usb_init(void *instance);
#endif /* __AT32_MSP_H__ */
