/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2022-05-16     shelton      first version
 */

#include "drv_common.h"
#include "drv_adc.h"
#include "HS_main.h"
#include "HS_#define.h"

#if defined(BSP_USING_ADC1) || defined(BSP_USING_ADC2) || \
    defined(BSP_USING_ADC3)

//#define DRV_DEBUG
#define LOG_TAG             "drv.adc"
#include <drv_log.h>


uint16_t adc3_ordinary_valuetab[ADC3_DMA_MAX];
//uint16_t dma_trans_complete_flag=0,adc1_overflow_flag=0;

struct at32_adc
{
    struct rt_adc_device at32_adc_device;
    adc_type *adc_x;
    char *name;
};

static struct at32_adc at32_adc_obj[] =
{
#ifdef BSP_USING_ADC1
    ADC1_CONFIG,
#endif

#ifdef BSP_USING_ADC2
    ADC2_CONFIG,
#endif

#ifdef BSP_USING_ADC3
    ADC3_CONFIG,
#endif
};


uint16_t adc3_data[ADC3_DMA_MAX];

//void DMA1_Channel1_IRQHandler(void)
//{
//  if(dma_flag_get(DMA1_FDT1_FLAG) != RESET)
//  {
//    dma_flag_clear(DMA1_FDT1_FLAG);
//    dma_trans_complete_flag++;
////		adc3_data[dma_trans_complete_flag]=adc3_ordinary_valuetab;
//  }
//}


//void ADC1_2_3_IRQHandler(void)
//{
//  if(adc_flag_get(ADC1, ADC_OCCO_FLAG) != RESET)
//  {
//    adc_flag_clear(ADC1, ADC_OCCO_FLAG);
//    adc1_overflow_flag++;
//  }
//}




static void dma_config(void)
{
  dma_init_type dma_init_struct;
  crm_periph_clock_enable(CRM_DMA1_PERIPH_CLOCK, TRUE);
  nvic_irq_enable(DMA1_Channel1_IRQn, 0, 0);

  dma_reset(DMA1_CHANNEL1);
  dma_default_para_init(&dma_init_struct);
  dma_init_struct.buffer_size = ADC3_DMA_MAX;
  dma_init_struct.direction = DMA_DIR_PERIPHERAL_TO_MEMORY;
  dma_init_struct.memory_base_addr = (uint32_t)adc3_ordinary_valuetab;
  dma_init_struct.memory_data_width = DMA_MEMORY_DATA_WIDTH_HALFWORD;
  dma_init_struct.memory_inc_enable = TRUE;
  dma_init_struct.peripheral_base_addr = (uint32_t)&(ADC3->odt);
  dma_init_struct.peripheral_data_width = DMA_PERIPHERAL_DATA_WIDTH_HALFWORD;
  dma_init_struct.peripheral_inc_enable = FALSE;
  dma_init_struct.priority = DMA_PRIORITY_HIGH;
  dma_init_struct.loop_mode_enable = TRUE;
  dma_init(DMA1_CHANNEL1, &dma_init_struct);

  dmamux_enable(DMA1, TRUE);
  dmamux_init(DMA1MUX_CHANNEL1, DMAMUX_DMAREQ_ID_ADC3);

  /* enable dma transfer complete interrupt */
  dma_interrupt_enable(DMA1_CHANNEL1, DMA_FDT_INT, TRUE);
  dma_channel_enable(DMA1_CHANNEL1, TRUE);
}


static rt_err_t at32_adc_enabled(struct rt_adc_device *device, rt_uint32_t channel, rt_bool_t enabled)
{
    adc_type *adc_x;
    adc_base_config_type adc_config_struct;
#if defined (SOC_SERIES_AT32F435) || defined (SOC_SERIES_AT32F437)
    adc_common_config_type adc_common_struct;
#endif

    RT_ASSERT(device != RT_NULL);
    adc_x = device->parent.user_data;

    at32_msp_adc_init(adc_x);

#if defined (SOC_SERIES_AT32F435) || defined (SOC_SERIES_AT32F437)
	
		nvic_irq_enable(ADC1_2_3_IRQn, 0, 0);
		dma_config();
	
    adc_common_default_para_init(&adc_common_struct);
    /* config combine mode */
    adc_common_struct.combine_mode = ADC_INDEPENDENT_MODE;
    /* config division, adcclk is division by hclk */
    adc_common_struct.div = ADC_HCLK_DIV_16;		//18mhz
    /* config common dma mode,it's not useful in independent mode */
    adc_common_struct.common_dma_mode = ADC_COMMON_DMAMODE_DISABLE;
    /* config common dma request repeat */
    adc_common_struct.common_dma_request_repeat_state = FALSE;
    /* config adjacent adc sampling interval,it's useful for ordinary shifting mode */
    adc_common_struct.sampling_interval = ADC_SAMPLING_INTERVAL_5CYCLES;
    /* config inner temperature sensor and vintrv *///FALSE
    adc_common_struct.tempervintrv_state = 1;
    /* config voltage battery *///FALSE
    adc_common_struct.vbat_state = FALSE;
    adc_common_config(&adc_common_struct);
#else
#if !defined (SOC_SERIES_AT32F415)
    adc_combine_mode_select(ADC_INDEPENDENT_MODE);
#endif
    adc_ordinary_conversion_trigger_set(adc_x, ADC12_ORDINARY_TRIG_SOFTWARE, TRUE);
#endif

    /* adc_x configuration */
    adc_base_default_para_init(&adc_config_struct);
    adc_config_struct.data_align = ADC_RIGHT_ALIGNMENT;
    adc_config_struct.ordinary_channel_length = 1;
    adc_config_struct.repeat_mode = FALSE;
    adc_config_struct.sequence_mode = FALSE;
    adc_base_config(adc_x, &adc_config_struct);
		
		adc_resolution_set(adc_x,ADC_RESOLUTION_12B);
		
		
		
		adc_ordinary_conversion_trigger_set(ADC3, ADC_ORDINARY_TRIG_TMR2CH4, ADC_ORDINARY_TRIG_EDGE_NONE);
		adc_dma_mode_enable(ADC3, TRUE);
		adc_dma_request_repeat_enable(ADC3, TRUE);
		adc_interrupt_enable(ADC3, ADC_OCCO_INT, TRUE);
		
		
		
//		adc_interrupt_enable(ADC2, ADC_OCCO_INT, TRUE);
    if (!enabled)
    {
        /* disable adc_x */
        adc_enable(adc_x, FALSE);
    }
    else
    {
        /* enable adc_x */
        adc_enable(adc_x, TRUE);
				while(adc_flag_get(adc_x, ADC_RDY_FLAG) == RESET)
				{
				}
        /* enable adc_x calibration */
        adc_calibration_init(adc_x);
        /* check the end of adc_x reset calibration register */
        while(adc_calibration_init_status_get(adc_x) == SET)
        {
        }
        /* start adc_x calibration */
         adc_calibration_start(adc_x);
        /* check the end of adc_x calibration */
        while(adc_calibration_status_get(adc_x) == SET)
        {
        }
				adc_ordinary_software_trigger_enable(ADC3, TRUE);
    }

    return RT_EOK;
}

static rt_err_t at32_get_adc_value(struct rt_adc_device *device, rt_uint32_t channel, rt_uint32_t *value)
{
    adc_type *adc_x;
    rt_uint32_t timeout = 0;

    RT_ASSERT(device != RT_NULL);
    adc_x = device->parent.user_data;

    /* adc_x regular channels configuration */
#if defined (SOC_SERIES_AT32F435) || defined (SOC_SERIES_AT32F437)
    adc_ordinary_channel_set(adc_x, (adc_channel_select_type)channel, 1, ADC_SAMPLETIME_247_5);//260
#else
    adc_ordinary_channel_set(adc_x, (adc_channel_select_type)channel, 1, ADC_SAMPLETIME_239_5);
#endif

    /* start adc_x software conversion */
    adc_ordinary_software_trigger_enable(adc_x, TRUE);

    /* wait for the adc to convert */
#if defined (SOC_SERIES_AT32F435) || defined (SOC_SERIES_AT32F437)
    while((adc_flag_get(adc_x, ADC_OCCE_FLAG) == RESET) && timeout < 0xFFFF)
#else
    while((adc_flag_get(adc_x, ADC_CCE_FLAG) == RESET) && timeout < 0xFFFF)
#endif
    {
        timeout ++;
    }

    if(timeout >= 0xFFFF)
    {
        LOG_D("channel%d converts timeout, please confirm adc_x enabled or not", channel);
    }

    /* get adc value */
    *value = adc_ordinary_conversion_data_get(adc_x);

    return RT_EOK;
}

static const struct rt_adc_ops at_adc_ops =
{
    .enabled = at32_adc_enabled,
    .convert = at32_get_adc_value,
};
//static
 int rt_hw_adc_init(void)
{
    int result = RT_EOK;
    int i = 0;

    for (i = 0; i < sizeof(at32_adc_obj) / sizeof(at32_adc_obj[0]); i++)
    {
        /* register ADC device */
        if (rt_hw_adc_register(&at32_adc_obj[i].at32_adc_device, at32_adc_obj[i].name, &at_adc_ops, at32_adc_obj[i].adc_x) == RT_EOK)
        {
            LOG_D("%s register success", at32_adc_obj[i].name);
        }
        else
        {
            LOG_E("%s register failed", at32_adc_obj[i].name);
            result = -RT_ERROR;
        }

    }

    return result;
}
INIT_BOARD_EXPORT(rt_hw_adc_init);

#endif /* BSP_USING_ADC */
